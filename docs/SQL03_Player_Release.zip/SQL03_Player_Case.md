# SQL03 — The Missing Batch
## Case briefing

**Your role:** Two investigators working together.  
**Your objective:** Determine who diverted the missing batch of QUBIT finalist badges, how the records reveal the diversion, and what the person was trying to hide.

At 3:20 PM, the event desk reports that **Batch B-17**, containing 12 finalist badges, never arrived. The dispatch sheet says it left the print room at 2:46 PM. The event desk says it received only an empty sleeve. A second batch, B-17R, appears in the records—but nobody remembers requesting a reprint.

Four people had a legitimate reason to handle badge production or delivery:

- **Aarav Mehta** — print-room operator
- **Nisha Varma** — event logistics coordinator
- **Kabir Shah** — runner assigned to deliveries
- **Leena Das** — registration lead

The first obvious theory is that the runner lost the package. But the database records do not all describe the same kind of event: some are print jobs, some are custody scans, and some are desk receipts. Treating them as interchangeable may send you after the wrong person.

## Investigation rules
- Use SQL to inspect the tables unlocked in each phase.
- You may work together, divide query-writing and timeline reconstruction, and compare findings.
- Explore freely: failed exploratory queries do not cost points.
- For scored tasks, submit one of the provided answer options. A wrong committed answer may incur the standard penalty.
- Do not assume that a timestamp proves physical custody unless the record type supports that conclusion.

## Phase 1 — Establish the facts
Find the intended quantity and destination of B-17, compare the dispatch and receipt records, and identify what is unusual about the reprint.

## Phase 2 — Reconstruct custody
Join print jobs, custody scans and event-desk receipts. Determine whether Kabir ever accepted the original sealed package and whether the reprint was a normal replacement.

## Phase 3 — Test the cover story
Compare the reprint's job metadata with the approval trail and the final handoff. Identify who initiated the unapproved reprint and why the missing-batch report was delayed.

## Final deduction
Submit:
1. **Who was responsible?**
2. **Which explanation best fits the complete record?**

Do not accuse someone based only on access. Your conclusion must explain the missing original, the unexplained reprint and the inconsistent delivery record.
