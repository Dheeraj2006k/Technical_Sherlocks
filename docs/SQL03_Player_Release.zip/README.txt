Player-facing release only. Do not include answer keys, seed SQL, task grading data, or author notes in the client bundle.
