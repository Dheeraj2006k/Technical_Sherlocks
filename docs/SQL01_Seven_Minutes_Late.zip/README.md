# SQL01 — Seven Minutes Late

**Status: packaged case content, not production-certified.**

## Files
- `schema/001_sql01_schema.sql`: case-specific schema in `sql01`.
- `seeds/seed_SQL01.sql`: deterministic, idempotent seed.
- `verification/verify_SQL01.sql`: structural/content checks.
- `source_case_pack/SQL01_Case_Manifest.json`: tasks, phases, scoring and intended answer.
- `source_case_pack/SQL01_Hints.json`: progressive hints.
- `source_case_pack/SQL01_Author_Notes_and_Answer_Key.md`: restricted solution and review gates.
- `player_release/`: player-facing story and prompts only.

## Staging sequence
1. Apply schema to a disposable Supabase staging project.
2. Run the seed SQL.
3. Run verification SQL; every check should report PASS.
4. Integrate the manifest into the shared game engine and enforce server-side phase unlocks.
5. Test that restricted notes, actor hints and future-phase evidence cannot be queried early.
6. Run a blind trio playtest and concurrent/security tests before event deployment.

## Important
The pack has not been executed against your Supabase project, integrated with the runtime, or blind-playtested. SQL01's source concept has a compelling multi-clock mystery, but the current seed remains a compact scaffold. Expand decoy/background data and complete the fairness gates in the organizer notes before calling it production-ready.
