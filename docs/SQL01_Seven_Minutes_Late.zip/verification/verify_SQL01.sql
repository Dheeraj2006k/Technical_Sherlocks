WITH checks AS (
 SELECT 'expected_case_tables' check_name,
   (SELECT count(*) FROM information_schema.tables WHERE table_schema='sql01'
   AND table_name IN ('team_members','workshop_access_log','equipment_checkout','initial_statements','fest_activity_log','maintenance_reports','report_notifications','notification_activity','power_controller_log','corridor_camera_events','building_access_points','security_configuration','component_inventory','rohit_fest_tasks','rohit_messages','nikhil_device_activity','staff_directory'))=17 ok
 UNION ALL SELECT 'fault_report', (SELECT count(*) FROM sql01.maintenance_reports WHERE report_id='MR-184' AND component_code='MODULE_04')=1
 UNION ALL SELECT 'rohit_read_warning', (SELECT count(*) FROM sql01.notification_activity na JOIN sql01.report_notifications rn USING(notification_id) WHERE rn.recipient='Rohit Kulkarni' AND na.action='OPENED')=1
 UNION ALL SELECT 'controller_three_minutes_slow', (SELECT count(*) FROM sql01.security_configuration WHERE config_key='controller_clock_offset_minutes' AND config_value='-3')=1
 UNION ALL SELECT 'camera_four_minutes_fast', (SELECT count(*) FROM sql01.security_configuration WHERE config_key='camera_clock_offset_minutes' AND config_value='+4')=2
 UNION ALL SELECT 'rear_door_no_rfid', (SELECT count(*) FROM sql01.building_access_points WHERE door_name='Rear Loading Door' AND records_rfid=false)=1
 UNION ALL SELECT 'replacement_module_missing', (SELECT count(*) FROM sql01.component_inventory WHERE component_code='MODULE_SPARE' AND status='NOT_FOUND')=1
 UNION ALL SELECT 'rohit_demo_message', (SELECT count(*) FROM sql01.rohit_messages WHERE sender='Rohit Kulkarni' AND message_text='Give me ten minutes.')=1
)
SELECT check_name, CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END result FROM checks ORDER BY check_name;
