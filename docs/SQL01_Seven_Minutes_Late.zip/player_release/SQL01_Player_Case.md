# SEVEN MINUTES LATE
**Case SQL01 · Trio investigation**

At 9:52 PM on the final night before QUBIT opens, Arjun Varma is found unconscious beside the damaged power-control cabinet for Pulse, the festival's interactive LED wall.

His teammate Nikhil Reddy had argued with him earlier. Nikhil's workshop entry appears close to Arjun's final entry, and Nikhil says he left before Arjun arrived.

But three systems recorded the night—and their clocks disagree.

Your team must identify who was responsible for what happened to Arjun, reconstruct the sequence of events, and distinguish knowing negligence from an intentional attack.

## Investigation phases
1. **Who Was Still There?** — team roster, workshop access, equipment checkout, statements and maintenance report.
2. **The Fault and the Alibi** — report notifications, notification activity and independent device/activity records.
3. **Seven Minutes Late** — controller events, camera events, door configuration, component inventory, tasks and messages.

## Questions
1. How many Team Pulse members appear in engineering-block activity records after 9:20 PM?
2. Which three Team Pulse members have workshop RFID entries after 9:20 PM before the incident?
3. Which person of interest has two independent records supporting presence in Seminar Hall 2 after leaving the workshop?
4. Who filed the official Module 04 overheating report, and what did it require?
5. After correcting the controller clock, what is the real time Module 04 powered on again?
6. Which entrance explains why the person entering around the reactivation time has no RFID entry?

## Final deduction
Who was responsible for what happened to Arjun Varma, and what evidence shows the action was knowing rather than accidental?

SQL exploration errors are free. Only committed answers are subject to the game's scoring rules.
