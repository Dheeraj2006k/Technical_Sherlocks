-- SQL01: Seven Minutes Late — case-specific PostgreSQL evidence schema.
-- Namespaced to keep case content separate from shared game runtime tables.
CREATE SCHEMA IF NOT EXISTS sql01;

CREATE TABLE IF NOT EXISTS sql01.team_members (
  member_id text PRIMARY KEY,
  full_name text NOT NULL,
  team_name text NOT NULL,
  role_title text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.workshop_access_log (
  event_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  person_name text NOT NULL,
  door_name text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('ENTRY','EXIT')),
  credential text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.equipment_checkout (
  checkout_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  person_name text NOT NULL,
  item_name text NOT NULL,
  action text NOT NULL,
  destination text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.initial_statements (
  statement_id text PRIMARY KEY,
  person_name text NOT NULL,
  recorded_at timestamptz NOT NULL,
  statement_text text NOT NULL,
  statement_type text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.fest_activity_log (
  activity_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  person_name text NOT NULL,
  activity text NOT NULL,
  location text NOT NULL,
  source_system text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.maintenance_reports (
  report_id text PRIMARY KEY,
  reported_at timestamptz NOT NULL,
  reported_by text NOT NULL,
  component_code text NOT NULL,
  severity text NOT NULL,
  report_text text NOT NULL,
  status text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.report_notifications (
  notification_id text PRIMARY KEY,
  report_id text NOT NULL REFERENCES sql01.maintenance_reports(report_id),
  recipient text NOT NULL,
  sent_at timestamptz NOT NULL,
  delivery_status text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.notification_activity (
  activity_id text PRIMARY KEY,
  notification_id text NOT NULL REFERENCES sql01.report_notifications(notification_id),
  actor text NOT NULL,
  action text NOT NULL,
  event_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.power_controller_log (
  controller_event_id text PRIMARY KEY,
  controller_at timestamptz NOT NULL,
  component_code text NOT NULL,
  event_type text NOT NULL,
  status text NOT NULL,
  actor_hint text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.corridor_camera_events (
  camera_event_id text PRIMARY KEY,
  camera_at timestamptz NOT NULL,
  camera_location text NOT NULL,
  event_type text NOT NULL,
  person_hint text NOT NULL,
  linked_reference text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.building_access_points (
  access_point_id text PRIMARY KEY,
  door_name text NOT NULL,
  access_method text NOT NULL,
  records_rfid boolean NOT NULL,
  camera_coverage text NOT NULL,
  notes text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.security_configuration (
  config_id text PRIMARY KEY,
  access_point_id text NOT NULL,
  config_key text NOT NULL,
  config_value text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.component_inventory (
  component_code text PRIMARY KEY,
  component_name text NOT NULL,
  storage_location text NOT NULL,
  safe_to_use boolean NOT NULL,
  status text NOT NULL,
  last_checked_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.rohit_fest_tasks (
  task_id text PRIMARY KEY,
  task_at timestamptz NOT NULL,
  assigned_to text NOT NULL,
  task_text text NOT NULL,
  task_status text NOT NULL,
  location text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.rohit_messages (
  message_id text PRIMARY KEY,
  message_at timestamptz NOT NULL,
  sender text NOT NULL,
  recipient text NOT NULL,
  message_text text NOT NULL,
  channel text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.nikhil_device_activity (
  device_event_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  person_name text NOT NULL,
  device_name text NOT NULL,
  event_type text NOT NULL,
  location text NOT NULL
);
CREATE TABLE IF NOT EXISTS sql01.staff_directory (
  staff_id text PRIMARY KEY,
  full_name text NOT NULL,
  role_title text NOT NULL,
  known_context text NOT NULL
);
