# SQL01 — Organizer Answer Key (RESTRICTED)

## Intended conclusion
**Rohit Kulkarni** is responsible for knowingly restoring power to Module 04 after a high-severity warning said its connector was overheating and the unit must not be powered. He did this because the team was under pressure to demonstrate Pulse at full brightness at 10 PM. Arjun later entered and received an electric shock while diagnosing the powered cabinet.

This is a finding of reckless, knowing conduct—not an intentional attack. The evidence does not prove Rohit intended to hurt Arjun.

## Clock correction
- Workshop RFID access log is the reference clock.
- Power controller clock is 3 minutes slow: add 3 minutes to displayed times. `21:29` means real `21:32`.
- Corridor camera clock is 4 minutes fast: subtract 4 minutes from displayed times. A camera event displayed as `21:36` would mean real `21:32`.

## Main evidence chain
1. Kavya reports Module 04 connector temperature above safe operating range at 20:46 and marks it DO NOT POWER.
2. Notification log says Rohit received the report at 20:47 and opened it at 20:49.
3. Spare-module search returns no spare.
4. Priya reminds Rohit of the 10 PM full-brightness demo at 21:28; Rohit replies “Give me ten minutes” at 21:30.
5. Controller shows Module 04 ON at 21:29; corrected real time is 21:32.
6. Rear-door camera is offset +4 minutes; corrected events should align with the same time. The rear door has no RFID event by design.
7. Arjun later enters via main workshop RFID and is found unconscious.

## Fairness / production gates
- Player-facing data must not reveal `actor_hint='ROHIT'` or the restricted answer key too early. Consider replacing actor_hint with `UNKNOWN` for player queries and releasing corroborating evidence progressively.
- The initial seed intentionally contains limited illustrative evidence rather than the large realistic-sized datasets described in the source concept. Expand with decoy/background rows before deployment.
- Align incident time consistently: the source premise says found at 21:52; ensure all tables use this same timestamp.
- Add an independently corroborated camera event at displayed 21:36 that corrects to real 21:32 if the exact timestamp convergence is a scored deduction.
- Blind trio playtest, SQL execution and permission checks remain required.
