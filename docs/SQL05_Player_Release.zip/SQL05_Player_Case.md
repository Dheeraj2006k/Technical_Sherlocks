# SQL05 — The Wrong Parcel

## Case briefing
**Your role:** Solo investigator.

At 4:10 PM, the QUBIT demo desk opens parcel **PX-41**. It contains spare stage clips—not the prototype sensor module expected by the team. The dashboard says **PX-14** was delivered, but nobody at the demo desk signed for it.

Three people had legitimate roles in the delivery chain:
- **Ravi Menon** — dispatch clerk who prints labels
- **Sana Qureshi** — courier handoff coordinator
- **Joel D'Souza** — demo desk receiver

A delivery scan records what the system was told, not necessarily what was physically inside a parcel. The label history, route scans, expected delivery and desk receipt may not tell the same story.

### Phase 1 — The Mix-up
Establish which parcel was expected, what actually arrived, and where the first mismatch appears.

### Phase 2 — The Route
Join parcel scans, label history and handoff records. Determine whether the parcels were swapped in transit or mislabelled before dispatch.

### Phase 3 — The Cover-up
Compare the label reprint audit with dispatch messages and the final receipt. Identify who redirected the package and why.

### Final deduction
Submit who was responsible and which explanation best fits the complete record. Your explanation must account for the wrong parcel at the desk, the missing prototype module, and the misleading delivered status.

Exploratory SQL errors do not cost points. Scored answers use fixed choices; incorrect committed answers may incur the standard penalty.
