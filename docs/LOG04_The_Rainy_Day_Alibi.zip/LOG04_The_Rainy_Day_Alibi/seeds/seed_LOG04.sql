-- LOG04 — The Rainy-Day Alibi. Restricted server-side case content.
-- Requires schema/001_logic_case_content_schema.sql from the shared Logic database pack.
-- Idempotent upserts. Do not expose answer-key columns to browser clients.
begin;

insert into public.logic_case_catalog (case_id,title,track,content_version,recommended_team_size,release_status,core_mechanism,max_score,scoring_config,source_manifest) values ('LOG04','The Rainy-Day Alibi','LOGIC','1.0.0',2,'draft_pending_review_and_platform_qa','cross-check an environmental alibi against independent access, document-version, printer, custody, and authorization records',100,'{"investigation_max_each":10,"hint_rewards":[10,8,6,4,2],"investigation_task_count":6,"final_person_points":25,"final_explanation_points":15,"wrong_committed_answer_penalty":2,"score_floor":0,"total":100}'::jsonb,'{"case_id":"LOG04","title":"The Rainy-Day Alibi","content_version":"1.0.0","player_asset":"LOG04_Player_Case.md","restricted_assets":["LOG04_Case_Manifest.json","LOG04_Author_Notes.md","LOG04_Scoring_and_Hints.md","LOG04_Validation_Checklist.md"],"phases":[{"phase_number":1,"phase_name":"The Alibi","evidence_ids":["A","B","C","D"],"task_ids":["T1","T2"]},{"phase_number":2,"phase_name":"The Record Changes","evidence_ids":["E","F","G","H"],"task_ids":["T3","T4"]},{"phase_number":3,"phase_name":"The Contradiction","evidence_ids":["I","J","K","L","M"],"task_ids":["T5","T6"]}],"tasks":[{"task_id":"T1","phase_number":1,"task_number":1,"correct_option_key":[["A","It proves she was inside the judges'' office at 3:23 PM."],["B","It contradicts the claim that heavy rain continued until 3:40 PM, but weather alone does not establish where she was."],["C","It proves no one could enter the building."],["D","It proves Devika is guilty without any other evidence."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5},{"task_id":"T2","phase_number":1,"task_number":2,"correct_option_key":[["A","Devika''s badge was granted entry at 3:23 PM, but the swipe alone does not identify the person carrying it."],["B","Arjun entered the corridor at 3:19 PM."],["C","Isha entered the corridor at 3:27 PM."],["D","The original summary was definitely removed at 3:23 PM."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5},{"task_id":"T3","phase_number":2,"task_number":3,"correct_option_key":[["A","The replacement changed the total points and the tie-break."],["B","The replacement changed the tie-break result while keeping the total points the same."],["C","The judges officially approved Team Meridian after 3:28 PM."],["D","The printer audit proves Devika personally collected the page."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5},{"task_id":"T4","phase_number":2,"task_number":4,"correct_option_key":[["A","The D.RAO account printed the revision at 3:28 PM; the audit alone does not identify the person who operated or collected it."],["B","Devika was certainly standing at the printer."],["C","Isha printed the replacement at 3:28 PM."],["D","The replacement must be authentic because the printer completed the job."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5},{"task_id":"T5","phase_number":3,"task_number":5,"correct_option_key":[["A","The rain stopped at 3:16, and her badge recorded a successful corridor entry at 3:23; together these conflict with her account, although each record has limits."],["B","The weather station proves she was inside the office."],["C","The badge log proves with certainty that no one could have borrowed her badge."],["D","The maintenance ticket proves Devika was at the loading bay all afternoon."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5},{"task_id":"T6","phase_number":3,"task_number":6,"correct_option_key":[["A","Arjun accidentally printed a new sheet during rehearsal, and the judges silently approved it."],["B","Isha changed the tie-break because she printed a badge after 3:28 PM."],["C","Devika used the results workflow to produce an unauthorised replacement tie-break summary; her corridor badge entry, account print, contradicted alibi and lack of judge approval converge on her, while no single log is treated as conclusive alone."],["D","Kabir entered the judges'' corridor despite the denied-access record and changed the sheet, with no supporting evidence."]],"max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2,"hint_count":5}],"final_deduction":{"correct_character_id":"devika_rao","responsible_person_points":25,"correct_explanation_key":"B","explanation_points":15,"wrong_answer_penalty":2,"components_graded_independently":true},"scoring":{"investigation_tasks_max":60,"final_person_max":25,"final_explanation_max":15,"total":100,"hint_rewards":[10,8,6,4,2],"wrong_committed_answer_penalty":2,"score_floor":0,"retry_allowed":true,"award_success_once":true,"server_authoritative":true},"author_only":{"ground_truth":"Devika introduced an unsigned replacement tie-break summary without a new judge decision. The intended deduction relies on converging evidence, not a single log.","important_limits":["Weather proves conditions at the loading bay, not personal location.","Badge log identifies the badge used, not conclusively its carrier.","Printer log identifies the account, not conclusively the operator or collector.","Do not grade free-text theories or require certainty beyond the fixed explanation."],"seed_ready":false},"release_gates":{"story_logic_review":"pending_independent_review","evidence_fairness_review":"pending","SQL_seed_validation":"pending_execution_in_staging","answer_key_secrecy_test":"pending","phase_unlock_test":"pending","two_player_shared_state_test":"pending","first_time_duo_playtests":"pending","live_release":"blocked_until_required_gates_pass"}}'::jsonb) on conflict (case_id) do update set title=excluded.title,content_version=excluded.content_version,recommended_team_size=excluded.recommended_team_size,release_status=excluded.release_status,core_mechanism=excluded.core_mechanism,max_score=excluded.max_score,scoring_config=excluded.scoring_config,source_manifest=excluded.source_manifest,updated_at=now();

insert into public.logic_case_phases (case_id,phase_number,phase_name) values
('LOG04',1, 'The Alibi'),
('LOG04',2, 'The Record Changes'),
('LOG04',3, 'The Contradiction') on conflict (case_id,phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id,character_id,display_name,role,sort_order) values
('LOG04','devika_rao','Devika Rao','Results coordinator',1),
('LOG04','arjun_mehta','Arjun Mehta','Stage manager',2),
('LOG04','farah_khan','Farah Khan','Judge liaison',3),
('LOG04','nikhil_verma','Nikhil Verma','AV technician',4),
('LOG04','isha_reddy','Isha Reddy','Registration lead',5),
('LOG04','kabir_shah','Kabir Shah','Student team representative',6),
('LOG04','judge_leena','Judge Leena','Aster category judge',7),
('LOG04','event_secretary','Event secretary','Results record custodian',8) on conflict (case_id,character_id) do update set display_name=excluded.display_name,role=excluded.role,sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id,evidence_id,phase_number,title,source_label,body_markdown,sort_order) values
('LOG04','A',1,'Rainfall Station Record','Venue weather station','| Time | Rain intensity | Notes |
|---|---:|---|
| 2:55 PM | 11 mm/hour | Heavy rain |
| 3:05 PM | 8 mm/hour | Rain easing |
| 3:12 PM | 3 mm/hour | Light rain |
| 3:16 PM | 0 mm/hour | Rain stopped at station |
| 3:25 PM | 0 mm/hour | Dry interval |
| 3:35 PM | 0 mm/hour | Dry interval |

The station clock is synchronised to venue time. This establishes conditions at the loading bay, not anyone''s location.',1),
('LOG04','B',1,'Devika''s Statement','First interview, 3:50 PM','Devika says she was at the covered loading bay from about 3:15 until nearly 3:40, that heavy rain prevented her crossing, and that she never entered the judges'' corridor after 3:10. She says her staff badge remained with her and she did not lend it.',2),
('LOG04','C',1,'Staff Access Log','Badge reader at judges'' corridor','| Time | Badge | Result |
|---|---|---|
| 3:08 PM | Devika Rao — R-14 | Entry granted |
| 3:12 PM | Farah Khan — F-02 | Entry granted |
| 3:19 PM | Arjun Mehta — A-11 | Access denied |
| 3:23 PM | Devika Rao — R-14 | Entry granted |
| 3:27 PM | Isha Reddy — I-07 | Access denied |
| 3:31 PM | Nikhil Verma — N-09 | Access denied |

A successful swipe records the badge presented, not conclusively the person carrying it.',3),
('LOG04','D',1,'Original Document Handover','Judges'' office handover register','3:12 PM — Farah records delivery of the original signed Aster judging summary. 3:14 PM — Judge Leena acknowledges receipt. 3:40 PM — Judge Leena reports the original missing from the red folder. 3:42 PM — A replacement summary is found in the event results folder. The register does not identify who last touched the folder after 3:14.',4),
('LOG04','E',2,'Judges'' Folder Inventory','Inventory signed at 3:14 and compared at 3:40','| Item | At 3:14 PM | At 3:40 PM |
|---|---|---|
| Original signed Aster summary | Present | Missing |
| Blue scoring worksheets | Present | Present |
| Judge''s handwritten tie-break note | Clipped behind summary | Still clipped behind blank divider |
| Red folder seal | Intact, S-208 | S-208 cut; replacement tape applied |

Judge Leena says she did not authorise anyone to open the folder after handover.',5),
('LOG04','F',2,'Replacement Summary Comparison','Original and replacement scans','The original scan shows Team Northstar ahead on the signed tie-break note. The replacement names Team Meridian as tie-break winner. Total points are unchanged; only the tie-break decision differs. The replacement footer reads “Printed 3:28 PM — Results Desk — User: D.RAO”. Printer account data identifies the account used, not necessarily the operator.',6),
('LOG04','G',2,'Results Desk Printer Audit','Managed printer log','| Time | Account | Job | Pages | Status |
|---|---|---|---:|---|
| 3:06 PM | D.RAO | Aster_summary_original.pdf | 1 | Completed |
| 3:28 PM | D.RAO | Aster_summary_revision.pdf | 1 | Completed |
| 3:29 PM | I.REDDY | Badge_reprint_17.pdf | 1 | Completed |
| 3:34 PM | D.RAO | Aster_summary_revision.pdf | 1 | Cancelled |

The audit records account and job status, not who collected each page.',7),
('LOG04','H',2,'Stage Rehearsal Log','Stage run sheet and AV cue timestamps','3:18 PM — Arjun begins award-announcement rehearsal. 3:21 — first microphone cue. 3:26 — second microphone cue. 3:32 — final timing cue. 3:36 — rehearsal ends. This supports Arjun being occupied for much of the interval but does not prove he could not briefly leave.',8),
('LOG04','I',3,'Badge Custody Check','Staff badge issue and return register','Devika checked out R-14 at 8:42 AM and signed that it would remain in her possession. At 3:45 PM she said it was clipped to her lanyard all afternoon and she did not lend it. No transfer is recorded. A 3:50 PM interview photo shows R-14 on her lanyard; that photo does not establish where it was at 3:23.',9),
('LOG04','J',3,'Loading-Bay Service Ticket','Nikhil''s signed maintenance ticket','3:17 PM — Nikhil checks the outer cable cover. 3:22 — walkway passable and cover dry. 3:24 — he photographs the cleared walkway; timestamp verified by venue media system, no person identifiable. 3:29 — maintenance kit returned. Nikhil did not see Devika during his check but does not claim she was absent the entire period.',10),
('LOG04','K',3,'Results Revision Request','Results desk email archive','3:04 PM — Devika asks the secretary to prepare a clean copy, stating: “Do not change any score or decision without a judge''s confirmation.” 3:30 PM — secretary replies that a revision printed under her account but no new signed judge decision has been received, so the signed original will not be replaced. Archive confirms messages and timestamps but not who physically changed the document.',11),
('LOG04','L',3,'Judge''s Confirmation Record','Judges'' decision register and interview','Judge Leena confirms she signed the original tie-break note at 3:10 PM. No later tie-break change is entered. She did not authorise a replacement decision and did not sign the revision. The replacement contains no judge initials or signature.',12),
('LOG04','M',3,'Results Desk Incident Note','Secretary''s note at 3:43 PM','Original was present at handover; missing at 3:40; replacement had different tie-break and no judge signature. Devika had the results-desk account and badge R-14; badge recorded corridor entry at 3:23; account print at 3:28. She said rain kept her at loading bay until 3:40, while the station shows rain stopped at 3:16. The note records observations and follow-up, not proof of guilt.',13) on conflict (case_id,evidence_id) do update set phase_number=excluded.phase_number,title=excluded.title,source_label=excluded.source_label,body_markdown=excluded.body_markdown,sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id,task_id,phase_number,task_number,prompt_markdown,task_type,max_points,correct_option_key,hint_rewards,wrong_answer_penalty) values
('LOG04','T1',1,1,'What does the weather record establish about Devika''s claim that heavy rain kept her at the loading bay until nearly 3:40 PM?','single_choice',10,'B',ARRAY[10,8,6,4,2]::integer[],2),
('LOG04','T2',1,2,'Which conclusion is supported by the access log at this stage?','single_choice',10,'A',ARRAY[10,8,6,4,2]::integer[],2),
('LOG04','T3',2,3,'What is the strongest conclusion from the original and replacement summaries?','single_choice',10,'B',ARRAY[10,8,6,4,2]::integer[],2),
('LOG04','T4',2,4,'What does the printer audit establish about the 3:28 PM replacement?','single_choice',10,'A',ARRAY[10,8,6,4,2]::integer[],2),
('LOG04','T5',3,5,'Which evidence most directly undermines Devika''s alibi without overclaiming what a single record proves?','single_choice',10,'A',ARRAY[10,8,6,4,2]::integer[],2),
('LOG04','T6',3,6,'Which explanation best accounts for the changed summary and the full evidence set?','single_choice',10,'C',ARRAY[10,8,6,4,2]::integer[],2) on conflict (case_id,task_id) do update set phase_number=excluded.phase_number,task_number=excluded.task_number,prompt_markdown=excluded.prompt_markdown,max_points=excluded.max_points,correct_option_key=excluded.correct_option_key,hint_rewards=excluded.hint_rewards,wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id,task_id,option_key,option_text,sort_order) values
('LOG04','T1','A','It proves she was inside the judges'' office at 3:23 PM.',1),
('LOG04','T1','B','It contradicts the claim that heavy rain continued until 3:40 PM, but weather alone does not establish where she was.',2),
('LOG04','T1','C','It proves no one could enter the building.',3),
('LOG04','T1','D','It proves Devika is guilty without any other evidence.',4),
('LOG04','T2','A','Devika''s badge was granted entry at 3:23 PM, but the swipe alone does not identify the person carrying it.',1),
('LOG04','T2','B','Arjun entered the corridor at 3:19 PM.',2),
('LOG04','T2','C','Isha entered the corridor at 3:27 PM.',3),
('LOG04','T2','D','The original summary was definitely removed at 3:23 PM.',4),
('LOG04','T3','A','The replacement changed the total points and the tie-break.',1),
('LOG04','T3','B','The replacement changed the tie-break result while keeping the total points the same.',2),
('LOG04','T3','C','The judges officially approved Team Meridian after 3:28 PM.',3),
('LOG04','T3','D','The printer audit proves Devika personally collected the page.',4),
('LOG04','T4','A','The D.RAO account printed the revision at 3:28 PM; the audit alone does not identify the person who operated or collected it.',1),
('LOG04','T4','B','Devika was certainly standing at the printer.',2),
('LOG04','T4','C','Isha printed the replacement at 3:28 PM.',3),
('LOG04','T4','D','The replacement must be authentic because the printer completed the job.',4),
('LOG04','T5','A','The rain stopped at 3:16, and her badge recorded a successful corridor entry at 3:23; together these conflict with her account, although each record has limits.',1),
('LOG04','T5','B','The weather station proves she was inside the office.',2),
('LOG04','T5','C','The badge log proves with certainty that no one could have borrowed her badge.',3),
('LOG04','T5','D','The maintenance ticket proves Devika was at the loading bay all afternoon.',4),
('LOG04','T6','A','Arjun accidentally printed a new sheet during rehearsal, and the judges silently approved it.',1),
('LOG04','T6','B','Isha changed the tie-break because she printed a badge after 3:28 PM.',2),
('LOG04','T6','C','Devika used the results workflow to produce an unauthorised replacement tie-break summary; her corridor badge entry, account print, contradicted alibi and lack of judge approval converge on her, while no single log is treated as conclusive alone.',3),
('LOG04','T6','D','Kabir entered the judges'' corridor despite the denied-access record and changed the sheet, with no supporting evidence.',4) on conflict (case_id,task_id,option_key) do update set option_text=excluded.option_text,sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id,task_id,hint_number,hint_text) values
('LOG04','T1',1,'Treat the weather station as evidence about conditions, not a person.'),
('LOG04','T1',2,'Rainfall reached zero at 3:16 PM.'),
('LOG04','T1',3,'The alibi says heavy rain continued until nearly 3:40 PM.'),
('LOG04','T1',4,'The weather conflicts with the claimed reason for remaining at the bay, but does not locate Devika.'),
('LOG04','T1',5,'Choose the option that states both the contradiction and the limitation.'),
('LOG04','T2',1,'Read the result column carefully.'),
('LOG04','T2',2,'Only one listed swipe is granted at 3:23 PM.'),
('LOG04','T2',3,'The record identifies badge R-14, not a face.'),
('LOG04','T2',4,'A successful swipe is not a timestamp for the document removal itself.'),
('LOG04','T2',5,'Choose the option that states exactly what the log proves and what it does not.'),
('LOG04','T3',1,'Compare the total and tie-break separately.'),
('LOG04','T3',2,'The total points are explicitly unchanged.'),
('LOG04','T3',3,'The named tie-break winner changes from Northstar to Meridian.'),
('LOG04','T3',4,'No later judge decision is recorded.'),
('LOG04','T3',5,'Choose the option that describes only the documented change.'),
('LOG04','T4',1,'The audit has an account field and a job field.'),
('LOG04','T4',2,'The 3:28 job is under D.RAO.'),
('LOG04','T4',3,'Account attribution is not the same as physical-person identification.'),
('LOG04','T4',4,'Completion confirms printing, not approval.'),
('LOG04','T4',5,'Choose the option with the right boundary on the evidence.'),
('LOG04','T5',1,'Use two independent records rather than one.'),
('LOG04','T5',2,'The rain record contradicts the claimed weather condition.'),
('LOG04','T5',3,'The corridor reader records a granted R-14 swipe at 3:23.'),
('LOG04','T5',4,'Neither record alone proves who carried the badge or where Devika stood.'),
('LOG04','T5',5,'Choose the answer that combines the evidence while preserving its limitations.'),
('LOG04','T6',1,'Identify who is connected to both the corridor entry and the revision print.'),
('LOG04','T6',2,'The replacement changed the decision but has no judge signature.'),
('LOG04','T6',3,'The weather contradiction weakens Devika''s stated location.'),
('LOG04','T6',4,'The records converge on the same person, while each has a stated limitation.'),
('LOG04','T6',5,'Choose the explanation that accounts for the complete record without inventing judge approval.') on conflict (case_id,task_id,hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id,responsible_person_points,correct_character_id,explanation_points,correct_explanation_key,wrong_answer_penalty,components_graded_independently) values ('LOG04',25,'devika_rao',15,'B',2,true) on conflict (case_id) do update set responsible_person_points=excluded.responsible_person_points,correct_character_id=excluded.correct_character_id,explanation_points=excluded.explanation_points,correct_explanation_key=excluded.correct_explanation_key,wrong_answer_penalty=excluded.wrong_answer_penalty,components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id,character_id,sort_order) values
('LOG04','devika_rao',1),
('LOG04','arjun_mehta',2),
('LOG04','farah_khan',3),
('LOG04','nikhil_verma',4),
('LOG04','isha_reddy',5),
('LOG04','kabir_shah',6) on conflict (case_id,character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id,option_key,option_text,sort_order) values
('LOG04','A','Devika accidentally printed an old copy; the judges approved the new tie-break later.',1),
('LOG04','B','Devika knowingly introduced an unsigned replacement tie-break summary without a new judge decision, and used the rain-based alibi to distance herself from the corridor and revision window.',2),
('LOG04','C','Farah removed the original during delivery, and the weather record proves she did it.',3),
('LOG04','D','Kabir altered the result from the public waiting area.',4) on conflict (case_id,option_key) do update set option_text=excluded.option_text,sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id,gate_key,gate_status,notes) values
('LOG04','independent_story_logic_review','pending','Second author must solve from player evidence alone.'),
('LOG04','evidence_fairness_review','pending','Check for alternate plausible culprit and ambiguous options.'),
('LOG04','seed_execution_in_staging','pending','Execute seed and verification SQL in a staging Supabase project.'),
('LOG04','answer_key_secrecy','pending','Verify no client endpoint exposes correct keys or restricted manifest.'),
('LOG04','phase_unlock_test','pending','Verify evidence is returned only for assigned case and unlocked phase.'),
('LOG04','two_player_shared_state_test','pending','Test concurrent duo clients and idempotent scoring.'),
('LOG04','first_time_duo_playtests','pending','Run at least two first-time duo playtests; target 15–20 minutes.'),
('LOG04','live_release','fail','Blocked until all required gates pass.') on conflict (case_id,gate_key) do update set gate_status=excluded.gate_status,notes=excluded.notes;

commit;
