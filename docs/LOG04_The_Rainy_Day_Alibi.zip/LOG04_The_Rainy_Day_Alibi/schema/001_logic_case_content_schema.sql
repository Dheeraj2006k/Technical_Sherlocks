-- Sherlock's Last Case — shared Logic-track content schema
-- PostgreSQL / Supabase. Run once in the target project.
-- Answer keys and content tables intentionally have no client-facing RLS policies.

create table if not exists public.logic_case_catalog (
  case_id text primary key check (case_id ~ '^LOG[0-9]{2}$'),
  title text not null,
  track text not null default 'LOGIC' check (track = 'LOGIC'),
  content_version text not null,
  recommended_team_size smallint not null check (recommended_team_size between 1 and 3),
  release_status text not null default 'draft',
  core_mechanism text,
  max_score integer not null default 100 check (max_score = 100),
  scoring_config jsonb not null,
  source_manifest jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.logic_case_phases (
  case_id text not null references public.logic_case_catalog(case_id) on delete cascade,
  phase_number smallint not null check (phase_number between 1 and 3),
  phase_name text not null,
  primary key (case_id, phase_number)
);

create table if not exists public.logic_case_characters (
  case_id text not null references public.logic_case_catalog(case_id) on delete cascade,
  character_id text not null,
  display_name text not null,
  role text not null,
  sort_order smallint not null,
  primary key (case_id, character_id),
  unique (case_id, sort_order)
);

create table if not exists public.logic_case_evidence (
  case_id text not null,
  evidence_id text not null,
  phase_number smallint not null,
  title text not null,
  source_label text,
  body_markdown text not null,
  sort_order smallint not null,
  primary key (case_id, evidence_id),
  foreign key (case_id, phase_number) references public.logic_case_phases(case_id, phase_number) on delete cascade,
  unique (case_id, phase_number, sort_order)
);

create table if not exists public.logic_case_tasks (
  case_id text not null,
  task_id text not null,
  phase_number smallint not null,
  task_number smallint not null,
  prompt_markdown text not null,
  task_type text not null default 'single_choice' check (task_type in ('single_choice')),
  max_points smallint not null check (max_points >= 0),
  correct_option_key text not null check (correct_option_key in ('A','B','C','D')),
  hint_rewards integer[] not null,
  wrong_answer_penalty smallint not null default 2 check (wrong_answer_penalty >= 0),
  primary key (case_id, task_id),
  foreign key (case_id, phase_number) references public.logic_case_phases(case_id, phase_number) on delete cascade,
  unique (case_id, task_number),
  check (cardinality(hint_rewards) >= 1),
  check (hint_rewards[1] <= max_points)
);

create table if not exists public.logic_case_task_options (
  case_id text not null,
  task_id text not null,
  option_key text not null check (option_key in ('A','B','C','D')),
  option_text text not null,
  sort_order smallint not null,
  primary key (case_id, task_id, option_key),
  foreign key (case_id, task_id) references public.logic_case_tasks(case_id, task_id) on delete cascade,
  unique (case_id, task_id, sort_order)
);

create table if not exists public.logic_case_task_hints (
  case_id text not null,
  task_id text not null,
  hint_number smallint not null check (hint_number between 1 and 5),
  hint_text text not null,
  primary key (case_id, task_id, hint_number),
  foreign key (case_id, task_id) references public.logic_case_tasks(case_id, task_id) on delete cascade
);

create table if not exists public.logic_case_final_deductions (
  case_id text primary key references public.logic_case_catalog(case_id) on delete cascade,
  responsible_person_points smallint not null,
  correct_character_id text not null,
  explanation_points smallint not null,
  correct_explanation_key text not null check (correct_explanation_key in ('A','B','C','D')),
  wrong_answer_penalty smallint not null default 2,
  components_graded_independently boolean not null default true,
  foreign key (case_id, correct_character_id) references public.logic_case_characters(case_id, character_id),
  check (responsible_person_points + explanation_points <= 100)
);

create table if not exists public.logic_case_final_person_options (
  case_id text not null,
  character_id text not null,
  sort_order smallint not null,
  primary key (case_id, character_id),
  foreign key (case_id, character_id) references public.logic_case_characters(case_id, character_id) on delete cascade,
  unique (case_id, sort_order)
);

create table if not exists public.logic_case_final_explanation_options (
  case_id text not null references public.logic_case_catalog(case_id) on delete cascade,
  option_key text not null check (option_key in ('A','B','C','D')),
  option_text text not null,
  sort_order smallint not null,
  primary key (case_id, option_key),
  unique (case_id, sort_order)
);

create table if not exists public.logic_case_release_gates (
  case_id text not null references public.logic_case_catalog(case_id) on delete cascade,
  gate_key text not null,
  gate_status text not null check (gate_status in ('pass','pending','fail','not_applicable')),
  notes text not null default '',
  primary key (case_id, gate_key)
);

-- Lock all content tables away from browser roles. Use trusted server endpoints/RPCs
-- after checking team assignment and phase. Never send answer-key columns to clients.
do $$ declare t text; begin
  foreach t in array array['logic_case_catalog','logic_case_phases','logic_case_characters','logic_case_evidence','logic_case_tasks','logic_case_task_options','logic_case_task_hints','logic_case_final_deductions','logic_case_final_person_options','logic_case_final_explanation_options','logic_case_release_gates'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on table public.%I from anon, authenticated', t);
  end loop;
end $$;
