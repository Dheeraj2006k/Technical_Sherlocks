# LOG04 — Validation Checklist

## Content integrity
- [ ] Independent reviewer solves the case using only released evidence.
- [ ] Independent reviewer finds no plausible alternate answer better supported than Devika.
- [ ] All times and records are consistent across player case, manifest and seed.
- [ ] No task requires identifying the badge carrier or printer operator beyond what records prove.
- [ ] Each red herring has an evidence-backed innocent explanation.
- [ ] Player-facing wording and reading level tested with first-time duo participants.

## Database
- [ ] Run shared Logic content schema in staging.
- [ ] Run `seed_LOG04.sql` twice; second run is idempotent.
- [ ] Run `verify_LOG04.sql`; no missing options, phases, hints, final-person options or broken references.
- [ ] Confirm task reward ladder and max-score totals equal 100.
- [ ] Confirm content tables are not directly readable by `anon` or `authenticated`.
- [ ] Confirm server responses never include correct-option fields, final answer keys, or restricted manifest JSON.
- [ ] Confirm evidence is filtered by assigned case and unlocked phase server-side.

## Runtime/security
- [ ] Team assignment enforced on every evidence/task endpoint.
- [ ] Phase unlock checks run server-side.
- [ ] Attempts and completions are separate; retries cannot double-award points.
- [ ] Idempotency keys prevent duplicate submissions.
- [ ] Shared duo state updates correctly from two clients.
- [ ] Query/access logs do not include credentials or session tokens.

## Live release
- [ ] Two first-time duo playtests completed; target completion 15–20 minutes.
- [ ] No confusing wording or unexpected alternate solutions observed.
- [ ] Organiser-approved content version pinned to assigned sessions.
- [ ] `release_status` changed from draft only after all required gates pass.
