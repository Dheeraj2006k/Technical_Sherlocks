# LOG04 — Scoring and Hints (Restricted)

## Score allocation
- T1–T6: 10 points each = 60.
- Correct responsible person: 25 points.
- Correct explanation: 15 points.
- Maximum: 100.
- Wrong committed answer: −2 points; total score never below 0.
- Final person and explanation are graded independently and can be retried.
- A task/component awards its success points only once. Attempts must be stored separately from completion records.

## Hint reward ladder
For each ordinary task, the award is 10, 8, 6, 4, or 2 points for 0, 1, 2, 3, or 4+ hints used. The fifth hint is a final nudge; it does not lower the reward below 2. Hints are shared by the team. A hint counter and answer key must be enforced server-side.

## Correct task answers
- T1 B
- T2 A
- T3 B
- T4 A
- T5 A
- T6 C
- Final person: `devika_rao`
- Final explanation: B

## Final explanation options
A. Devika accidentally printed an old copy; the judges approved the new tie-break later.
B. Devika knowingly introduced an unsigned replacement tie-break summary without a new judge decision, and used the rain-based alibi to distance herself from the corridor and revision window.
C. Farah removed the original during delivery, and the weather record proves she did it.
D. Kabir altered the result from the public waiting area.
