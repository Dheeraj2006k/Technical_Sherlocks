# LOG04 — The Rainy-Day Alibi
## Player-facing case file — Duo Edition

**Track:** Logic | **Recommended team size:** 2 | **Content version:** 1.0.0

> Fictional case. All people, timestamps, event logs and records are invented for this investigation.

## Incident briefing

At the QUBIT Innovation Showcase, the original signed judging summary for the **Aster** prototype category disappeared from the judges' office between 3:15 PM and 3:40 PM. The judges had already agreed on the winner, but the summary sheet contained the signed tie-break decision needed to publish the result. A replacement summary appeared in the event folder at 3:42 PM with a different tie-break note. The judges paused the announcement while the records were checked.

The office corridor had a single badge-controlled entrance. Several staff members had reasons to be nearby. One person says the heavy rain kept them at the covered loading bay throughout the relevant period. The weather records, access records and ordinary event paperwork do not all tell the same story.

Your task is to determine who replaced the summary, and which explanation best accounts for the evidence. Do not assume that being near a room proves someone entered it, or that one inconsistent statement automatically proves guilt.

## People involved

### 1. Devika Rao — Results coordinator
Prepared the result packet and handled the final score summary. She says she was stuck at the covered loading bay during the rain and did not enter the judges' corridor after 3:10 PM.

### 2. Arjun Mehta — Stage manager
Managed stage timing and says he was on the main stage rehearsing the award announcement from 3:18 to 3:36 PM.

### 3. Farah Khan — Judge liaison
Carried documents between the judges and the event office. She says she delivered the original signed summary to the judges' office at 3:12 PM and did not retrieve it afterward.

### 4. Nikhil Verma — AV technician
Worked near the loading bay and checked a power distribution unit after rainwater was reported near the outer cable cover.

### 5. Isha Reddy — Registration lead
Managed the registration desk and used the office printer for badge reprints. She says she did not enter the judges' corridor that afternoon.

### 6. Kabir Shah — Student team representative
Had challenged the preliminary tie-break result on behalf of his team. He says he remained in the public waiting area and did not have staff access.

---

# Phase 1 — The Alibi

## Evidence A — Rainfall Station Record
**Source:** Venue's covered loading-bay weather station

| Time | Rain intensity | Notes |
|---|---:|---|
| 2:55 PM | 11 mm/hour | Heavy rain |
| 3:05 PM | 8 mm/hour | Rain easing |
| 3:12 PM | 3 mm/hour | Light rain |
| 3:16 PM | 0 mm/hour | Rain stopped at the station |
| 3:25 PM | 0 mm/hour | Dry interval |
| 3:35 PM | 0 mm/hour | Dry interval |

The station clock is synchronised to the venue time server. This record establishes conditions at the loading bay, not the location of any individual.

## Evidence B — Devika's Statement
**Source:** First interview, 3:50 PM

Devika says: *“I was at the covered loading bay from about 3:15 until nearly 3:40. The rain was too heavy for me to cross over, and I never went into the judges' corridor after 3:10.”*

She says she had her staff badge with her and did not lend it to anyone. She adds that she only returned to the results desk after the announcement was paused.

## Evidence C — Staff Access Log
**Source:** Badge reader at the judges' corridor

| Time | Badge | Result |
|---|---|---|
| 3:08 PM | Devika Rao — R-14 | Entry granted |
| 3:12 PM | Farah Khan — F-02 | Entry granted |
| 3:19 PM | Arjun Mehta — A-11 | Access denied |
| 3:23 PM | Devika Rao — R-14 | Entry granted |
| 3:27 PM | Isha Reddy — I-07 | Access denied |
| 3:31 PM | Nikhil Verma — N-09 | Access denied |

The system records the badge presented at the reader. By itself, a successful swipe does not prove who physically carried the badge.

## Evidence D — Original Document Handover
**Source:** Judges' office handover register

- 3:12 PM — Farah records delivery of the original signed Aster judging summary to the judges' office.
- 3:14 PM — Judge Leena signs the register acknowledging receipt.
- 3:40 PM — Judge Leena reports the original summary missing from the red folder.
- 3:42 PM — A replacement summary is found in the event results folder.

The handover register does not say who last touched the folder after 3:14 PM.

### Investigation Task 1
**What does the weather record establish about Devika's claim that heavy rain kept her at the loading bay until nearly 3:40 PM?**

A. It proves she was inside the judges' office at 3:23 PM.  
B. It contradicts the claim that heavy rain continued until 3:40 PM, but weather alone does not establish where she was.  
C. It proves no one could enter the building.  
D. It proves Devika is guilty without any other evidence.

### Investigation Task 2
**Which conclusion is supported by the access log at this stage?**

A. Devika's badge was granted entry at 3:23 PM, but the swipe alone does not identify the person carrying it.  
B. Arjun entered the corridor at 3:19 PM.  
C. Isha entered the corridor at 3:27 PM.  
D. The original summary was definitely removed at 3:23 PM.

---

# Phase 2 — The Record Changes

## Evidence E — Judges' Folder Inventory
**Source:** Inventory signed by Judge Leena at 3:14 PM; compared with the 3:40 PM check

| Item | At 3:14 PM | At 3:40 PM |
|---|---|---|
| Original signed Aster summary | Present in red folder | Missing |
| Blue scoring worksheets | Present | Present |
| Judge's handwritten tie-break note | Clipped behind summary | Still clipped behind a blank divider |
| Red folder seal | Intact, numbered S-208 | Seal S-208 cut; replacement tape applied |

Judge Leena says she did not authorise anyone to open the folder after signing the handover register.

## Evidence F — Replacement Summary Comparison
**Source:** Original scan and replacement scan, compared by the event secretary

- The original scan shows **Team Northstar** ahead on the signed tie-break note.
- The replacement summary names **Team Meridian** as the tie-break winner.
- The replacement has the same total points as the original; only the tie-break decision is different.
- The replacement's footer says “Printed 3:28 PM — Results Desk — User: D.RAO”.
- The printer audit identifies the job as a print from the results-desk account. A logged-in account identifies the account used, not necessarily the person at the printer.

## Evidence G — Results Desk Printer Audit
**Source:** Managed printer log

| Time | Account | Job | Pages | Status |
|---|---|---|---:|---|
| 3:06 PM | D.RAO | Aster_summary_original.pdf | 1 | Completed |
| 3:28 PM | D.RAO | Aster_summary_revision.pdf | 1 | Completed |
| 3:29 PM | I.REDDY | Badge_reprint_17.pdf | 1 | Completed |
| 3:34 PM | D.RAO | Aster_summary_revision.pdf | 1 | Cancelled |

The audit records account and job status. It does not record who physically collected each page.

## Evidence H — Stage Rehearsal Log
**Source:** Stage manager's run sheet and AV cue timestamps

- 3:18 PM — Arjun begins the award-announcement rehearsal on the main stage.
- 3:21 PM — First microphone cue recorded.
- 3:26 PM — Second microphone cue recorded.
- 3:32 PM — Final timing cue recorded.
- 3:36 PM — Rehearsal ends.

The log supports Arjun being occupied on stage during much of the relevant interval, but it does not independently prove that he could not briefly leave the stage.

### Investigation Task 3
**What is the strongest conclusion from the original and replacement summaries?**

A. The replacement changed the total points and the tie-break.  
B. The replacement changed the tie-break result while keeping the total points the same.  
C. The judges officially approved Team Meridian after 3:28 PM.  
D. The printer audit proves Devika personally collected the page.

### Investigation Task 4
**What does the printer audit establish about the 3:28 PM replacement?**

A. The D.RAO account printed the revision at 3:28 PM; the audit alone does not identify the person who operated or collected it.  
B. Devika was certainly standing at the printer.  
C. Isha printed the replacement at 3:28 PM.  
D. The replacement must be authentic because the printer completed the job.

---

# Phase 3 — The Contradiction

## Evidence I — Badge Custody Check
**Source:** Staff badge issue and return register

- Devika checked out badge R-14 at 8:42 AM and signed that it would remain in her possession.
- At 3:45 PM, the event lead asked whether Devika had lent R-14 to another staff member. Devika answered, “No. It was clipped to my lanyard all afternoon.”
- No replacement badge or temporary transfer for R-14 is recorded.
- The lanyard was photographed during the 3:50 PM interview; R-14 is visible on it.

The photo establishes where the badge was at 3:50 PM, not where it was at 3:23 PM. The custody register and Devika's statement are relevant but should be evaluated with the other records.

## Evidence J — Loading-Bay Service Ticket
**Source:** Nikhil's signed maintenance ticket

- 3:17 PM — Nikhil begins checking the outer cable cover after a report of water near the walkway.
- 3:22 PM — He records the walkway as passable and the cable cover dry.
- 3:24 PM — Nikhil photographs the cleared walkway. The photograph's timestamp is verified by the venue media system; no person is identifiable in the frame.
- 3:29 PM — Nikhil returns the maintenance kit.

Nikhil says he did not see Devika at the loading bay during his check. He does not claim that she was absent for the entire period.

## Evidence K — Results Revision Request
**Source:** Results desk email archive

At 3:04 PM, Devika sent the event secretary this message:

*“Please prepare a clean copy of the Aster summary. The tie-break note is messy and I need the final sheet ready before the announcement. Do not change any score or decision without a judge's confirmation.”*

At 3:30 PM, the secretary replied:

*“I see a revision printed under your account. I have not received a new signed decision from the judges, so I will not replace the signed original with it.”*

The archive confirms the messages and timestamps. It does not, by itself, prove who physically changed the document.

## Evidence L — Judge's Confirmation Record
**Source:** Judges' decision register and interview

- Judge Leena confirms she signed the original tie-break note at 3:10 PM.
- No later tie-break change is entered in the decision register.
- Judge Leena says she did not authorise a replacement decision and did not sign the revision.
- The replacement summary contains no judge's initials or signature.

## Evidence M — Results Desk Incident Note
**Source:** Event secretary's contemporaneous note, written at 3:43 PM

*“Original in folder at handover; folder checked at 3:40 and original gone. Replacement had different tie-break, no judge signature. Devika had results-desk account and badge R-14; her badge recorded corridor entry at 3:23. Account print at 3:28. She said she remained at loading bay until 3:40 due to heavy rain. Station shows rain stopped 3:16. Need preserve original scan and access/print logs.”*

The note records the secretary's observations and next steps; it is not itself proof of guilt.

### Investigation Task 5
**Which evidence most directly undermines Devika's alibi without overclaiming what a single record proves?**

A. The rain stopped at 3:16, and her badge recorded a successful corridor entry at 3:23; together these conflict with her account, although each record has limits.  
B. The weather station proves she was inside the office.  
C. The badge log proves with certainty that no one could have borrowed her badge.  
D. The maintenance ticket proves Devika was at the loading bay all afternoon.

### Investigation Task 6
**Which explanation best accounts for the changed summary and the full evidence set?**

A. Arjun accidentally printed a new sheet during rehearsal, and the judges silently approved it.  
B. Isha changed the tie-break because she printed a badge after 3:28 PM.  
C. Devika used the results workflow to produce an unauthorised replacement tie-break summary; her corridor badge entry, account print, contradicted alibi and lack of judge approval converge on her, while no single log is treated as conclusive alone.  
D. Kabir entered the judges' corridor despite the denied-access record and changed the sheet, with no supporting evidence.

---

# Final deduction

Submit both components. Each is graded independently.

## Final component 1 — Who was responsible?
Choose one person:
- Devika Rao
- Arjun Mehta
- Farah Khan
- Nikhil Verma
- Isha Reddy
- Kabir Shah

## Final component 2 — Which explanation best fits?

A. Devika accidentally printed an old copy; the judges approved the new tie-break later.  
B. Devika knowingly introduced an unsigned replacement tie-break summary without a new judge decision, and used the rain-based alibi to distance herself from the corridor and revision window.  
C. Farah removed the original during delivery, and the weather record proves she did it.  
D. Kabir altered the result from the public waiting area.

## What counts as a fair solution?
A strong solution distinguishes **corroboration from certainty**. The rainfall record alone does not locate Devika; the badge log alone does not identify the badge carrier; the printer account alone does not identify the operator. The conclusion comes from the records converging: a contradicted alibi, a successful corridor entry on her badge, a revision printed under her account, a changed tie-break, and no later judge authorisation.
