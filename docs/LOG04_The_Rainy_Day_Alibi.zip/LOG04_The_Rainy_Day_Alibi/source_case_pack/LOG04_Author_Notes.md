# LOG04 — Restricted Author Notes

**Never expose this file, the manifest's answer keys, or the seed SQL to players.**

## Ground truth
Devika Rao is responsible. She knowingly introduced a replacement Aster tie-break summary naming Team Meridian without a new signed judge decision. Her stated motive is intentionally not over-specified: the evidence establishes unauthorized manipulation and an attempt to distance herself from the corridor/revision window, but does not prove a personal relationship or financial motive. Do not invent one in grading.

## Intended deduction chain
1. The rainfall station records zero rain from 3:16 onward, contradicting Devika's claim that heavy rain kept her at the loading bay until 3:40. It does not prove her location.
2. Badge R-14 assigned to Devika records granted corridor entry at 3:23. Badge logs do not prove the carrier alone.
3. A revision is printed under the D.RAO account at 3:28. Account logs do not prove the operator alone.
4. The replacement changes the tie-break, not the points, and has no judge signature. Judge Leena confirms no later authorization.
5. Devika denies entering the corridor and says she did not lend her badge. The badge custody register supports that she was expected to retain it; her statement and access record conflict.
6. The combination of contradicted alibi, corridor swipe, revision account, changed outcome and absent judge approval supports Devika over alternatives. No single evidence item should be treated as conclusive.

## Fairness and ambiguity controls
- Do not ask who physically carried badge R-14 as a separate graded question; records cannot independently establish this with absolute certainty.
- Do not ask who physically collected the print; the printer log does not establish that.
- The final explanation's wording should say evidence converges on Devika, not that one timestamp proves guilt.
- The replacement's unauthorized nature is clear from the signed decision register and judge interview.
- Arjun's rehearsal is corroborated but not an absolute continuous-location alibi; he is eliminated by the full evidence pattern, not by claiming he could never leave stage.
- Kabir has no recorded staff access; do not describe denied access as metaphysically impossible to bypass.
- Isha's badge reprint is a red herring explained by a separate printer job at 3:29.
- Nikhil's service ticket explains why he was near the loading bay and why his records do not place Devika there.
- Farah's 3:12 handover is independently acknowledged by Judge Leena.

## Scoring
Six investigation tasks × 10 max = 60. Each task's reward for 0–4 hints used is 10/8/6/4/2. Five hints are present; the reward ladder intentionally bottoms at 2 after four hints, and the fifth hint is the final nudge rather than a sixth reward step. This follows the current platform ladder and should be implemented as “hint count capped at 4 for reward” unless product owner changes it. Final person = 25; explanation = 15. Wrong committed answer penalty −2, each component graded independently; correct components award once. Score floor 0. Maximum total 100.

## Production caveat
This is a content-complete draft pack, not a claim of production certification. A second author must independently solve it, inspect every option for ambiguity, run the SQL against a staging Supabase project, confirm answer-key secrecy and phase filtering, and conduct two first-time duo playtests before live release. If testers can reasonably infer an alternate culprit, revise the evidence rather than adding author-only assumptions.
