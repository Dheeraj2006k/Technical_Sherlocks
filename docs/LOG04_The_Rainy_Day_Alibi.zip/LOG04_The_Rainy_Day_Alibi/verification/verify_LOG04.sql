-- Run after schema and seed_LOG04.sql. Expected: all integrity checks return zero rows,
-- task count 6, evidence count 13, phase count 3, total score 100, release gates pending/fail.
select 'catalog' as check_name, count(*) as actual, 1 as expected from public.logic_case_catalog where case_id='LOG04'
union all select 'phases',count(*),3 from public.logic_case_phases where case_id='LOG04'
union all select 'characters',count(*),8 from public.logic_case_characters where case_id='LOG04'
union all select 'evidence',count(*),13 from public.logic_case_evidence where case_id='LOG04'
union all select 'tasks',count(*),6 from public.logic_case_tasks where case_id='LOG04'
union all select 'task_options',count(*),24 from public.logic_case_task_options where case_id='LOG04'
union all select 'task_hints',count(*),30 from public.logic_case_task_hints where case_id='LOG04'
union all select 'final_person_options',count(*),6 from public.logic_case_final_person_options where case_id='LOG04'
union all select 'final_explanation_options',count(*),4 from public.logic_case_final_explanation_options where case_id='LOG04';

-- Must return zero rows: each task needs exactly four options and five hints.
select t.task_id,
 (select count(*) from public.logic_case_task_options o where o.case_id=t.case_id and o.task_id=t.task_id) as option_count,
 (select count(*) from public.logic_case_task_hints h where h.case_id=t.case_id and h.task_id=t.task_id) as hint_count
from public.logic_case_tasks t
where t.case_id='LOG04'
 and ((select count(*) from public.logic_case_task_options o where o.case_id=t.case_id and o.task_id=t.task_id) <> 4
   or (select count(*) from public.logic_case_task_hints h where h.case_id=t.case_id and h.task_id=t.task_id) <> 5);

-- Must return zero rows: broken phase/task/evidence references or invalid correct-option references.
select 'task_phase' as issue, t.task_id as item_id from public.logic_case_tasks t
left join public.logic_case_phases p on p.case_id=t.case_id and p.phase_number=t.phase_number
where t.case_id='LOG04' and p.case_id is null
union all
select 'evidence_phase',e.evidence_id from public.logic_case_evidence e
left join public.logic_case_phases p on p.case_id=e.case_id and p.phase_number=e.phase_number
where e.case_id='LOG04' and p.case_id is null
union all
select 'correct_option_missing',t.task_id from public.logic_case_tasks t
left join public.logic_case_task_options o on o.case_id=t.case_id and o.task_id=t.task_id and o.option_key=t.correct_option_key
where t.case_id='LOG04' and o.option_key is null;

-- Expected one row, total 100.
select c.case_id, sum(t.max_points) as task_points,
 f.responsible_person_points, f.explanation_points,
 sum(t.max_points)+f.responsible_person_points+f.explanation_points as total_points
from public.logic_case_catalog c
join public.logic_case_tasks t on t.case_id=c.case_id
join public.logic_case_final_deductions f on f.case_id=c.case_id
where c.case_id='LOG04'
group by c.case_id,f.responsible_person_points,f.explanation_points;

-- Release gates must remain pending/fail until completed by the team. This query is informational.
select gate_key,gate_status,notes from public.logic_case_release_gates where case_id='LOG04' order by gate_key;
