# LOG04 — The Rainy-Day Alibi

**Logic track | Duo case | Content version 1.0.0**

## Files
- `source_case_pack/LOG04_Player_Case.md` — player-facing case.
- `source_case_pack/LOG04_Author_Notes.md` — restricted ground truth and reasoning.
- `source_case_pack/LOG04_Scoring_and_Hints.md` — restricted answer key and score allocation.
- `source_case_pack/LOG04_Case_Manifest.json` — structured metadata; contains restricted answer keys.
- `source_case_pack/LOG04_Validation_Checklist.md` — required release checks.
- `schema/001_logic_case_content_schema.sql` — copy of the shared Logic case-content schema for reference. It is not a case-specific schema and should be run only once per project.
- `seeds/seed_LOG04.sql` — exact idempotent case-content seed.
- `verification/verify_LOG04.sql` — counts, relationships, answer-option and scoring checks.

## Seed instructions
1. Use a Supabase development/staging project or branch.
2. If the shared Logic schema is not already installed, run `schema/001_logic_case_content_schema.sql` once. Do not rerun a modified schema against production without migration review.
3. Run `seeds/seed_LOG04.sql`.
4. Run `verification/verify_LOG04.sql`.
5. The seed is intended to be rerunnable. Review row counts and the release gates after each run.

## Architecture boundary
This pack seeds **case content only**. It does not create or alter runtime tables for team assignments, sessions, attempts, completions, score ledger, leaderboard, or admin actions. Those belong to the shared platform migrations and must not be duplicated per case.

## Security
- Run seed scripts with a trusted migration/admin role.
- The schema enables RLS and revokes `anon`/`authenticated` table access. Do not add public read policies to answer-key tables.
- Fetch player evidence through trusted server endpoints that verify assignment and phase unlocks.
- Never return `correct_option_key`, `correct_character_id`, `correct_explanation_key`, or restricted `source_manifest` to the browser.
- Do not use the Supabase service-role key in the browser.

## Release status
This is a database-complete authored pack, **not yet certified for live play**. Independent story review, staging SQL execution, API answer-key secrecy tests, phase-access tests, shared-state tests, and two first-time duo playtests are required. The seed records these gates as pending/fail; do not enable LOG04 for event teams until they pass.
