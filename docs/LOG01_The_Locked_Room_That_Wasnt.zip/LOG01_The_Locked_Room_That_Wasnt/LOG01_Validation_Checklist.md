# LOG01 — Validation Checklist

Use this checklist before converting the prototype into production seed data.

## Story and evidence
- [ ] Add an independent, time-bounded clue strengthening the link between Vikram and the physical substitution.
- [ ] Define which people could enter Innovation Room B between 4:07 and 4:20.
- [ ] Clarify how the 4:16 sweep and 4:18 photograph can occur before the 4:20 closure.
- [ ] Make the reason a fake security incident benefits Vikram plausible and evidence-backed.
- [ ] Ensure every innocent suspect has a fair, evidence-based alternative explanation.
- [ ] Ensure no single clue makes the final answer obvious before Phase 3.
- [ ] Ensure Phase 3 reinterprets at least two Phase 1 clues.
- [ ] Verify all timestamps and records agree.

## Task quality
- [ ] Review Q2 and Q3 for deterministic grading; they currently ask for best-supported judgment.
- [ ] Confirm every multiple-choice distractor is clearly inferior using only currently unlocked evidence.
- [ ] Ensure hints narrow the reasoning without giving away the answer too early.
- [ ] Ensure every task has exactly one accepted answer.
- [ ] Test solo completion and team-shared progress.

## Scoring
- [ ] Reconcile the proposed five-point task ladder with the global scoring model.
- [ ] Confirm the base score totals exactly 100.
- [ ] Confirm each wrong committed answer applies -2 exactly once per attempt.
- [ ] Confirm successful components award points once only.
- [ ] Confirm score floor is zero.

## Security and implementation
- [ ] Keep answer keys and author notes server-side.
- [ ] Seed only currently unlocked evidence for the active phase.
- [ ] Validate phase unlocks on the server.
- [ ] Use idempotency keys for submissions.
- [ ] Ensure hidden future-phase evidence is not retrievable through API calls.
- [ ] Test reset/recovery without losing or duplicating score.

## Playtest
- [ ] Run a first-time solo playtest.
- [ ] Run a 2–3 person team playtest.
- [ ] Record completion time per phase.
- [ ] Ask testers to explain why Rohan is plausible but not proven guilty.
- [ ] Ask testers to explain exactly how the 4:18 photograph changes the theory.
- [ ] Ask testers to distinguish supporting evidence from direct proof.
- [ ] Confirm the final answer is reached by reconstruction rather than guessing.
