# LOG01 — Author Notes (Restricted)

**Status:** Prototype draft, not seed-ready.  
**Correct final deduction:** Vikram Sethi + Final Explanation C.

## 1. Ground truth

Vikram removed the working Aster prototype from Innovation Room B at 4:12 PM while the room was still open for event preparation. He put a nonfunctional display replica in its place, then allowed the normal closing process to continue.

Aster had failed a rehearsal check. Vikram feared the demonstration would collapse, the showcase schedule would be disrupted, and his failure to report the issue would be exposed. Instead of disclosing the fault, he staged the appearance of a theft to create a reason to postpone the demonstration.

The room did not need to be entered after it was locked. The genuine prototype had already been removed.

## 2. Intended player journey

1. **Initial suspicion:** Rohan appears plausible due to rivalry and proximity.
2. **First correction:** The closure log records when the room was reported closed; it does not prove the genuine object was present at that time.
3. **Identity twist:** The object in the 4:18 photograph is a replica.
4. **Timeline twist:** The substitution predates the 4:20 closure.
5. **Alternative lead:** Rohan's account links Vikram to a black case, but the case contents are initially unknown.
6. **Motive/context:** Vikram receives the failure warning and drafts a security-related delay before the missing prototype is reported.
7. **Convergence:** The photograph, schedule draft, equipment register, case insert and witness timeline jointly support Vikram's responsibility.
8. **Final reconstruction:** Vikram removed Aster before closure and substituted the replica to create a security-related delay.

## 3. Twist map

### Twist 1 — The obvious suspect is not enough
Rohan has a real rivalry and gives a misleading initial account. Neither fact proves he removed Aster.

### Twist 2 — The display is a convincing lie
The replica shares the outer shell but lacks the genuine device's blue inspection mark and transparent indicator lens.

### Twist 3 — The timeline is wrong
The case is initially framed as a locked-room theft. The replica's presence at 4:18, before the 4:20 closure, undermines that premise.

### Twist 4 — The schedule draft changes the interpretation
Vikram drafts a security-related delay at 4:14, before the loss is reported. In combination with his knowledge of the failed rehearsal and the case evidence, this supports the staged-delay theory.

## 4. Suspect assessment

- **Rohan:** Has motive and is nearby; first account is misleading. His sighting of Vikram with the case is corroborated by the checkout record. No evidence places him making the substitution.
- **Naina:** Took the key photograph, but her photograph documents the replica rather than proving she placed it.
- **Imran:** Had maintenance access, but the documented work occurred earlier. No evidence connects his repair to the later substitution.
- **Devika:** Her checklist verified visual completeness, not object identity. This is a procedural failure, not evidence of theft.
- **Aditya:** Knew about the failed output check and created the prototype. He did not authorize a swap; the current draft does not establish a direct physical link between him and the substitution.
- **Vikram:** Received the failure warning, checked out the case, was seen carrying it, drafted a security-related delay before the report, and the replica was present before closure. The totality of evidence supports the intended answer.

## 5. Evidence-to-solution map

| Conclusion | Evidence |
|---|---|
| The object in the later photograph is a replica | E, F, M |
| The substitution occurred before room closure | F and closure log A |
| Rohan's motive does not establish guilt | B, G, H |
| Vikram knew about the failed prototype | D, J |
| Vikram prepared for a security-related delay before the report | K and 4:30 report time |
| The case is relevant but not conclusive | H, L |
| The room did not need to be entered after lockup | F and A |
| Vikram is the best-supported responsible person | J, K, H, L, M, N considered together |

## 6. Current weaknesses to resolve before seeding

### Gap A — Physical link between Vikram and the swap
The evidence supports a strong inference but does not directly establish who physically put the replica in the case. Add one independent, time-bounded clue that strengthens this link without becoming a confession or making the answer trivial. Possible design directions: a neutral staff observation of a distinctive case movement; a controlled access/checkout record; or a photo detail that establishes who was at the display at the critical moment. Ensure the clue is not merely another statement from a witness already aligned with the theory.

### Gap B — Opportunity boundaries for innocent suspects
The current evidence says no one is documented inside during the critical window, but absence from records is not the same as proof of absence. Define the room's actual access conditions and each suspect's relevant opportunity using fair, independently supported evidence. Do not make a suspect innocent solely because the case author says so.

### Gap C — Timing clarity
The incident premise says the room is closed at 4:20, but a 4:16 final sweep begins and a 4:18 photograph is taken. Clarify whether the room remains accessible to authorized staff during the sweep and who can be present. Avoid an accidental contradiction.

### Gap D — Motive and causal story
The failure warning explains pressure, but the author should decide precisely why a fake security incident would benefit Vikram. The explanation should be plausible and evidence-backed, not just an asserted motive.

### Gap E — Question design
Question 2 asks for the strongest *apparent* motive and Question 3 asks for the best next step. These are judgment questions, not objectively unique factual questions. If grading automatically, author accepted reasoning and ensure distractors are clearly inferior from the evidence available at that phase.

## 7. Player-facing information policy

Never expose:
- This document.
- Correct answer fields.
- Ground truth.
- Author-only explanation of the twists.
- Unlocked future evidence before phase unlock.
- Any hidden case metadata that reveals the culprit.

Player interface can show only the evidence and tasks unlocked for the team's current phase.
