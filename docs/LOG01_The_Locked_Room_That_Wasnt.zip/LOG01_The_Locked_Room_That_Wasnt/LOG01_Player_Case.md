# LOG01 — The Locked Room That Wasn't
## Player-facing case file

**Track:** Logic  
**Objective:** Determine who was responsible for the disappearance of the Aster prototype and what most likely happened.

> **Important:** This document contains player-facing information only. Do not add the author-only solution or answer keys to the player interface.

## Incident briefing

At the annual college innovation showcase, a working prototype called **Aster** is due to be demonstrated at 4:45 PM. It is kept in a display case inside Innovation Room B.

At 4:30 PM, the display case is opened for a final check. The Aster prototype is gone. An object that looks similar remains in its place.

The room door is closed. The key register shows no unusual key issue. No one admits entering after the room was secured.

The event coordinator claims that someone must have entered a locked room without leaving evidence of entry.

**Your task:** Investigate the evidence. Was Aster stolen from a locked room, or did everyone make the wrong assumption about when it disappeared?

## People involved

### Rohan Mehta — Competing team leader
Rohan's team lost the internal selection round to Aster's team. He argued with the prototype's creator the previous afternoon and was seen near Innovation Room B. He says he came to collect his team's presentation file.

### Naina Rao — Event photographer
Naina took official photographs of the prototype before the room was closed. She says she never touched Aster and left before the final preparations.

### Imran Shaikh — Lab technician
Imran repaired the display case's lighting earlier that afternoon. He had tools, access to the room and knowledge of the display's construction.

### Devika Nair — Room key custodian
Devika signed for the room key, supervised the closing procedure and was the first person to report that Aster was missing.

### Vikram Sethi — Showcase coordinator
Vikram managed the demonstration schedule and insists the room was secured at 4:20 PM. He says postponing the demonstration would cause serious problems for the event.

### Aditya Varma — Aster's creator
Aditya built the prototype and prepared it for the demonstration. He says the object in the display was the genuine Aster when he last saw it.

---

# Phase 1 — Discovery

## Evidence A — Room Closure Log
**Source:** Devika's signed checklist

- 4:05 PM — Aster checked in the display case.
- 4:16 PM — Final room sweep started.
- 4:20 PM — Room reported closed.
- 4:21 PM — Key returned to the event desk.
- 4:30 PM — Missing prototype reported.

Devika's note reads: *“Display appeared complete before closure.”*

## Evidence B — Access and Movement Notes
**Source:** Staff movement sheet and witness statements

- Rohan was seen near Innovation Room B around 4:08 PM.
- Imran worked on the display lighting earlier that afternoon.
- Naina was inside the room for official photographs.
- Vikram visited the room during preparation.
- Devika was responsible for the key and closing checklist.

The sheet records **presence near the room**, not proof of entry at the time Aster disappeared.

## Evidence C — Two Photographs
**Source:** Naina's official event photo set

- Photo 1: 4:07 PM — Aster in its display case.
- Photo 2: 4:18 PM — The display case appears complete from the front.

The second photograph is slightly angled. A small label on the base is partly obscured by glare.

## Evidence D — The Rehearsal Note
**Source:** Event preparation notebook

At 3:52 PM, Aditya wrote:

*“Check the output before the live demo. If the fault returns, do not present it as fully working.”*

There is no signature beside the note and no indication that the issue was resolved.

## Question 1
**Which conclusion is actually supported by the closure log?**

A. Rohan stole Aster because he was near the room.  
B. The room was reported closed at 4:20 PM, but the log does not prove when Aster was last physically present.  
C. Aster was definitely present at 4:20 PM.  
D. Devika must have taken Aster because she held the key.

## Question 2
**Which suspect has the clearest apparent motive from the evidence available so far?**

A. Rohan  
B. Naina  
C. Imran  
D. Devika

## Question 3
**What is the most useful next step?**

A. Accuse Rohan before he can leave.  
B. Verify whether the object in the 4:18 photograph is the genuine Aster.  
C. Assume the key register proves no one could have removed the prototype.  
D. Investigate every person who has ever worked in the lab.

---

# Phase 2 — Investigation

## Evidence E — The Prototype Identification Sheet
**Source:** Aditya's pre-event technical checklist

The genuine Aster has three identifying features:

1. A small blue inspection mark on the underside of its base.
2. A short scratch beside the left mounting screw.
3. A green indicator that lights up when the device is powered.

The display replica was made for photographs and has the same outer shell, but it has no functioning indicator and no internal electronics.

## Evidence F — The Enlarged 4:18 Photograph
**Source:** Enhanced crop of Naina's original photograph

The photograph reveals the display's left mounting screw and the label on its base. The blue inspection mark is absent. The green indicator is dark, and its lens is a solid piece rather than the transparent lens fitted to the genuine prototype.

The image does not prove that the device is switched off: the lens itself is visibly different.

## Evidence G — Rohan's Account
**Source:** Recorded interview

Rohan says:

*“I went to the corridor at about 4:08 to collect our presentation file. I did not enter the room. I saw Vikram carrying a flat black event case near the AV booth, but I thought it held cables.”*

Rohan initially denied being near the room, then corrected himself when shown the movement sheet. His first answer was misleading, but the second part of his account is independently testable.

## Evidence H — AV Booth Equipment Register
**Source:** Event equipment checkout sheet

- 4:02 PM — Vikram signs out a flat black equipment case.
- 4:24 PM — The case is listed as returned to the AV booth.
- The register does not record what was placed inside the case.
- No one records an inspection of the case at return.

## Evidence I — Maintenance Record
**Source:** Imran's signed work note

Imran repaired the display lighting at 3:35 PM. He records that he did not remove the display's backing panel and that the case was left open for Aditya's inspection afterward.

Aditya's signature confirms the case was open during the inspection. No evidence places Imran inside the room during the later 4:07–4:20 period.

## Question 4
**What does the 4:18 photograph establish?**

A. Aster was definitely present because a device-shaped object is visible.  
B. The genuine Aster was likely replaced by the display replica before the room was closed.  
C. Naina stole Aster because she took the photograph.  
D. The room's lock was defective.

## Question 5
**Which conclusion about Rohan is best supported now?**

A. He is guilty because he initially denied being near the room.  
B. His account contains a contradiction that must be checked, but his presence alone does not prove he entered or removed Aster.  
C. He is innocent because he eventually told the truth.  
D. He must have used Imran's tools.

## Question 6
**Which lead should investigators pursue next to test the removal timeline?**

A. Search the AV booth and determine whether the returned equipment case could still contain Aster.  
B. Accuse Naina because the replica appears in her photograph.  
C. Reopen Imran's maintenance work without checking the later timeline.  
D. Treat Devika's closure checklist as proof that the genuine prototype was present at 4:20.

---

# Phase 3 — Reconstruction

## Evidence J — The Rehearsal Follow-up
**Source:** Aditya's message to the showcase team

At 4:00 PM, Aditya sends the team a message:

*“Aster failed the output check again. I need ten minutes to inspect it. Please don't announce that it's ready yet.”*

The message is delivered to the event preparation group, which includes Vikram. The delivery record confirms that Vikram's account received it at 4:01 PM.

## Evidence K — The Unsent Schedule Change
**Source:** Event coordinator's draft schedule

At 4:14 PM, Vikram drafts a schedule update stating that Aster's demonstration may be delayed because of a *“security incident in Innovation Room B.”*

The draft is never sent. Its creation time is recorded by the event scheduling system. The draft alone does not prove that Vikram caused the incident; it does show he was preparing for a delay before the missing prototype was officially reported.

## Evidence L — AV Booth Inspection
**Source:** Joint inspection by the event staff

The flat black case Vikram signed out is found in the AV booth. Inside it is a foam insert cut to fit the Aster prototype. A small piece of blue protective tape matching the prototype's packaging is stuck to the insert.

The prototype is not inside the case when it is inspected. The insert proves the case was configured to carry a device of Aster's size, but does not independently prove that the genuine Aster was inside it.

## Evidence M — Aditya's Final Identification
**Source:** Comparison of the replica with the genuine prototype's build notes

Aditya confirms that the object in the 4:18 photograph is the replica, not the working Aster. The replica's solid indicator lens, missing inspection mark and different mounting screw are all consistent with his identification sheet.

He also confirms that the genuine Aster was functioning earlier in the afternoon but had failed the 4:00 PM output check. He had not authorized anyone to replace it with the display model.

## Evidence N — The Witness Timeline
**Source:** Independently collected statements

- **Aditya:** sent the failure warning at 4:00 PM and did not authorize a swap.
- **Rohan:** saw Vikram with the black case near the AV booth around 4:08 PM.
- **Naina:** took the photograph showing the replica at 4:18 PM.
- **Devika:** closed the room at 4:20 PM based on the visual checklist.
- **Vikram:** drafted a security-incident schedule change at 4:14 PM.

The statements and records establish a sequence, but no single item directly captures Vikram physically taking Aster.

## Question 7
**Which timeline is consistent with all the evidence?**

A. The room was locked at 4:20, then someone entered and replaced Aster with the replica.  
B. Vikram learned about the failed output check, prepared for a possible security-related delay, and the replica was in place before the room closed.  
C. Rohan removed Aster after 4:20, then returned the replica without being seen.  
D. Imran's 3:35 lighting repair proves he took Aster.

## Question 8
**What is the strongest interpretation of the black equipment case?**

A. It conclusively proves Vikram transported the genuine Aster.  
B. It is irrelevant because the prototype was not found inside it.  
C. It independently links Vikram to a container prepared for an object of Aster's size, supporting—but not proving—the removal theory.  
D. It proves Rohan lied about everything.

## Question 9
**Which hypothesis best explains the full set of evidence with the fewest unsupported assumptions?**

A. Rohan entered the locked room after 4:20 and somehow replaced the genuine prototype.  
B. Imran used his maintenance knowledge to bypass the room's lock after closure.  
C. Vikram used the failed rehearsal as a reason to remove Aster before closure, substitute the replica, and prepare a security-related delay.  
D. Naina accidentally photographed a different prototype and caused the entire incident through a camera error.

---

# Final deduction

## Final Question 1 — Who was responsible?

Select one:

- Rohan Mehta
- Naina Rao
- Imran Shaikh
- Devika Nair
- Vikram Sethi
- Aditya Varma

## Final Question 2 — What most likely happened?

A. The genuine Aster was stolen after the room was locked, using an unknown way into the room.  
B. The genuine Aster was accidentally damaged during maintenance, and the display model was substituted to hide the damage.  
C. The genuine Aster was removed before closure and replaced with a replica; the disappearance was used to create a security-related delay after the rehearsal failure.  
D. The genuine Aster was never placed in the room; the entire event team mistakenly believed a replica was the real prototype.

**Submit both answers.** The two components are graded independently.
