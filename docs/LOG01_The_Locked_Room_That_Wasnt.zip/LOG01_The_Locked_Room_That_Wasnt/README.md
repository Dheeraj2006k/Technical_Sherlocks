# LOG01 — The Locked Room That Wasn't

**Track:** Logic  
**Status:** Prototype draft — not yet seed-ready  
**Version:** 0.1  
**Format:** 3 phases, 9 investigation questions, 2-part final deduction

## What's included

- `LOG01_Player_Case.md` — player-facing briefing, characters, evidence and tasks. Keep author-only material out of the player build.
- `LOG01_Author_Notes.md` — ground truth, twist map, suspect reasoning, evidence-to-solution map, and remaining design gaps.
- `LOG01_Scoring_and_Hints.md` — proposed points, hints, answer key and scoring caveats.
- `LOG01_Case_Manifest.json` — machine-readable draft structure for review and later conversion to the game's seed format.
- `LOG01_Validation_Checklist.md` — checks to complete before implementation.

## Important status note

This is a **complete narrative prototype**, not a production-ready seed pack. The core mystery and answer key are defined, but the case still needs a stronger independent link between Vikram and the physical substitution, tighter opportunity boundaries for innocent suspects, and playtesting. The scoring proposal also needs reconciliation with the game's global 10-point task ladder.

Do not expose the author notes, answer keys, or manifest's answer fields to players.
