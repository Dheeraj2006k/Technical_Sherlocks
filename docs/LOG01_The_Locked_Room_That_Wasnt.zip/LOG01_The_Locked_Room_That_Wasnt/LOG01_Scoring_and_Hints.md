# LOG01 — Scoring, Hints and Answer Key

**Status:** Proposed scoring draft. Must be reconciled with global scoring rules before implementation.

## Proposed allocation

| Component | Proposed points |
|---|---:|
| Questions 1–3 | 15 total |
| Questions 4–6 | 15 total |
| Questions 7–9 | 15 total |
| Final responsible character | 35 |
| Final explanation | 20 |
| **Total** | **100** |

For this draft, each ordinary question is proposed as a five-point task with the hint ladder 5, 4, 3, 2, 1.

**Compatibility warning:** The previously agreed global default for a standard 10-point task is 10, 8, 6, 4, 2. This prototype's nine five-point tasks are a case-specific proposal, not a global rules change. Before implementation, either:
1. retain the global ladder and consolidate/restructure the nine prompts into the agreed number of scored tasks; or
2. formally approve a second task type with its own point and hint ladder.

Wrong committed answers cost −2 under the existing global rule. Successful tasks/components award points only once. Total score cannot fall below zero. Hints are team-shared.

## Answer key

| Question | Correct answer | Reason |
|---|---|---|
| Q1 | B | Closure time is not proof of when the genuine object was last present. |
| Q2 | A — Rohan | His rivalry is the strongest apparent motive at Phase 1; it is not proof of guilt. |
| Q3 | B | Verify the object's identity in the later photograph. |
| Q4 | B | Physical details indicate that the display object is a replica. |
| Q5 | B | Rohan's contradiction warrants checking but does not establish theft. |
| Q6 | A | The case is a testable lead, though its contents are not yet known. |
| Q7 | B | This sequence is consistent with the failure warning, draft, photograph and closure time. |
| Q8 | C | The case corroborates the theory but does not prove what it carried. |
| Q9 | C | This hypothesis best explains the independent evidence with fewer unsupported assumptions. |
| Final person | Vikram Sethi | Author-intended responsible person. |
| Final explanation | C | Removal before closure, replica substitution and a security-related delay. |

## Hint ladders

### Q1
1. Separate the record's timestamp from the conclusion someone draws from it.
2. What did the staff actually verify?
3. The checklist records a closure process, not a forensic identification of the object.

### Q2
1. Identify the person with a documented conflict involving Aster's team.
2. Which conflict could plausibly motivate interference?
3. Rohan has the clearest apparent motive so far, but motive is not proof.

### Q3
1. Before asking how an object left, verify which object is visible.
2. Compare the photograph with the identification sheet.
3. Look for physical features that cannot be explained by the device merely being switched off.

### Q4
1. Compare the identification sheet with the enlarged photograph.
2. Look at the inspection mark and indicator lens.
3. The lens itself is different, not merely unlit.

### Q5
1. Evaluate each part of Rohan's account separately.
2. Check the claim about the black case against an independent record.
3. The register confirms Vikram checked out a case, but neither fact alone proves theft.

### Q6
1. Which object has an unverified chain of custody?
2. The equipment register does not state what the case contained.
3. Inspect the returned case and its insert.

### Q7
1. Put the message, draft, photograph and closure log in time order.
2. The replica appears before the room is reported closed.
3. The evidence supports a pre-closure substitution, not a post-lock entry.

### Q8
1. Separate what the case physically proves from what investigators infer.
2. The case has a fitted insert and packaging trace, but the prototype is absent.
3. It supports the removal theory without conclusively proving the case's contents at the critical time.

### Q9
1. Compare how many independent records each hypothesis explains.
2. Consider who knew about the failed prototype and prepared for a security-related delay.
3. Combine the rehearsal warning, early draft, case evidence and pre-closure replica.

## Grading implementation notes

- Store attempts separately from successful completions.
- Apply the −2 penalty only to committed wrong answers, not to browsing or inspecting evidence.
- Grade the final responsible-character and explanation components independently.
- Make successful completion idempotent; a duplicate submission must not award points twice.
- Use server-side answer keys only.
- Do not show the full explanation or answer key when a player gets one component wrong.
