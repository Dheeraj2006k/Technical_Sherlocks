# LOG06 — The Last Render

**Track:** Logic
**Recommended team size:** 1 player (solo)
**Estimated play time:** 12–18 minutes

## Case briefing

QUBIT’s showcase is running on a tight schedule. Team Comet submitted a two-minute demo video before the deadline. At 4:20 PM, the video begins with the right title—but ends after just 42 seconds, skipping the reveal that judges were waiting for. The team’s slot is paused, and Team Orbit is next in line.

Your job is to work out how the wrong video reached the playback system, who was responsible, and whether it was an accident or a deliberate move. You do not need technical knowledge: treat filenames, times, checksums and handoff records as clues. A checksum is simply a file’s identifying fingerprint.

## People involved

- **Nisha Rao** — AV coordinator; prepares the playback package and stage cue list.
- **Dev Malhotra** — Team Comet captain; submitted the final demo video.
- **Tara Iyer** — AV trainee; helps copy files and label media.
- **Arjun Kapoor** — Stage runner; transports the sealed playback drive.
- **Zoya Khan** — Team Orbit captain; competing for the final showcase slot.
- **Milan Das** — Event photographer; records setup and the playback desk.

## Phase 1 — The Cut

Start with what happened on stage, the approved cue, the upload receipt and the duty card. Keep separate what is known from what is merely possible.

### Evidence

### E01 — The Demo That Ended Too Soon
**Source:** Judge’s incident card

Team Comet’s scheduled 2-minute demo stopped after 42 seconds. The screen showed the correct opening title, then skipped straight to the end card. The judges paused scoring and asked for the source file. This establishes what happened on stage, not who caused it.

### E02 — The Approved Run Sheet
**Source:** Stage manager’s signed copy

Team Comet’s slot is 4:20–4:22 PM. The cue reads “COMET_FINAL — 2:00 — reveal at 1:25.” Team Orbit follows at 4:25 PM. The run sheet was signed at 3:30 PM and no timing change is recorded.

### E03 — The Submission Receipt
**Source:** Event upload kiosk

At 3:36 PM, Dev submitted “Comet_Final_v7.mp4”, duration 02:00. The kiosk receipt records a successful upload and checksum ending 91C4. The upload happened before the 3:45 PM media cutoff.

### E04 — Who Could Prepare Playback?
**Source:** AV booth duty card

Nisha prepared the playback package from 3:35–4:00 PM. Tara assisted with copying and labels from 3:40–3:55 PM. Arjun collected the playback drive at 4:02 PM after it was sealed. This shows opportunity windows, not who altered a file.

## Phase 2 — The File Trail

Now follow the drive and the media file. A person holding a drive later is not automatically responsible for a file prepared earlier.

### Evidence

### E05 — The Sealed Drive Handoff
**Source:** Stage runner’s handoff log

Arjun signed for one sealed USB drive at 4:02 PM. The seal number was AV-17. He returned it unopened at 4:31 PM. The seal number matches the booth’s photo taken immediately after the drive was closed.

### E06 — The Playback Device Report
**Source:** Media player diagnostics

The player ran “Comet_Final_v7.mp4” for exactly 00:42. Its checksum ends 7A20, not 91C4. The player log confirms the short file was played, but it does not identify who created or copied it.

### E07 — The Export Folder History
**Source:** AV workstation audit

At 3:49 PM, the workstation created a 42-second file named “Comet_Final_v7.mp4” from the source “Comet_Rehearsal_cut.mp4”. The workstation audit attributes the export session to Nisha’s account. The audit records the account, not by itself the human at the keyboard.

### E08 — Tara’s Label Sheet
**Source:** Recovered from the AV desk

Tara’s handwritten label sheet says “COMET FINAL — 2:00 — checksum 91C4”. A separate sticky note says “short cut = rehearsal only”. The label sheet was written at 3:44 PM, before the 3:49 PM export. Tara’s labels accurately describe the submitted final file.

## Phase 3 — The Final Export

Use the last records to test your leading theory. Look for evidence that independently connects the export, the person at the workstation and the reason for doing it.

### Evidence

### E09 — The Booth Reflection Photo
**Source:** Milan’s setup photograph, 3:50 PM

A reflection in the booth monitor shows Nisha at the workstation while the export progress bar is visible. The monitor’s filename field reads “Comet_Final_v7.mp4”. The photo cannot show the source filename or prove intent, but it places Nisha at the active export session.

### E10 — The Rehearsal Cut’s End Card
**Source:** Recovered preview frame

The short playback file’s final frame contains a rehearsal-only note: “Reveal animation still pending — do not use for judging.” The same wording appears in the rehearsal cut’s project notes. The submitted 2-minute file’s preview frame, preserved at upload, contains the finished reveal instead.

### E11 — Nisha’s Cue Draft
**Source:** AV clipboard, reverse side

A draft in Nisha’s handwriting reads: “If Comet misses reveal, hold scoring; Orbit can take the spare slot. Use the short render if timing gets tight.” It is timestamped 3:47 PM, two minutes before the short export. The note must be read with the export log and her presence at the workstation.

### E12 — The Original Upload Still Exists
**Source:** Kiosk archive and checksum comparison

The kiosk archive still holds Dev’s 2-minute file with checksum 91C4. The playback copy has checksum 7A20 and matches the 42-second rehearsal cut. The original was not corrupted or overwritten; a different export was placed in the playback package.

## Final deduction

Submit two answers independently:
1. **Who was responsible?**
2. **Which explanation best fits the complete evidence?**

Do not choose someone just because they had access. The strongest answer must explain the file’s short duration, its source, the intact original submission, the sealed handoff and the timing of the export.
