Player-facing file only. Do not share author notes, task answer keys, seed SQL or verification files with players.
