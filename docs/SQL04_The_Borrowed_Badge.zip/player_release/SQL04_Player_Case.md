# SQL04 — The Borrowed Badge
## Case briefing

**Team:** Two investigators  
**Objective:** Work out who used a borrowed access badge to enter the equipment archive after hours, what they were actually trying to retrieve, and how the logs were made to point at someone else.

At 6:40 PM, a sealed envelope containing the final QUBIT demo-room access tokens is found missing from the equipment archive. The archive door log records badge **B-204** entering at 6:17 PM. B-204 belongs to **Ishaan Rao**, a student volunteer who says he returned it before 5:30 PM.

Four people had plausible reasons to be near the archive:

- **Ishaan Rao** — volunteer whose badge ID appears in the door log
- **Maya Kapoor** — inventory coordinator with archive access
- **Arjun Sen** — AV technician who needed a replacement cable
- **Pooja Nair** — demo-room coordinator responsible for the access-token envelope

A door log is not the same thing as proof of who physically carried a badge. You will need to connect badge checkout records, door events, equipment requests and the archive inventory trail.

## How to investigate
- Use SQL against the tables unlocked for each phase.
- Divide the work: one investigator can reconstruct badge custody while the other checks door and equipment records.
- Exploratory SQL errors do not cost points.
- Scored answers are submitted as fixed choices. Wrong committed answers may incur the standard penalty.
- Do not assume the badge owner and the person who used it are necessarily the same person.

## Phase 1 — The Access Log
Identify the missing item, establish which badge appears in the door log, and find out whether the badge was officially checked out at the time.

## Phase 2 — The Borrowed Identity
Join checkout and return records with door events. Find the gap between badge ownership and actual custody, then compare the archive entry with the equipment request.

## Phase 3 — What Was Really Taken?
Reconstruct the sequence around the archive visit. Determine who had the badge, what they accessed, and which records were altered or misrepresented afterward.

## Final deduction
Submit:
1. Who was responsible?
2. Which explanation best fits the evidence?

Your answer must explain both the borrowed badge and the missing envelope. A badge ID alone is not enough to identify the person who used it.
