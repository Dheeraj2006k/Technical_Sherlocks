# SQL04 Acceptance Tests

## Data
- [ ] Apply schema in staging with no errors.
- [ ] Run seed twice; counts remain stable and no runtime player-state tables are changed.
- [ ] Run verification SQL; every check is PASS.
- [ ] Confirm all foreign keys resolve.
- [ ] Parse manifest/tasks/hints JSON.
- [ ] Verify six unique tasks, four options each, exactly one correct option per task, and a complete hint ladder.
- [ ] Verify 6×10 + 25 + 15 = 100 points.

## Security and engine
- [ ] Student SQL runs under restricted read-only role.
- [ ] Writes, DDL, multiple statements, system catalog reads and cross-case access are rejected.
- [ ] Assignment and phase unlocks are enforced server-side.
- [ ] Answer keys and canonical queries never reach client bundle or API responses.
- [ ] Query timeout, row cap, rate limit, retries and idempotent scoring are tested.

## Narrative and duo playtest
- [ ] Two first-time players solve in 15–20 minutes without author intervention.
- [ ] One player can trace badge custody while the other compares archive inventory and requests.
- [ ] All scored answers are supported by currently unlocked evidence.
- [ ] The door log alone does not prove identity; the solution requires joined evidence.
- [ ] Arjun's alternative explanation is fairly tested and specifically weakened.
- [ ] No clue claims Maya intended to use the tokens; supported motive is to delay handover.
- [ ] Final answer does not depend on a hidden or inaccessible record.
