-- SQL04 isolated case evidence schema; does not replace shared runtime tables.
CREATE TABLE IF NOT EXISTS public.sql04_case (
 case_id text PRIMARY KEY, title text NOT NULL, content_version text NOT NULL,
 intended_team_size smallint NOT NULL CHECK (intended_team_size=2), release_status text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_characters (
 character_id text PRIMARY KEY, display_name text NOT NULL, role text NOT NULL, public_description text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_badge_registry (
 badge_id text PRIMARY KEY, assigned_to text NOT NULL REFERENCES public.sql04_characters(character_id),
 badge_type text NOT NULL, status text NOT NULL, note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_badge_custody (
 custody_id text PRIMARY KEY, badge_id text NOT NULL REFERENCES public.sql04_badge_registry(badge_id),
 event_at timestamptz NOT NULL, actor_id text NOT NULL REFERENCES public.sql04_characters(character_id),
 event_type text NOT NULL, from_location text NOT NULL, to_location text NOT NULL, note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_door_events (
 door_event_id text PRIMARY KEY, event_at timestamptz NOT NULL, door_name text NOT NULL,
 badge_id text NOT NULL REFERENCES public.sql04_badge_registry(badge_id), event_type text NOT NULL,
 result text NOT NULL, controller_note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_archive_inventory (
 inventory_event_id text PRIMARY KEY, event_at timestamptz NOT NULL, item_id text NOT NULL,
 item_name text NOT NULL, location text NOT NULL, quantity integer NOT NULL CHECK(quantity>=0),
 recorded_by text NOT NULL REFERENCES public.sql04_characters(character_id), event_type text NOT NULL, note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_equipment_requests (
 request_id text PRIMARY KEY, requested_at timestamptz NOT NULL, requester_id text NOT NULL REFERENCES public.sql04_characters(character_id),
 item_requested text NOT NULL, fulfilled_from text NOT NULL, fulfilled_at timestamptz,
 fulfilled_by text REFERENCES public.sql04_characters(character_id), status text NOT NULL, note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_inventory_notes (
 note_id text PRIMARY KEY, created_at timestamptz NOT NULL, author_id text NOT NULL REFERENCES public.sql04_characters(character_id),
 subject_id text NOT NULL, note_status text NOT NULL, note_text text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql04_messages (
 message_id text PRIMARY KEY, sent_at timestamptz NOT NULL,
 sender_id text NOT NULL REFERENCES public.sql04_characters(character_id),
 recipient_id text NOT NULL REFERENCES public.sql04_characters(character_id),
 channel text NOT NULL, message_text text NOT NULL
);
CREATE INDEX IF NOT EXISTS sql04_custody_badge_time_idx ON public.sql04_badge_custody(badge_id,event_at);
CREATE INDEX IF NOT EXISTS sql04_door_badge_time_idx ON public.sql04_door_events(badge_id,event_at);
CREATE INDEX IF NOT EXISTS sql04_inventory_item_time_idx ON public.sql04_archive_inventory(item_id,event_at);
CREATE INDEX IF NOT EXISTS sql04_notes_author_time_idx ON public.sql04_inventory_notes(author_id,created_at);
