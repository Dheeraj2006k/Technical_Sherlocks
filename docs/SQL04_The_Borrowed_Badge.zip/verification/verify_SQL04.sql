WITH checks AS (
 SELECT 'case row' AS check_name,(SELECT count(*)=1 FROM public.sql04_case WHERE case_id='SQL04') AS ok
 UNION ALL SELECT 'six characters',(SELECT count(*)=6 FROM public.sql04_characters)
 UNION ALL SELECT 'four registered badges',(SELECT count(*)=4 FROM public.sql04_badge_registry)
 UNION ALL SELECT 'five badge custody events',(SELECT count(*)=5 FROM public.sql04_badge_custody)
 UNION ALL SELECT 'four door events',(SELECT count(*)=4 FROM public.sql04_door_events)
 UNION ALL SELECT 'four archive inventory events',(SELECT count(*)=4 FROM public.sql04_archive_inventory)
 UNION ALL SELECT 'two equipment requests',(SELECT count(*)=2 FROM public.sql04_equipment_requests)
 UNION ALL SELECT 'three inventory notes',(SELECT count(*)=3 FROM public.sql04_inventory_notes)
 UNION ALL SELECT 'four messages',(SELECT count(*)=4 FROM public.sql04_messages)
 UNION ALL SELECT 'Ishaan return before archive entry',
  (SELECT min(event_at) FILTER(WHERE event_type='RETURN_ACCEPTED') < (SELECT event_at FROM public.sql04_door_events WHERE door_event_id='DE-03') FROM public.sql04_badge_custody WHERE badge_id='B-204')
 UNION ALL SELECT 'envelope count drops to zero',
  (SELECT min(quantity)=0 AND max(quantity)=1 FROM public.sql04_archive_inventory WHERE item_id='ENV-TOKEN')
 UNION ALL SELECT 'Maya note follows signed return',
  (SELECT (SELECT created_at FROM public.sql04_inventory_notes WHERE note_id='IN-02') > (SELECT event_at FROM public.sql04_badge_custody WHERE custody_id='BC-03'))
)
SELECT check_name,CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END AS result FROM checks ORDER BY check_name;

-- Author-side timeline view; do not expose to players as a precomputed answer.
SELECT event_at AS event_time,'badge_custody' AS source,badge_id AS subject,event_type AS event,actor_id AS actor,note AS detail
FROM public.sql04_badge_custody
UNION ALL
SELECT event_at,'door',badge_id,event_type,result,controller_note FROM public.sql04_door_events
UNION ALL
SELECT event_at,'inventory',item_id,event_type,recorded_by,'quantity='||quantity||'; '||note FROM public.sql04_archive_inventory
ORDER BY event_time;
