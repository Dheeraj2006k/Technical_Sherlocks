# RESTRICTED — SQL04 Author Notes and Answer Key
Do not distribute to players or include in client assets.

## Canonical solution
**Responsible person: Maya Kapoor.** Maya had official access as inventory coordinator and took custody of Ishaan's returned badge under the pretext of reconciling the checkout sheet. She used B-204 to enter the archive, removed the access-token envelope to delay a demo-room handover after discovering a token-list mismatch, then edited the inventory note to imply Ishaan had not returned the badge. The case supports concealment and intentional interference with the handover; it does not prove Maya planned to use the tokens herself.

## Timeline
- 17:22 — Ishaan checks badge B-204 back in with the volunteer desk. Return is recorded by desk attendant Pooja.
- 17:31 — Maya signs a reconciliation note saying she is reviewing returned badge IDs; she takes B-204 temporarily for a scan.
- 17:48 — Arjun requests a replacement cable for the demo room; the request is fulfilled from the AV cabinet, not the archive.
- 18:11 — Maya creates an inventory note that incorrectly marks B-204 “return unconfirmed.”
- 18:17 — Door controller logs B-204 entering the equipment archive.
- 18:21 — Archive inventory scan records the access-token envelope present at 18:05 but absent at 18:21.
- 18:26 — Maya messages Pooja asking to hold the demo-room handover until the token list is reconciled.
- 18:40 — Pooja reports the envelope missing.
- 18:44 — Ishaan says he returned B-204 at 17:22; the signed checkout record corroborates him.
- 18:51 — Maya says Ishaan must have retained the badge because the door log names B-204.

## Twists
1. The badge ID in the door log belongs to Ishaan, but the signed return proves ownership is not the same as custody.
2. Arjun's cable request makes him look like a plausible archive visitor, but the request was fulfilled from a different cabinet and does not link him to the door event.
3. The inventory note blaming an unconfirmed return was created after the signed return.
4. The envelope disappears during the same narrow window as the archive entry.
5. Maya's handover message and post-return note establish a plausible reason for the interference and an attempt to redirect blame.

## Fairness limits
- Do not claim the database identifies the physical person through badge telemetry alone. The conclusion comes from badge custody, note timing, archive inventory and Maya's message together.
- Do not claim Maya intended to steal or use the tokens; evidence supports removing the envelope to delay the handover and concealing the action.
- Arjun is cleared by the cable request's fulfillment location and the absence of an archive-linked movement, not merely by lack of a door scan.
- Ishaan is cleared by the signed return record plus Maya's later custody and contradictory inventory note.
