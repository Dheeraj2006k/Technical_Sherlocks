BEGIN;
INSERT INTO public.sql04_case VALUES ('SQL04','The Borrowed Badge','1.0.0',2,'content_complete_staging_validation_required')
ON CONFLICT(case_id) DO UPDATE SET title=EXCLUDED.title,content_version=EXCLUDED.content_version,intended_team_size=EXCLUDED.intended_team_size,release_status=EXCLUDED.release_status;
INSERT INTO public.sql04_characters VALUES
('ISHAAN','Ishaan Rao','Student volunteer','Volunteer whose badge ID appears in the archive door log.'),
('MAYA','Maya Kapoor','Inventory coordinator','Reconciles equipment and returned badge records.'),
('ARJUN','Arjun Sen','AV technician','Requested a replacement cable for the demo room.'),
('POOJA','Pooja Nair','Demo-room coordinator','Responsible for receiving the access-token envelope.'),
('DEV','Dev Malhotra','Security desk attendant','Records returned badges at the volunteer desk.'),
('RHEA','Rhea Thomas','Show producer','Responsible for the closing-show schedule.')
ON CONFLICT(character_id) DO UPDATE SET display_name=EXCLUDED.display_name,role=EXCLUDED.role,public_description=EXCLUDED.public_description;
INSERT INTO public.sql04_badge_registry VALUES
('B-204','ISHAAN','TEMPORARY_ACCESS','ACTIVE','Assigned to Ishaan for volunteer duty.'),
('B-118','MAYA','STAFF_ACCESS','ACTIVE','Inventory coordinator badge.'),
('B-311','ARJUN','TECH_ACCESS','ACTIVE','AV technician badge.'),
('B-090','POOJA','STAFF_ACCESS','ACTIVE','Demo-room coordinator badge.')
ON CONFLICT(badge_id) DO UPDATE SET assigned_to=EXCLUDED.assigned_to,badge_type=EXCLUDED.badge_type,status=EXCLUDED.status,note=EXCLUDED.note;
INSERT INTO public.sql04_badge_custody VALUES
('BC-01','B-204','2026-10-16 16:05:00+05:30','DEV','CHECKOUT','Volunteer Desk','Ishaan Rao','Issued for volunteer shift.'),
('BC-02','B-204','2026-10-16 17:22:00+05:30','ISHAAN','RETURN_DECLARED','Ishaan Rao','Volunteer Desk','Ishaan hands badge back; Dev signs receipt.'),
('BC-03','B-204','2026-10-16 17:24:00+05:30','DEV','RETURN_ACCEPTED','Ishaan Rao','Volunteer Desk','Signed return recorded by security desk attendant.'),
('BC-04','B-204','2026-10-16 17:31:00+05:30','MAYA','TEMPORARY_SCAN','Volunteer Desk','Inventory Office','Maya takes badge briefly to reconcile returned badge IDs.'),
('BC-05','B-204','2026-10-16 17:42:00+05:30','MAYA','SCAN_COMPLETE','Inventory Office','Inventory Office','Badge scan completed; no return-to-desk event is recorded.')
ON CONFLICT(custody_id) DO UPDATE SET badge_id=EXCLUDED.badge_id,event_at=EXCLUDED.event_at,actor_id=EXCLUDED.actor_id,event_type=EXCLUDED.event_type,from_location=EXCLUDED.from_location,to_location=EXCLUDED.to_location,note=EXCLUDED.note;
INSERT INTO public.sql04_door_events VALUES
('DE-01','2026-10-16 16:52:00+05:30','Equipment Archive','B-118','ENTRY','GRANTED','Maya enters during routine inventory check.'),
('DE-02','2026-10-16 17:09:00+05:30','Equipment Archive','B-311','ENTRY','GRANTED','Arjun enters to inspect a cable rack.'),
('DE-03','2026-10-16 18:17:00+05:30','Equipment Archive','B-204','ENTRY','GRANTED','Door controller records badge ID only; it does not identify the carrier.'),
('DE-04','2026-10-16 18:23:00+05:30','Equipment Archive','B-204','EXIT','GRANTED','Exit logged with the same badge ID.')
ON CONFLICT(door_event_id) DO UPDATE SET event_at=EXCLUDED.event_at,door_name=EXCLUDED.door_name,badge_id=EXCLUDED.badge_id,event_type=EXCLUDED.event_type,result=EXCLUDED.result,controller_note=EXCLUDED.controller_note;
INSERT INTO public.sql04_archive_inventory VALUES
('AI-01','2026-10-16 17:55:00+05:30','ENV-TOKEN','Demo-room access-token envelope','Equipment Archive',1,'MAYA','COUNT','Envelope present during pre-show inventory.'),
('AI-02','2026-10-16 18:05:00+05:30','ENV-TOKEN','Demo-room access-token envelope','Equipment Archive',1,'MAYA','COUNT','Second count confirms envelope present.'),
('AI-03','2026-10-16 18:21:00+05:30','ENV-TOKEN','Demo-room access-token envelope','Equipment Archive',0,'MAYA','COUNT','Envelope absent after badge B-204 archive visit.'),
('AI-04','2026-10-16 18:32:00+05:30','ENV-TOKEN','Demo-room access-token envelope','Equipment Archive','0','POOJA','INCIDENT_CHECK','Pooja independently confirms envelope missing.')
ON CONFLICT(inventory_event_id) DO UPDATE SET event_at=EXCLUDED.event_at,item_id=EXCLUDED.item_id,item_name=EXCLUDED.item_name,location=EXCLUDED.location,quantity=EXCLUDED.quantity,recorded_by=EXCLUDED.recorded_by,event_type=EXCLUDED.event_type,note=EXCLUDED.note;
INSERT INTO public.sql04_equipment_requests VALUES
('ER-01','2026-10-16 17:48:00+05:30','ARJUN','Replacement HDMI cable','AV Cabinet', '2026-10-16 17:54:00+05:30','DEV','FULFILLED','Cable issued from AV cabinet; no archive stock movement.'),
('ER-02','2026-10-16 18:12:00+05:30','POOJA','Demo-room access-token envelope','Equipment Archive',NULL,NULL,'OPEN','Pooja checks the handover list; this is not a request to remove the envelope.')
ON CONFLICT(request_id) DO UPDATE SET requested_at=EXCLUDED.requested_at,requester_id=EXCLUDED.requester_id,item_requested=EXCLUDED.item_requested,fulfilled_from=EXCLUDED.fulfilled_from,fulfilled_at=EXCLUDED.fulfilled_at,fulfilled_by=EXCLUDED.fulfilled_by,status=EXCLUDED.status,note=EXCLUDED.note;
INSERT INTO public.sql04_inventory_notes VALUES
('IN-01','2026-10-16 17:31:00+05:30','MAYA','B-204','RECONCILIATION','Temporary scan of returned badge for inventory reconciliation.'),
('IN-02','2026-10-16 18:11:00+05:30','MAYA','B-204','AMENDED','Return unconfirmed; badge may still be with Ishaan.'),
('IN-03','2026-10-16 18:44:00+05:30','DEV','B-204','VERIFIED','Signed return accepted at 17:24; later note conflicts with desk record.')
ON CONFLICT(note_id) DO UPDATE SET created_at=EXCLUDED.created_at,author_id=EXCLUDED.author_id,subject_id=EXCLUDED.subject_id,note_status=EXCLUDED.note_status,note_text=EXCLUDED.note_text;
INSERT INTO public.sql04_messages VALUES
('MSG-01','2026-10-16 18:26:00+05:30','MAYA','POOJA','EVENT_CHAT','Hold the demo-room handover until the token list is reconciled. Please do not issue the replacement list yet.'),
('MSG-02','2026-10-16 18:39:00+05:30','POOJA','MAYA','EVENT_CHAT','The envelope is missing. Was it moved during your archive count?'),
('MSG-03','2026-10-16 18:51:00+05:30','MAYA','RHEA','EVENT_CHAT','The door log says B-204, so Ishaan must have kept his badge after all.'),
('MSG-04','2026-10-16 18:53:00+05:30','DEV','POOJA','EVENT_CHAT','B-204 was signed back in at 17:24. Maya took it for a scan after that.')
ON CONFLICT(message_id) DO UPDATE SET sent_at=EXCLUDED.sent_at,sender_id=EXCLUDED.sender_id,recipient_id=EXCLUDED.recipient_id,channel=EXCLUDED.channel,message_text=EXCLUDED.message_text;
COMMIT;
