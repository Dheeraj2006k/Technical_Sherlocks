# SQL04 — The Borrowed Badge
Version 1.0.0 · SQL track · Duo (exactly 2 players) · Target 15–20 minutes

## Package
- `player_release/SQL04_Player_Case.md`: player-facing briefing.
- `schema/001_sql04_schema.sql`: isolated case-evidence tables, prefixed `sql04_`.
- `seeds/seed_SQL04.sql`: deterministic upsert seed. Does not modify shared runtime state.
- `source_case_pack/SQL04_Case_Manifest.json`: version and case metadata.
- `source_case_pack/SQL04_Tasks.json`: six scored tasks, options, canonical queries and answer keys. Server-side only.
- `source_case_pack/SQL04_Hints.json`: hint ladders. Serve through server-authorized endpoints.
- `source_case_pack/SQL04_Author_Notes_and_Answer_Key.md`: restricted solution.
- `source_case_pack/SQL04_Scoring_and_Hints.md`: score contract.
- `verification/verify_SQL04.sql`: data-integrity checks.
- `tests/SQL04_Acceptance_Tests.md`: staging, security and blind-playtest checklist.

## Staging install
1. Apply the case schema in a non-production Supabase project.
2. Run the seed.
3. Run the verification SQL and require every check to pass.
4. Register tasks and phase-unlock rules in the existing SQL game engine. Do not send task answers/canonical queries to the browser.
5. Test through the same read-only query API players use.

## Integration boundary
The `sql04_*` tables contain case evidence only. They do not replace shared platform tables for assignments, sessions, attempts, completions, hints-used counters, scoring ledger or leaderboard. Integrate the task manifest with your canonical engine. Server-side APIs must enforce assignment, phase unlocks, idempotency and score calculation.

## Security
Never expose service-role credentials. Student SQL must run under a restricted read-only role and reject writes, DDL, multiple statements, system catalogs and cross-case access. Enforce statement timeout, row cap and rate limits. Keep all author files off the client bundle.

## Release status
Content package complete; live certification requires SQL execution in staging, query-service security testing, engine integration and a blind duo playtest. Do not describe the case as live-validated until these are complete.
