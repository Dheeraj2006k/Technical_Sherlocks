# SQL03 — The Missing Batch
**Version:** 1.0.0  
**Track:** SQL  
**Intended team size:** 2 players (duo)  
**Target solve time:** 15–20 minutes  
**Status:** Content-complete package; staging execution and live-engine integration are release gates.

## Package contents
- `player_release/SQL03_Player_Case.md` — player-facing briefing only.
- `schema/001_sql03_schema.sql` — namespaced case evidence schema.
- `seeds/seed_SQL03.sql` — deterministic, repeatable case seed; does not reset team progress.
- `source_case_pack/SQL03_Tasks.json` — six tasks, canonical queries, correct options and grading metadata. **Keep server-side.**
- `source_case_pack/SQL03_Hints.json` — progressive hints. Serve hints according to the engine's hint rules.
- `source_case_pack/SQL03_Case_Manifest.json` — case identity, phase order, team size and content version.
- `source_case_pack/SQL03_Author_Notes_and_Answer_Key.md` — restricted narrative solution and evidence map.
- `source_case_pack/SQL03_Scoring_and_Hints.md` — scoring contract.
- `verification/verify_SQL03.sql` — structural and narrative-data checks.
- `tests/SQL03_Acceptance_Tests.md` — manual and automated acceptance checklist.

## Staging install
1. Use a non-production Supabase project.
2. Run `schema/001_sql03_schema.sql`.
3. Run `seeds/seed_SQL03.sql`.
4. Run `verification/verify_SQL03.sql`; every assertion should return `PASS`.
5. Register the case in the existing game engine using the manifest and task JSON. Do not expose task answer keys or canonical solutions to the browser.
6. Run the acceptance tests with two first-time players.

## Important integration boundary
This schema is namespaced (`sql03_*`) and stores case evidence only. It does **not** replace the shared game runtime tables for team assignments, sessions, attempts, completions, hints-used counters, score ledger, or leaderboard. Connect `SQL03_Tasks.json` to the canonical SQL-track task registry in your engine. The game API—not the client—must validate answers and award points.

## Security requirements
- Students must query through a server-controlled, read-only query service.
- Never provide a Supabase service-role key to clients.
- Allow only a single read-only statement; reject DDL/DML, multiple statements, system catalog access and cross-case queries.
- Apply statement timeout, row cap, query rate limit, and server-side assignment/phase checks.
- Keep task answer keys and this package's author files off the client.
- Do not run seed scripts against a live project until staging checks pass.

## Repeatability
Seed statements use stable IDs and `ON CONFLICT` updates for case content. Re-running the seed should converge to the same evidence data and must not delete runtime player state.
