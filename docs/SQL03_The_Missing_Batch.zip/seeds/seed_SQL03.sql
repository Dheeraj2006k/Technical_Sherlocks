BEGIN;
INSERT INTO public.sql03_case(case_id,title,content_version,intended_team_size,release_status)
VALUES ('SQL03','The Missing Batch','1.0.0',2,'content_complete_staging_validation_required')
ON CONFLICT(case_id) DO UPDATE SET title=EXCLUDED.title,content_version=EXCLUDED.content_version,
 intended_team_size=EXCLUDED.intended_team_size,release_status=EXCLUDED.release_status;

INSERT INTO public.sql03_characters(character_id,display_name,role,public_description) VALUES
('AARAV','Aarav Mehta','Print-room operator','Operates the badge printer and logs print jobs.'),
('NISHA','Nisha Varma','Event logistics coordinator','Controls the logistics cage and approves event movement records.'),
('KABIR','Kabir Shah','Delivery runner','Moves sealed packages along the event route.'),
('LEENA','Leena Das','Registration lead','Receives badges at the registration desk.'),
('DEV','Dev Malhotra','Production supervisor','Owns print-room scheduling and signs routine job summaries.'),
('TARA','Tara Iyer','Volunteer coordinator','Requested an unrelated lanyard order earlier that day.')
ON CONFLICT(character_id) DO UPDATE SET display_name=EXCLUDED.display_name,role=EXCLUDED.role,public_description=EXCLUDED.public_description;

INSERT INTO public.sql03_print_jobs(job_id,batch_id,requested_by,printed_by,created_at,quantity,destination,approval_ref,job_status,note) VALUES
('J-170','B-17','DEV','AARAV','2026-10-16 14:32:00+05:30',12,'Registration Desk','APR-170','PRINTED','Original finalist badge batch.'),
('J-171','B-17R','NISHA','AARAV','2026-10-16 15:02:00+05:30',12,'Registration Desk','APR-044','PRINTED','Replacement batch requested after the original was put on hold.'),
('J-044','L-04','TARA','AARAV','2026-10-16 11:10:00+05:30',40,'Volunteer Desk','APR-044','CLOSED','Unrelated lanyard order; approval reference APR-044 belongs here.')
ON CONFLICT(job_id) DO UPDATE SET batch_id=EXCLUDED.batch_id,requested_by=EXCLUDED.requested_by,printed_by=EXCLUDED.printed_by,created_at=EXCLUDED.created_at,quantity=EXCLUDED.quantity,destination=EXCLUDED.destination,approval_ref=EXCLUDED.approval_ref,job_status=EXCLUDED.job_status,note=EXCLUDED.note;

INSERT INTO public.sql03_custody_scans(scan_id,batch_id,event_at,location,scanned_by,scan_type,package_state,note) VALUES
('CS-01','B-17','2026-10-16 14:39:00+05:30','Print Room','NISHA','QUALITY_HOLD','SEALED','Nisha places original batch on hold; no failed quality measurement is recorded.'),
('CS-02','B-17','2026-10-16 14:44:00+05:30','Logistics Cage','NISHA','CUSTODY_IN','SEALED','Original sleeve enters logistics cage under Nisha custody.'),
('CS-03','B-17','2026-10-16 14:49:00+05:30','Dispatch Bay','KABIR','TOTE_SCAN','EMPTY_TOTE','Kabir scans route tote; scan is not acceptance of batch B-17.'),
('CS-04','B-17R','2026-10-16 15:08:00+05:30','Logistics Cage','NISHA','CUSTODY_OUT','SEALED','Replacement sleeve leaves cage under Nisha badge.'),
('CS-05','B-17R','2026-10-16 15:14:00+05:30','Registration Desk','KABIR','ROUTE_DROP','SEALED','Kabir delivers replacement batch to desk.'),
('CS-06','B-17','2026-10-16 15:17:00+05:30','Registration Desk','LEENA','RECEIPT_CHECK','EMPTY_SLEEVE','Original batch ID appears on empty sleeve; zero badges received.'),
('CS-07','B-17R','2026-10-16 15:18:00+05:30','Registration Desk','LEENA','RECEIPT_CHECK','SEALED','Desk confirms 12 badges in replacement batch.'),
('CS-08','B-17','2026-10-16 15:24:00+05:30','Admin Desk','NISHA','INCIDENT_NOTE','UNKNOWN','Nisha states original was handed to Kabir at 14:46.')
ON CONFLICT(scan_id) DO UPDATE SET batch_id=EXCLUDED.batch_id,event_at=EXCLUDED.event_at,location=EXCLUDED.location,scanned_by=EXCLUDED.scanned_by,scan_type=EXCLUDED.scan_type,package_state=EXCLUDED.package_state,note=EXCLUDED.note;

INSERT INTO public.sql03_route_manifests(manifest_id,batch_id,created_at,route_name,planned_runner,manifest_type,status,note) VALUES
('RM-17','B-17','2026-10-16 14:46:00+05:30','Print Room → Registration Desk','KABIR','PLANNED_ROUTE','GENERATED','Generated from planned route; not a physical custody acceptance.'),
('RM-17R','B-17R','2026-10-16 15:05:00+05:30','Print Room → Registration Desk','KABIR','PLANNED_ROUTE','GENERATED','Route manifest generated after replacement print.')
ON CONFLICT(manifest_id) DO UPDATE SET batch_id=EXCLUDED.batch_id,created_at=EXCLUDED.created_at,route_name=EXCLUDED.route_name,planned_runner=EXCLUDED.planned_runner,manifest_type=EXCLUDED.manifest_type,status=EXCLUDED.status,note=EXCLUDED.note;

INSERT INTO public.sql03_desk_receipts(receipt_id,batch_id,received_at,received_by,item_received,quantity_received,condition_note) VALUES
('DR-17','B-17','2026-10-16 15:17:00+05:30','LEENA','EMPTY_SLEEVE',0,'Original batch sleeve arrived without badges.'),
('DR-17R','B-17R','2026-10-16 15:18:00+05:30','LEENA','SEALED_BADGE_PACK',12,'Replacement batch received and counted.')
ON CONFLICT(receipt_id) DO UPDATE SET batch_id=EXCLUDED.batch_id,received_at=EXCLUDED.received_at,received_by=EXCLUDED.received_by,item_received=EXCLUDED.item_received,quantity_received=EXCLUDED.quantity_received,condition_note=EXCLUDED.condition_note;

INSERT INTO public.sql03_approval_audit(audit_id,request_id,action_at,actor_id,action,approval_ref,result,note) VALUES
('AA-01','REQ-170','2026-10-16 14:30:00+05:30','DEV','APPROVE','APR-170','APPROVED','Approved original batch B-17 for 12 finalist badges.'),
('AA-02','REQ-171','2026-10-16 14:54:00+05:30','NISHA','REQUEST_REPRINT','APR-044','REJECTED','Approval reference belongs to lanyard order L-04; no valid replacement approval.'),
('AA-03','REQ-171','2026-10-16 14:56:00+05:30','DEV','REVIEW','APR-044','PENDING','Supervisor has not approved replacement request.'),
('AA-04','INC-17','2026-10-16 15:20:00+05:30','LEENA','OPEN_INCIDENT',NULL,'OPEN','Missing original batch reported by registration desk.')
ON CONFLICT(audit_id) DO UPDATE SET request_id=EXCLUDED.request_id,action_at=EXCLUDED.action_at,actor_id=EXCLUDED.actor_id,action=EXCLUDED.action,approval_ref=EXCLUDED.approval_ref,result=EXCLUDED.result,note=EXCLUDED.note;

INSERT INTO public.sql03_messages(message_id,sent_at,sender_id,recipient_id,channel,message_text) VALUES
('M-01','2026-10-16 14:41:00+05:30','NISHA','AARAV','EVENT_CHAT','Hold B-17 for a moment. I need to check something before it leaves the cage.'),
('M-02','2026-10-16 14:57:00+05:30','NISHA','AARAV','EVENT_CHAT','Print B-17R now. We cannot have the finalist photo delayed. I will sort the approval reference.'),
('M-03','2026-10-16 15:12:00+05:30','NISHA','KABIR','EVENT_CHAT','Take the replacement to registration; please do not describe it as a reprint yet.'),
('M-04','2026-10-16 15:24:00+05:30','NISHA','DEV','EVENT_CHAT','The first sleeve went with Kabir at 14:46. We can mark the replacement as the same batch until the sponsor photo is done.'),
('M-05','2026-10-16 15:25:00+05:30','KABIR','LEENA','EVENT_CHAT','I only scanned the empty tote at dispatch. I never received a sealed B-17 sleeve.'),
('M-06','2026-10-16 15:27:00+05:30','AARAV','DEV','EVENT_CHAT','I printed what the job queue showed. I did not authorize either batch.')
ON CONFLICT(message_id) DO UPDATE SET sent_at=EXCLUDED.sent_at,sender_id=EXCLUDED.sender_id,recipient_id=EXCLUDED.recipient_id,channel=EXCLUDED.channel,message_text=EXCLUDED.message_text;
COMMIT;
