# SQL03 Acceptance Tests

## Data and repeatability
- [ ] Apply schema in staging without errors.
- [ ] Run seed twice; counts remain stable and no duplicate rows appear.
- [ ] Run verification SQL; all checks return PASS.
- [ ] Confirm all foreign keys resolve.
- [ ] Confirm task JSON parses and contains six unique task IDs, four options per task, exactly one correct option per task.
- [ ] Confirm hint JSON has a complete ladder for every task.
- [ ] Confirm investigation points (6 × 10) + person (25) + explanation (15) = 100.

## Query-engine security
- [ ] Run as the restricted student query role, not service role.
- [ ] Student cannot INSERT/UPDATE/DELETE/DDL or issue multiple statements.
- [ ] Student cannot read answer keys, tasks JSON, hidden hints or other cases.
- [ ] Enforce assigned-case and phase-unlock checks server-side.
- [ ] Statement timeout, row cap, and rate limit work.
- [ ] No credentials or session tokens appear in query logs.

## Narrative fairness and duo playtest
- [ ] Two first-time players solve without author intervention in 15–20 minutes.
- [ ] A team can split work: one traces batch/custody; the other audits approval and message records.
- [ ] Each scored question is answerable from currently unlocked tables.
- [ ] Phase 1 contains enough context to start; no later-phase answer is required early.
- [ ] Kabir is not cleared solely by missing data; the empty-tote scan and downstream records are visible.
- [ ] Aarav is not blamed solely because he printed both jobs.
- [ ] Final answer does not claim a known physical destination for the missing badges.
- [ ] Hints help without directly naming the culprit before the final tasks.
