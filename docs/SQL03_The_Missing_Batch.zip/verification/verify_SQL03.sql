-- SQL03 structural verification. Each query should return PASS.
WITH checks AS (
 SELECT 'case row' AS check_name, (SELECT count(*)=1 FROM public.sql03_case WHERE case_id='SQL03') AS ok
 UNION ALL SELECT 'six characters', (SELECT count(*)=6 FROM public.sql03_characters)
 UNION ALL SELECT 'three print jobs', (SELECT count(*)=3 FROM public.sql03_print_jobs)
 UNION ALL SELECT 'eight custody scans', (SELECT count(*)=8 FROM public.sql03_custody_scans)
 UNION ALL SELECT 'two route manifests', (SELECT count(*)=2 FROM public.sql03_route_manifests)
 UNION ALL SELECT 'two desk receipts', (SELECT count(*)=2 FROM public.sql03_desk_receipts)
 UNION ALL SELECT 'four approval audit rows', (SELECT count(*)=4 FROM public.sql03_approval_audit)
 UNION ALL SELECT 'six messages', (SELECT count(*)=6 FROM public.sql03_messages)
 UNION ALL SELECT 'original batch count is 12', (SELECT quantity=12 AND destination='Registration Desk' FROM public.sql03_print_jobs WHERE job_id='J-170')
 UNION ALL SELECT 'replacement uses mismatched approval', (SELECT j.approval_ref='APR-044' AND a.result='REJECTED' FROM public.sql03_print_jobs j JOIN public.sql03_approval_audit a ON a.approval_ref=j.approval_ref WHERE j.job_id='J-171' AND a.audit_id='AA-02')
 UNION ALL SELECT 'original sleeve received empty', (SELECT quantity_received=0 AND item_received='EMPTY_SLEEVE' FROM public.sql03_desk_receipts WHERE receipt_id='DR-17')
 UNION ALL SELECT 'replacement received with 12', (SELECT quantity_received=12 FROM public.sql03_desk_receipts WHERE receipt_id='DR-17R')
)
SELECT check_name, CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END AS result FROM checks ORDER BY check_name;

-- Useful author-side timeline view; do not expose author notes to players.
SELECT event_at AS event_time, 'custody' AS source, batch_id, scan_type AS event_type,
       scanned_by AS actor, package_state AS detail
FROM public.sql03_custody_scans
UNION ALL
SELECT created_at, 'print_job', batch_id, job_status, requested_by, 'qty='||quantity||'; printed_by='||printed_by
FROM public.sql03_print_jobs
ORDER BY event_time;
