-- SQL03 case evidence schema. Namespaced and isolated from shared runtime tables.
CREATE TABLE IF NOT EXISTS public.sql03_case (
  case_id text PRIMARY KEY,
  title text NOT NULL,
  content_version text NOT NULL,
  intended_team_size smallint NOT NULL CHECK (intended_team_size = 2),
  release_status text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_characters (
  character_id text PRIMARY KEY,
  display_name text NOT NULL,
  role text NOT NULL,
  public_description text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_print_jobs (
  job_id text PRIMARY KEY,
  batch_id text NOT NULL,
  requested_by text NOT NULL REFERENCES public.sql03_characters(character_id),
  printed_by text NOT NULL REFERENCES public.sql03_characters(character_id),
  created_at timestamptz NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  destination text NOT NULL,
  approval_ref text,
  job_status text NOT NULL,
  note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_custody_scans (
  scan_id text PRIMARY KEY,
  batch_id text NOT NULL,
  event_at timestamptz NOT NULL,
  location text NOT NULL,
  scanned_by text NOT NULL REFERENCES public.sql03_characters(character_id),
  scan_type text NOT NULL,
  package_state text NOT NULL,
  note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_route_manifests (
  manifest_id text PRIMARY KEY,
  batch_id text NOT NULL,
  created_at timestamptz NOT NULL,
  route_name text NOT NULL,
  planned_runner text NOT NULL REFERENCES public.sql03_characters(character_id),
  manifest_type text NOT NULL,
  status text NOT NULL,
  note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_desk_receipts (
  receipt_id text PRIMARY KEY,
  batch_id text NOT NULL,
  received_at timestamptz NOT NULL,
  received_by text NOT NULL REFERENCES public.sql03_characters(character_id),
  item_received text NOT NULL,
  quantity_received integer NOT NULL CHECK (quantity_received >= 0),
  condition_note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_approval_audit (
  audit_id text PRIMARY KEY,
  request_id text NOT NULL,
  action_at timestamptz NOT NULL,
  actor_id text NOT NULL REFERENCES public.sql03_characters(character_id),
  action text NOT NULL,
  approval_ref text,
  result text NOT NULL,
  note text NOT NULL
);
CREATE TABLE IF NOT EXISTS public.sql03_messages (
  message_id text PRIMARY KEY,
  sent_at timestamptz NOT NULL,
  sender_id text NOT NULL REFERENCES public.sql03_characters(character_id),
  recipient_id text NOT NULL REFERENCES public.sql03_characters(character_id),
  channel text NOT NULL,
  message_text text NOT NULL
);

CREATE INDEX IF NOT EXISTS sql03_print_jobs_batch_idx ON public.sql03_print_jobs(batch_id);
CREATE INDEX IF NOT EXISTS sql03_custody_scans_batch_time_idx ON public.sql03_custody_scans(batch_id,event_at);
CREATE INDEX IF NOT EXISTS sql03_approval_audit_request_idx ON public.sql03_approval_audit(request_id,action_at);
CREATE INDEX IF NOT EXISTS sql03_messages_time_idx ON public.sql03_messages(sent_at);
