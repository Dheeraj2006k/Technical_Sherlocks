# RESTRICTED — SQL03 Author Notes and Answer Key
Do not distribute this file to players or bundle it into client assets.

## Canonical solution
**Responsible person: Nisha Varma.**  
**Explanation: Nisha diverted the original B-17 sleeve before it reached the runner, initiated B-17R as an unapproved replacement to cover the shortage, and delayed the missing-batch report until the reprint could be presented as the intended delivery.** The evidence supports deliberate diversion/cover-up; it does not establish what happened to the physical badges after diversion, so the final answer must not claim that she sold or destroyed them.

## Timeline
- 14:32 — Aarav prints the original B-17 batch: 12 badges, destination event desk.
- 14:39 — Nisha records a quality hold on B-17. The hold is a status record, not proof of defect; no failed QC measurement exists.
- 14:44 — B-17 sleeve is scanned into the logistics cage under Nisha's custody.
- 14:46 — Dispatch manifest is generated, but it is generated from the planned route and is not a custody acceptance.
- 14:49 — Kabir's runner scan shows an empty route tote, not acceptance of B-17.
- 14:54 — Nisha initiates B-17R, quantity 12, using an approval reference that belongs to an unrelated lanyard order.
- 15:02 — B-17R is printed by Aarav. The printer operator is not the authorizing person.
- 15:08 — B-17R is scanned out under Nisha's badge.
- 15:17 — Registration desk records receipt of an empty B-17 sleeve; it did not receive the badges.
- 15:20 — Missing-batch incident is opened.
- 15:24 — Nisha posts that the original package was handed to Kabir at 14:46. The custody records do not support that statement.
- 15:28 — Messages show Nisha asking for the reprint to be treated as the original batch until the evening sponsor photo is finished. This provides a motive to avoid visible disruption, not proof of financial theft.

## Twists
1. The manifest timestamp looks like dispatch, but it is a planned route manifest, not a physical handoff.
2. Kabir's scan is for an empty tote, not the sealed badge sleeve.
3. Aarav printed both batches, but printer activity alone does not identify the person who diverted the original.
4. The reprint's approval reference is valid-looking but belongs to a different order.
5. Nisha's later statement conflicts with the custody trail; the messages explain why she wanted the replacement to be treated as original.

## Fairness guardrails
- Do not claim the database proves where the original badges ended up. It proves the official custody trail breaks while Nisha is recorded as custodian, plus her unapproved reprint and cover-up message.
- Kabir is cleared by a specific missing acceptance scan and a tote scan showing empty status; avoid stating that lack of a scan alone proves innocence. The combined route and receipt evidence does the work.
- Aarav is not guilty merely because he operated the printer. Nisha's reprint request and badge-authorized scans distinguish printer operation from authorization/custody.
- Leena's desk receipt is after the custody gap and describes an empty sleeve, so it cannot establish possession of the badges.
- Do not seed more clues that explicitly say “Nisha stole the badges”; the player must infer it from joined records.
