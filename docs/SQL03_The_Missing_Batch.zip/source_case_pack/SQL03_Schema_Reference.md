The case-specific SQL schema is in `schema/001_sql03_schema.sql`. It creates namespaced `sql03_*` evidence tables and does not replace shared runtime tables.
