# LOG06 — Scoring, Answers and Hints (RESTRICTED)

## Scoring
- T1–T6: 10 points each = 60.
- Responsible person: 25 points.
- Final explanation: 15 points.
- Maximum: 100.
- Hint ladder per task: 10 / 8 / 6 / 4 / 2.
- Wrong committed answer: −2; score floor 0.
- Grade final person and explanation independently. Award each successful component only once.

## Answer key
- **T1:** C — The demo played for 42 seconds even though the approved cue called for a 2-minute file.
- **T2:** A — The final 2-minute file was successfully submitted before the cutoff.
- **T3:** D — Arjun’s logged custody does not explain the mismatch; the drive was returned with its seal intact.
- **T4:** B — A short rehearsal source was exported under Nisha’s account using the same filename as the final file.
- **T5:** A — It independently places Nisha at the workstation during the short export, while still not proving intent on its own.
- **T6:** C — Nisha knowingly exported the 42-second rehearsal cut under the final filename before the drive was sealed, intending to disrupt Comet’s reveal and create an opening for Orbit.
- **Final person:** Nisha Rao (`nisha_rao`).
- **Final explanation:** C.

## Hints (ordered from broad to explicit)

### T1
1. Compare the actual duration with the planned duration.
2. The cue calls for 2:00.
3. The incident card says playback stopped after 00:42.
4. The title was Comet’s, but the run was too short.
5. Choose the mismatch without guessing its cause.

### T2
1. The receipt is evidence of submission, not later playback.
2. The upload was at 3:36 PM.
3. It records a 2-minute file and checksum 91C4.
4. The later player report has a different checksum.
5. Select what the receipt proves directly.

### T3
1. Separate physical custody from the file’s earlier preparation.
2. The seal was intact when returned.
3. Arjun did not open the drive according to the log.
4. The mismatch must be investigated before handoff.
5. Choose the conclusion supported by the seal and custody record.

### T4
1. Compare the source and duration in the export record.
2. The export was 42 seconds.
3. Its source was Comet_Rehearsal_cut.mp4.
4. The account was Nisha’s, but that alone does not prove intent.
5. Choose the exact relationship between source, name and account.

### T5
1. The photo and audit answer different questions.
2. The photo is timestamped 3:50 PM.
3. It shows Nisha at the workstation and an export in progress.
4. Pair that with the 3:49 PM audit, but avoid overclaiming.
5. Choose the conclusion that combines timing and limits.

### T6
1. The original upload remains intact.
2. The playback copy has a different checksum and matches the rehearsal cut.
3. The export happened before the drive was sealed, and the photo places Nisha at the workstation.
4. Read the cue draft alongside the export and rehearsal-only end card.
5. Choose the explanation that fits the file trail, timing and motive without blaming custody unsupportedly.
