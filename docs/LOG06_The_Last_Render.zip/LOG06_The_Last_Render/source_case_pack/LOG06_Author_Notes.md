# LOG06 — The Last Render: Author Notes (RESTRICTED)

## Intended solution
Nisha Rao deliberately exported the 42-second rehearsal cut from `Comet_Rehearsal_cut.mp4` under the filename `Comet_Final_v7.mp4` before the playback drive was sealed. She intended the skipped reveal to disrupt Team Comet and give Team Orbit a chance to use the spare slot.

## Deduction chain
1. The approved cue and incident card establish the 2:00 vs 0:42 mismatch.
2. The upload receipt proves Dev’s correct 2-minute file was submitted before cutoff, checksum 91C4.
3. Playback report says checksum 7A20 and 00:42, ruling out the submitted file as the actual playback copy.
4. Export history says a rehearsal source was exported to the final filename at 3:49 PM under Nisha’s account.
5. The drive was sealed after preparation and returned unopened, weakening the theory that Arjun swapped it later.
6. A timestamped reflection photo places Nisha at the workstation during the export.
7. The rehearsal-only end card identifies the short source, and Nisha’s cue draft states the intended consequence.

## Twists
- First suspicion: Dev may have submitted the wrong file; the receipt and archived source clear him.
- Second suspicion: Arjun had custody of the drive; the intact seal and pre-handoff export chronology clear him.
- Third suspicion: Tara handled labels and copying; her earlier label sheet correctly identifies the final duration and checksum.
- Resolution: Nisha’s account log is not used alone; it converges with photo, source/output mismatch and motive note.

## Fairness cautions
- Do not describe account logs as proof of a human identity on their own. The timestamped photo is required corroboration.
- The cue draft is a motive clue, not sufficient by itself; it becomes decisive only with the version-chain evidence.
- Do not expose the correct keys or this file to client code.
- The event’s media workstation, logs and physical records are fictional evidence objects in the game; they should not be presented as real-world forensic guarantees.

## Release status
Draft package assembled. Independent review, staging seed execution, phase-access/security tests and at least two first-time solo playtests remain required before live use.
