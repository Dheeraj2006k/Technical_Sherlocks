# LOG06 Validation Checklist

## Content checks
- [ ] Independent reviewer solves case without author notes.
- [ ] Each task answer follows from evidence already unlocked.
- [ ] No task requires technical knowledge beyond reading the stated records.
- [ ] Red herrings are cleared by evidence rather than author explanation.
- [ ] At least two first-time solo players finish in 12–18 minutes and explain the chain.

## Database and platform checks
- [ ] Apply shared schema once in staging.
- [ ] Run `seed_LOG06.sql`; verify transaction completes.
- [ ] Run `verify_LOG06.sql`; expected rows and score total match.
- [ ] Test repeat seeding and confirm no duplicate rows.
- [ ] Confirm player endpoints return only unlocked evidence and never answer keys.
- [ ] Confirm hints, retries, penalties and successful completion are server-authoritative and idempotent.
- [ ] Confirm answer keys, manifest, author notes and scoring file are not bundled into client assets.
- [ ] Only mark `live_release` passed after all prior gates pass.
