# LOG06 — The Last Render

**Version:** 1.0.0  
**Track:** Logic  
**Recommended team size:** 1 (solo)  
**Estimated play time:** 12–18 minutes  
**Status:** Database-complete case package; live release gates remain pending.

## Package contents
- `source_case_pack/LOG06_Player_Case.md` — player-facing case.
- `source_case_pack/LOG06_Author_Notes.md` — restricted solution and fairness notes.
- `source_case_pack/LOG06_Scoring_and_Hints.md` — restricted answer key and hints.
- `source_case_pack/LOG06_Case_Manifest.json` — restricted structured manifest with answer keys.
- `seeds/seed_LOG06.sql` — idempotent upsert into shared Logic content tables.
- `schema/001_logic_case_content_schema.sql` — copy of shared schema for reference; apply once per project, not per case.
- `verification/verify_LOG06.sql` — counts, relationships, score total and release-gate checks.

## Seed order
1. In Supabase staging, apply the shared schema once if it is not already installed.
2. Run `seeds/seed_LOG06.sql`.
3. Run `verification/verify_LOG06.sql`. Expected: 6 characters, 12 evidence items, 6 tasks, 24 task options, 30 hints, 6 final-person options, 4 explanation options, and 100 total points. The incomplete-task query should return zero rows.
4. Repeat the seed once to verify idempotency.

## Scoring
Six tasks × 10 = 60; final person = 25; final explanation = 15; total = 100. Hint rewards 10/8/6/4/2. Wrong committed answers cost 2 points; score floor is zero. Grade final components independently and award each success only once.

## Security
All answer keys, author notes, the scoring file and manifest must remain server-side. Player clients must receive only the currently unlocked evidence and public option text through trusted endpoints that verify assignment and phase. Never ship service-role credentials to the browser.

## Release gate
The seed has been generated and statically checked for consistent counts and scoring. It has **not** been executed against your Supabase instance. Complete independent logic/fairness review, staging execution, phase access and scoring/idempotency tests, and at least two first-time solo playtests before marking the case live.
