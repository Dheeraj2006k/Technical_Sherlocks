-- LOG06 seed verification. Run after seed_LOG06.sql in staging.
select case_id,title,content_version,release_status,recommended_team_size,max_score from public.logic_case_catalog where case_id='LOG06';
select phase_number,phase_name from public.logic_case_phases where case_id='LOG06' order by phase_number;
select count(*) as character_count from public.logic_case_characters where case_id='LOG06'; -- expect 6
select count(*) as evidence_count from public.logic_case_evidence where case_id='LOG06'; -- expect 12
select count(*) as task_count, sum(max_points) as investigation_points from public.logic_case_tasks where case_id='LOG06'; -- expect 6, 60
select count(*) as option_count from public.logic_case_task_options where case_id='LOG06'; -- expect 24
select count(*) as hint_count from public.logic_case_task_hints where case_id='LOG06'; -- expect 30
select count(*) as final_person_options from public.logic_case_final_person_options where case_id='LOG06'; -- expect 6
select count(*) as final_explanation_options from public.logic_case_final_explanation_options where case_id='LOG06'; -- expect 4
select d.responsible_person_points,d.explanation_points, sum(t.max_points) as investigation_points, d.responsible_person_points+d.explanation_points+sum(t.max_points) as total_points from public.logic_case_final_deductions d join public.logic_case_tasks t using(case_id) where d.case_id='LOG06' group by d.responsible_person_points,d.explanation_points; -- expect 25 + 15 + 60 = 100
-- Must return zero rows: any task without exactly four options or five hints.
select t.task_id, count(distinct o.option_key) as options, count(distinct h.hint_number) as hints from public.logic_case_tasks t left join public.logic_case_task_options o using(case_id,task_id) left join public.logic_case_task_hints h using(case_id,task_id) where t.case_id='LOG06' group by t.task_id having count(distinct o.option_key) <> 4 or count(distinct h.hint_number) <> 5;
-- Must return zero rows: broken character references or task phase references.
select 'final_character_missing' as issue where not exists(select 1 from public.logic_case_final_deductions d join public.logic_case_characters c on c.case_id=d.case_id and c.character_id=d.correct_character_id where d.case_id='LOG06') union all select 'phase_missing' where exists(select 1 from public.logic_case_tasks t left join public.logic_case_phases p using(case_id,phase_number) where t.case_id='LOG06' and p.case_id is null);
select gate_key,gate_status,notes from public.logic_case_release_gates where case_id='LOG06' order by gate_key;
