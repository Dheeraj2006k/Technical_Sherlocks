-- LOG05 verification queries. Run after schema and seed in staging.
-- Expected: catalog=1, phases=3, characters=6, evidence=12, tasks=6, options=24, hints=30,
-- final deduction=1, final person options=6, explanation options=4, release gates=8.
select 'catalog' as check_name,count(*) as actual,1 as expected from public.logic_case_catalog where case_id='LOG05'
union all select 'phases',count(*),3 from public.logic_case_phases where case_id='LOG05'
union all select 'characters',count(*),6 from public.logic_case_characters where case_id='LOG05'
union all select 'evidence',count(*),12 from public.logic_case_evidence where case_id='LOG05'
union all select 'tasks',count(*),6 from public.logic_case_tasks where case_id='LOG05'
union all select 'task_options',count(*),24 from public.logic_case_task_options where case_id='LOG05'
union all select 'task_hints',count(*),30 from public.logic_case_task_hints where case_id='LOG05'
union all select 'final_deduction',count(*),1 from public.logic_case_final_deductions where case_id='LOG05'
union all select 'final_person_options',count(*),6 from public.logic_case_final_person_options where case_id='LOG05'
union all select 'final_explanation_options',count(*),4 from public.logic_case_final_explanation_options where case_id='LOG05'
union all select 'release_gates',count(*),8 from public.logic_case_release_gates where case_id='LOG05';

-- Must return zero rows: tasks without exactly four options or five hints.
select t.task_id,
  (select count(*) from public.logic_case_task_options o where o.case_id=t.case_id and o.task_id=t.task_id) as option_count,
  (select count(*) from public.logic_case_task_hints h where h.case_id=t.case_id and h.task_id=t.task_id) as hint_count
from public.logic_case_tasks t
where t.case_id='LOG05'
  and ((select count(*) from public.logic_case_task_options o where o.case_id=t.case_id and o.task_id=t.task_id) <> 4
    or (select count(*) from public.logic_case_task_hints h where h.case_id=t.case_id and h.task_id=t.task_id) <> 5);

-- Must return 100 for max-score total.
select c.case_id,
  (select sum(max_points) from public.logic_case_tasks t where t.case_id=c.case_id)
  + d.responsible_person_points + d.explanation_points as computed_max_score,
  c.max_score as configured_max_score
from public.logic_case_catalog c join public.logic_case_final_deductions d using (case_id)
where c.case_id='LOG05';

-- Review gates still pending/fail until actually tested; this query must not be mistaken for proof that gates passed.
select gate_key,gate_status,notes from public.logic_case_release_gates where case_id='LOG05' order by gate_key;
