# LOG05 — The Duplicate Invitation

**Content version:** 1.0.0  
**Recommended team size:** 1 (solo)  
**Status:** Content/seed package prepared; live release gates remain pending.

## Contents
- `source_case_pack/LOG05_Player_Case.md` — safe player-facing case.
- `source_case_pack/LOG05_Author_Notes.md` — restricted intended solution and fairness notes.
- `source_case_pack/LOG05_Scoring_and_Hints.md` — restricted answer key and scoring.
- `source_case_pack/LOG05_Case_Manifest.json` — structured case content and keys; server-side only.
- `seeds/seed_LOG05.sql` — idempotent case-content upsert.
- `schema/001_logic_case_content_schema.sql` — copy of the shared Logic content schema for reference; apply once per project, not per case.
- `verification/verify_LOG05.sql` — row-count, options/hints and scoring checks.

## Seed order
1. In a **development/staging** Supabase project, run the shared schema once if not already installed: `schema/001_logic_case_content_schema.sql`.
2. Run `seeds/seed_LOG05.sql`.
3. Run `verification/verify_LOG05.sql`; confirm counts match expected values, the missing-options query returns zero rows and computed score is 100.
4. Review all `logic_case_release_gates`. They are deliberately pending/fail until the corresponding tests are completed.

## Important security notes
- Do not send `source_manifest`, `correct_option_key`, final-deduction keys, author notes or scoring files to browser clients.
- Browser clients should call trusted server endpoints that check team assignment and unlocked phase before returning evidence/options.
- The shared schema revokes browser access and enables RLS on content tables; verify actual service-role/server access patterns and policies in your project. Never put a Supabase service-role key in client code.
- This package covers case-content tables only. It does not create shared runtime tables for teams, assignments, sessions, attempts, completions, score ledger or leaderboard.

## Case design summary
Six deterministic tasks, two per phase; 12 evidence records; six characters; final person and explanation graded independently. Six tasks award up to 60, final person 25 and explanation 15 = 100. Hint ladder: 10/8/6/4/2; incorrect committed answers −2 with a score floor of zero.

## Release gate
The SQL has not been run against the user's Supabase project. Do not treat successful file generation as a live deployment. Complete independent solve/fairness review, staging SQL execution, security/phase-unlock tests and at least two first-time solo playtests before marking live.
