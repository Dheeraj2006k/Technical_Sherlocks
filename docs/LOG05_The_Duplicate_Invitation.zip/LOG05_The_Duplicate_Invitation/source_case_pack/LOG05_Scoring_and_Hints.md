# LOG05 — Scoring and Hints (Restricted)

## Score allocation
- T1–T6: 10 points each = 60 points.
- Correct responsible person: 25 points.
- Correct explanation: 15 points.
- Maximum: 100 points.
- Wrong committed answer: −2 points, with total score floored at 0.
- Final person and explanation are graded independently and may be retried.
- Each task/component awards successful points only once. Store attempts separately from completion records.

## Hint reward ladder
For each ordinary task, reward 10, 8, 6, 4, or 2 points according to 0, 1, 2, 3, or 4+ hints used. The fifth hint is a final nudge and the reward remains 2. Hints are shared across the team (for this solo case, the player). Enforce hint counters and answer keys server-side.

## Answer key
- T1: B
- T2: A
- T3: C
- T4: A
- T5: D
- T6: B
- Final person: `aanya_nair`
- Final explanation: B

## Task hint text
Hints are progressive. The fifth hint is explicit enough to help a stuck player but does not simply reveal the final culprit for every task.
