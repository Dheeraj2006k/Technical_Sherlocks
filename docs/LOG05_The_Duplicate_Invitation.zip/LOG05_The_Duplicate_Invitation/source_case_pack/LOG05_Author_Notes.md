# LOG05 — Author Notes (Restricted)

## Intended solution
**Responsible person:** Aanya Nair (`aanya_nair`).
**Final explanation:** B.

Aanya deliberately printed a misleading copy of Team Orbit’s invitation with check-in at 4:30 PM while retaining the valid existing QR code ORB-041. Her stated aim was to delay Orbit past sound check so Team Nova would keep the first demo slot. She did not change the master schedule, which is why the official run sheet and email remain at 4:00 PM.

## Deduction chain
1. E01/E02/E03 establish the mismatch and its consequence.
2. E05 establishes that the officially sent version was correct.
3. E06 establishes a print job under Aanya’s account, but explicitly does not identify the operator.
4. E08 independently places Aanya at the printer collecting a sheet, without making the sheet text readable.
5. E09 connects the wrong time and reused QR to a discarded proof with handwriting consistent with Aanya’s shift note.
6. E10 supplies a contemporaneous motive and explicitly distinguishes changing the copy from changing the master.
7. E11 clears the misleading interpretation of Rohan’s genuine schedule revision; E12 shows Nova checked in normally and does not establish complicity.

## Twists
- The valid QR initially makes the invitation look legitimate, but it authenticates only the team record, not the printed time.
- Rohan really did edit the schedule, but the version history shows the check-in times did not change. This is a real red herring, not a false record.
- The printer log points to Aanya’s account but is not enough alone; the photo, physical proof and note must converge.
- Team Nova benefits, but no evidence shows Nova requested or knew about the deception.

## Fairness boundaries
- Do not ask players to infer guilt from a shared account or opportunity alone. E08, E09 and E10 are required corroboration.
- Handwriting comparison is a fictional in-world observation, not a forensic certainty; phrase it as “consistent with,” and pair it with the other evidence.
- The final answer is the person who deliberately made the misleading copy, not the person who changed the master schedule (Rohan), printed at the desk generally (Irfan), or benefited from the delay (Team Nova).
- Do not introduce a hidden clue during scoring. All necessary facts are in E01–E12.

## Intended play length
Solo target: 12–18 minutes for first-time players. Six short tasks, two per phase, then a two-part final deduction. This is a target, not a measured result; playtesting remains required.
