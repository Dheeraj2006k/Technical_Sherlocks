# LOG05 — Validation Checklist

## Content checks
- [x] Six characters with distinct roles.
- [x] Three phases with four evidence records each.
- [x] Six deterministic single-choice tasks, two per phase.
- [x] Four options and five progressive hints per task.
- [x] Final responsible-person and explanation components graded independently.
- [x] Total score is 100; ordinary task reward ladder matches shared rules.
- [x] Red herrings have evidence-backed explanations.
- [x] No clue requires identifying a real person or accessing external material.
- [x] Correct invitation, misleading copy, QR, print job, photograph and motive are cross-referenced.

## Release gates — not yet certified
- [ ] Independent reviewer solves the case using only player-facing evidence.
- [ ] Reviewer tests whether another character is reasonably supportable as culprit.
- [ ] Run SQL schema and seed against a clean staging Supabase project.
- [ ] Run verification SQL and confirm counts/relationships.
- [ ] Verify browser clients cannot read answer keys, hidden hints, or restricted notes.
- [ ] Verify only the assigned case and unlocked phase evidence can be retrieved.
- [ ] Test wrong-answer penalties, retries, idempotency and score floor.
- [ ] Run at least two solo playtests; target 12–18 minutes, revise if too easy or confusing.
- [ ] Freeze version and checksum before live event deployment.

**Status:** Content and seed artifacts prepared; staging execution, security testing, independent review and playtesting are pending. Do not label as live-certified until all applicable gates pass.
