# RESTRICTED — SQL02 Author Notes and Answer Key

**Do not ship this file or `SQL02_Tasks.json` with correct answers to the browser.**

## Ground truth

Dev Malhotra, the prop lead, discovered that the original Starfall Mask's clasp had cracked/sn agged during rehearsal. He returned the original to the prop bay at 18:57, placed the replica on the stage-left wing at 18:59, and told Sana not to notify the producer until after the show because he feared the finale would be cancelled. The replica was used in the finale. Dev moved the original to Repair Case 2, then admitted the unlogged move after the inventory mismatch was raised. This was a concealed safety/repair decision, not permanent theft.

## Canonical final deduction

- Responsible character: `DEV` — Dev Malhotra.
- Correct explanation: option `A` — he used the backup while keeping the original for a clasp repair and concealed the move to avoid cancellation.
- Wrong theories: Nikhil is cleared by the stage timeline; Kavya operated the cue but has no prop-bay handling evidence; Arjun's delivery manifest contains fabric rolls only.

## Phase/task answer key

- SQL02-T01: B
- SQL02-T02: C
- SQL02-T03: B
- SQL02-T04: B
- SQL02-T05: B
- SQL02-T06: A

## Deduction chain

1. IC02 independently confirms the original at stage-left at 18:55.
2. PM04 records the original returning to the prop bay at 18:57, handled by Dev.
3. PM05 records the replica moving from backup tray to stage-left at 18:59, handled by Dev.
4. CU02 records the planned original versus observed replica at the 19:05 finale cue; IC03 independently confirms the replica on the stand.
5. PM07 records the original moving into Repair Case 2, and IC05 later finds it there.
6. MSG03 explains why Dev concealed the move; MSG06 is an admission after the discrepancy is raised.

## Red herrings and fair clears

- **Nikhil:** his disagreement and stage-left access look suspicious. The ordered exit event and call-sheet note place him onstage before the original's 18:57 return; he has no original-mask movement record.
- **Kavya:** she triggered CUE-17, which played with the wrong item. The cue log proves cue execution, not prop custody; her role is AV booth and no prop-bay access event appears.
- **Arjun:** he opened the staff door during the window. The delivery note/manifest specifies fabric rolls; no mask movement is assigned to him.

## Fairness / consistency note

The access logs are credential events and must never be treated as conclusive identity proof on their own. The case's unique conclusion relies on the joined custody sequence and Dev's message/admission, not merely role access.
