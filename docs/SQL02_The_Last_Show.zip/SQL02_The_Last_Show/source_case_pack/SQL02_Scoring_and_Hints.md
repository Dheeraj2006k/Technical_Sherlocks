# SQL02 Scoring and Hints

- Six scored tasks × 10 points = 60.
- Correct culprit = 25 points.
- Correct explanation = 15 points.
- Maximum base score = 100.
- Hint reward per task follows the approved ladder: 10, 8, 6, 4, 2 points for 0–4 hints used.
- Each incorrect committed answer incurs −2 points. SQL exploration errors do not cost points.
- Retries are allowed. Each task and each final component awards points at most once. Server is authoritative; total score cannot fall below zero.
- All three team members share task completion and hint state. Team-size recommendation is three, but tasks are not split into private roles that could block a team if one member disconnects.

## Suggested collaboration

- Investigator 1: inspect character roles, role assignments and access records.
- Investigator 2: reconstruct prop movements and inventory state.
- Investigator 3: analyse cue events and messages, then cross-check all findings.
- Bring results together before committing answers. These are suggested workstreams, not required account permissions.
