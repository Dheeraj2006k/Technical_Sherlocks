# SQL02 — The Last Show (v1.0.0)

## Pack contents
- `schema/001_sql02_schema.sql` — exact case-specific PostgreSQL tables.
- `seeds/seed_SQL02.sql` — idempotent fictional data seed; does not touch team progress.
- `source_case_pack/SQL02_Player_Case.md` — player story.
- `source_case_pack/SQL02_Tasks.json` — task prompts, choices, answer keys and canonical investigation queries. **Server-side only** because it contains correct answers.
- `source_case_pack/SQL02_Hints.json` — five-step hint ladder per task.
- `source_case_pack/SQL02_Author_Notes_and_Answer_Key.md` — restricted ground truth and deductions.
- `source_case_pack/SQL02_Case_Manifest.json` — machine-readable case metadata.
- `verification/verify_SQL02.sql` — count and key-evidence checks.
- `tests/SQL02_Acceptance_Tests.md` — release checklist.

## Staging seed order
1. Use a development/staging Supabase project.
2. Run `schema/001_sql02_schema.sql` once (safe to rerun for these table definitions).
3. Run `seeds/seed_SQL02.sql`.
4. Run `verification/verify_SQL02.sql`.
5. Test the exact SQL query service and the three-player game flow.

The case tables are namespaced `sql02_` and separate from shared platform/runtime tables. Do not create one physical schema per team. Enforce case assignment and read-only access in the trusted query service.

## Important integration note
The repository context available for authoring did not include a canonical SQL-track task/configuration schema or the live app repository. Therefore, this pack includes a complete case-specific evidence schema and task JSON, but it does **not** pretend to seed unknown runtime tables such as team sessions, task attempts, score ledger, or phase unlock state. Adapt/import `SQL02_Tasks.json` into the project's actual shared task system once its schema is confirmed. Do not dynamically create runtime tables from case JSON.

## Release status
Content pack generated; manifest JSON parses; scoring is 6×10 + 25 + 15 = 100. SQL execution, security review, query endpoint integration, blind review and team-of-three playtest remain pending. Status must stay `review` until those gates pass.
