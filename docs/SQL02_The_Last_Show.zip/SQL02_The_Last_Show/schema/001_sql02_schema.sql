-- SQL02: The Last Show — case-specific read-only investigation dataset.
-- Apply once in a dedicated staging project. No runtime/team tables are created here.
-- All tables are namespaced sql02_ to avoid collisions with other cases.

create table if not exists public.sql02_characters (
  character_id text primary key,
  display_name text not null,
  role text not null,
  public_profile text not null
);
create table if not exists public.sql02_role_assignments (
  assignment_id text primary key,
  character_id text not null references public.sql02_characters(character_id),
  duty text not null,
  zone text not null,
  valid_from timestamptz not null,
  valid_to timestamptz not null,
  check (valid_to > valid_from)
);
create table if not exists public.sql02_access_events (
  event_id text primary key,
  event_time timestamptz not null,
  credential_id text not null,
  assigned_character_id text references public.sql02_characters(character_id),
  zone text not null,
  event_type text not null check (event_type in ('ENTRY','EXIT','DENIED')),
  note text not null
);
create table if not exists public.sql02_prop_movements (
  movement_id text primary key,
  event_time timestamptz not null,
  item_id text not null,
  item_label text not null,
  from_location text not null,
  to_location text not null,
  handled_by text not null references public.sql02_characters(character_id),
  logged_by text not null references public.sql02_characters(character_id),
  reason text not null,
  seal_status text not null check (seal_status in ('SEALED','OPEN','NOT_APPLICABLE'))
);
create table if not exists public.sql02_inventory_checks (
  check_id text primary key,
  checked_at timestamptz not null,
  location text not null,
  item_id text not null,
  item_label text not null,
  observed_condition text not null,
  checked_by text not null references public.sql02_characters(character_id),
  note text not null
);
create table if not exists public.sql02_cue_log (
  cue_event_id text primary key,
  event_time timestamptz not null,
  cue_code text not null,
  operator_id text not null references public.sql02_characters(character_id),
  planned_item_id text not null,
  observed_item_id text not null,
  result text not null,
  note text not null
);
create table if not exists public.sql02_messages (
  message_id text primary key,
  sent_at timestamptz not null,
  sender_id text not null references public.sql02_characters(character_id),
  recipient_id text not null references public.sql02_characters(character_id),
  channel text not null,
  subject text not null,
  body text not null
);

-- Do not expose these tables to anon/authenticated directly. Your trusted query API
-- should execute SELECT-only statements using a dedicated least-privilege role,
-- enforce case/team assignment, statement timeout and row limits, and reject DDL/DML.
alter table public.sql02_characters enable row level security;
alter table public.sql02_role_assignments enable row level security;
alter table public.sql02_access_events enable row level security;
alter table public.sql02_prop_movements enable row level security;
alter table public.sql02_inventory_checks enable row level security;
alter table public.sql02_cue_log enable row level security;
alter table public.sql02_messages enable row level security;
revoke all on public.sql02_characters, public.sql02_role_assignments, public.sql02_access_events,
  public.sql02_prop_movements, public.sql02_inventory_checks, public.sql02_cue_log,
  public.sql02_messages from anon, authenticated;
