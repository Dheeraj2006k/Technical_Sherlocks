-- SQL02 seed verification. Run after schema + seed in staging.
DO $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM public.sql02_characters;
  IF n <> 6 THEN RAISE EXCEPTION 'Expected 6 characters, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_role_assignments;
  IF n <> 6 THEN RAISE EXCEPTION 'Expected 6 role assignments, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_access_events;
  IF n <> 10 THEN RAISE EXCEPTION 'Expected 10 access events, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_prop_movements;
  IF n <> 7 THEN RAISE EXCEPTION 'Expected 7 prop movements, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_inventory_checks;
  IF n <> 6 THEN RAISE EXCEPTION 'Expected 6 inventory checks, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_cue_log;
  IF n <> 3 THEN RAISE EXCEPTION 'Expected 3 cue records, found %', n; END IF;
  SELECT count(*) INTO n FROM public.sql02_messages;
  IF n <> 6 THEN RAISE EXCEPTION 'Expected 6 messages, found %', n; END IF;
  IF (SELECT count(*) FROM public.sql02_prop_movements WHERE item_id='MASK-ORIG' AND handled_by='DEV') < 2 THEN
    RAISE EXCEPTION 'Expected at least two original-mask movements handled by Dev';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.sql02_inventory_checks WHERE item_id='MASK-ORIG' AND location='REPAIR_CASE-2' AND observed_condition LIKE 'PRESENT%') THEN
    RAISE EXCEPTION 'Original mask not found in Repair Case 2';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.sql02_cue_log WHERE planned_item_id='MASK-ORIG' AND observed_item_id='MASK-REPL') THEN
    RAISE EXCEPTION 'Finale cue mismatch missing';
  END IF;
END $$;

-- Expected final evidence sequence: PM04 -> PM05 -> CU02/IC03 -> PM07/IC05.
SELECT movement_id,event_time,item_id,from_location,to_location,handled_by
FROM public.sql02_prop_movements
WHERE item_id IN ('MASK-ORIG','MASK-REPL')
ORDER BY event_time;

-- Expected culprit evidence: direct message MSG03 and admission MSG06.
SELECT message_id,sent_at,sender_id,subject,body
FROM public.sql02_messages
WHERE message_id IN ('MSG03','MSG06')
ORDER BY sent_at;
