# SQL02 — The Last Show

**Track:** SQL Investigation  
**Recommended team:** 3 players  
**Expected time:** 15–20 minutes

## Case briefing

At the QUBIT closing performance, the final reveal should have featured the original **Starfall Mask**, a one-of-a-kind prop signed by the student performers who built the show. Instead, the audience saw a replica. After the curtain call, the original was gone from its stand.

The organisers initially treated it as a theft. But the backstage records are messy: several people had legitimate access, a performer had argued about the finale, the cue operator triggered the reveal, and the prop team used a backup during rehearsal. **Being nearby is not the same as moving the mask.**

Your team has access to seven SQL tables containing staff roles, access events, prop hand-offs, inventory checks, cue records and internal messages. Use joins and filters to answer the investigation questions. The case is designed for three investigators working together; all players share one team state and one score.

## The people

- **Dev Malhotra** — prop lead; responsible for the original and backup props.
- **Nikhil Rao** — lead performer; argued that the mask should not be used in the finale.
- **Kavya Sen** — AV cue operator; triggered the final reveal.
- **Sana Iyer** — assistant stage manager; recorded the hand-offs.
- **Isha Menon** — costume assistant; worked near stage-left wing.
- **Arjun Das** — backstage access marshal; managed the staff door.

These descriptions establish roles, not guilt.

## Phase 1 — The Empty Stand

Determine which item was expected at the finale, what was actually present, and which people had duties connected to it. Do not accuse someone just because their job gave them access.

## Phase 2 — The Swap Window

Reconstruct the last confirmed handling of the original and compare it with the inventory check and cue records. A badge event proves a credential was used at a door; it does not, by itself, prove who carried an object.

## Phase 3 — The Cover Story

Use the movement records and messages to test whether the substitution was accidental, authorised, or concealed. Your final answer has two parts:

1. Who was responsible for the substitution?
2. Which explanation best fits the evidence?

## SQL investigation guide

Start with small queries, inspect the table columns, and join on stable IDs. Useful patterns include:

```sql
SELECT * FROM sql02_prop_movements ORDER BY event_time;
```

```sql
SELECT m.event_time, c.display_name, m.item_id, m.from_location,
       m.to_location, m.reason
FROM sql02_prop_movements AS m
JOIN sql02_characters AS c ON c.character_id = m.handled_by
ORDER BY m.event_time;
```

The SQL console is read-only. Do not use `SELECT *` as a substitute for comparing records: the key deduction depends on linking the item identity, hand-off record, inventory check and message context.

**Objective:** establish what happened to the original Starfall Mask, not merely who looks suspicious.
