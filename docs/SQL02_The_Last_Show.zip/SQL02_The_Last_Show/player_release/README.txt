Player-only release: SQL02_Player_Case.md. Do not distribute seed SQL, tasks with answer keys, or author notes to players.
