# SQL02 Automated / Manual Acceptance Tests

## Structural tests
- [ ] Apply `schema/001_sql02_schema.sql` twice; second run succeeds.
- [ ] Apply `seeds/seed_SQL02.sql` twice; counts remain 6 characters, 6 roles, 10 access events, 7 movements, 6 inventory checks, 3 cues, 6 messages.
- [ ] Run `verification/verify_SQL02.sql`; no exception is raised.
- [ ] All foreign keys resolve and all timestamps are timestamptz.
- [ ] Confirm no case task/answer keys are exposed to browser roles.

## Expected query truths
- [ ] Original confirmed at stage-left at 18:55.
- [ ] Original returned to prop bay at 18:57 by Dev.
- [ ] Replica moved to stage-left at 18:59 by Dev.
- [ ] Finale cue planned original, observed replica.
- [ ] Replica present on display stand after finale.
- [ ] Original found in Repair Case 2.
- [ ] MSG03 indicates concealment motive; MSG06 admits location and failure to log.
- [ ] Nikhil's access history and stage timing clear him of the swap.
- [ ] Cue operator and door marshal are red herrings, not uniquely implicated by their records.

## SQL sandbox security tests
- [ ] Student query role has SELECT only on the assigned case's tables.
- [ ] Reject INSERT/UPDATE/DELETE/DDL, multiple statements, system catalog access and unsafe functions.
- [ ] Enforce statement timeout (3–5 seconds), row cap, rate limit and query length limit.
- [ ] Do not use Supabase service-role credentials for student query execution.
- [ ] Verify no cross-case data can be read through the SQL endpoint.

## Gameplay tests
- [ ] Three first-time players can divide queries naturally and complete in 15–20 minutes.
- [ ] Each question has exactly one evidence-supported correct option.
- [ ] All tasks are reachable in phase order; final deduction unlocks only after required tasks.
- [ ] Hint ladder and −2 penalty match server scoring; retry and idempotency tests pass.
- [ ] Blind reviewer independently reaches Dev and explanation A without author hints.

**Status:** pending until each test is actually run and recorded. Do not mark published based only on file generation.
