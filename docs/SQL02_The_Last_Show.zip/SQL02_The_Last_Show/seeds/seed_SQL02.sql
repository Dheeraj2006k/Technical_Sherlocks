-- SQL02 — idempotent case-data seed. Safe to re-run before live play.
-- This script only upserts case evidence; it never resets team/session progress.
begin;
insert into public.sql02_characters(character_id,display_name,role,public_profile) values
('DEV','Dev Malhotra','Prop lead','Responsible for the original Starfall Mask and the backup prop.'),
('NIK','Nikhil Rao','Lead performer','Performed the finale and argued against using the mask after rehearsal.'),
('KAV','Kavya Sen','AV cue operator','Triggered the final reveal from the cue desk.'),
('SAN','Sana Iyer','Assistant stage manager','Recorded prop hand-offs and stage movement.'),
('ISH','Isha Menon','Costume assistant','Worked near the stage-left wing.'),
('ARJ','Arjun Das','Backstage access marshal','Managed the staff-door access console.')
on conflict(character_id) do update set display_name=excluded.display_name,role=excluded.role,public_profile=excluded.public_profile;

insert into public.sql02_role_assignments(assignment_id,character_id,duty,zone,valid_from,valid_to) values
('RA01','DEV','Prop custody lead','PROP_BAY','2026-10-16 17:00+05:30','2026-10-16 21:00+05:30'),
('RA02','NIK','Finale performer','STAGE_LEFT','2026-10-16 18:45+05:30','2026-10-16 19:20+05:30'),
('RA03','KAV','Cue operation','AV_BOOTH','2026-10-16 17:30+05:30','2026-10-16 21:00+05:30'),
('RA04','SAN','Stage movement logging','BACKSTAGE','2026-10-16 17:00+05:30','2026-10-16 21:00+05:30'),
('RA05','ISH','Costume and quick changes','STAGE_LEFT','2026-10-16 18:00+05:30','2026-10-16 20:00+05:30'),
('RA06','ARJ','Door access marshal','STAFF_DOOR','2026-10-16 17:00+05:30','2026-10-16 21:00+05:30')
on conflict(assignment_id) do update set character_id=excluded.character_id,duty=excluded.duty,zone=excluded.zone,valid_from=excluded.valid_from,valid_to=excluded.valid_to;

insert into public.sql02_access_events(event_id,event_time,credential_id,assigned_character_id,zone,event_type,note) values
('AC01','2026-10-16 18:42:00+05:30','BDG-11','NIK','BACKSTAGE','ENTRY','Performer entered before sound check.'),
('AC02','2026-10-16 18:49:00+05:30','BDG-11','NIK','STAGE_LEFT','ENTRY','Credential accepted at stage-left door.'),
('AC03','2026-10-16 18:54:00+05:30','BDG-11','NIK','STAGE_LEFT','EXIT','Credential exited toward stage; stage manager call sheet confirms he was onstage from 18:55.'),
('AC04','2026-10-16 18:56:00+05:30','BDG-23','DEV','PROP_BAY','ENTRY','Prop lead entered prop bay.'),
('AC05','2026-10-16 19:01:00+05:30','BDG-23','DEV','PROP_BAY','EXIT','Prop lead exited prop bay.'),
('AC06','2026-10-16 18:58:00+05:30','BDG-31','KAV','AV_BOOTH','ENTRY','Cue operator at console; not a prop-bay credential.'),
('AC07','2026-10-16 18:59:00+05:30','BDG-42','SAN','BACKSTAGE','ENTRY','Assistant stage manager returned from stage-left.'),
('AC08','2026-10-16 19:00:00+05:30','BDG-52','ISH','STAGE_LEFT','ENTRY','Costume assistant entered for quick-change reset.'),
('AC09','2026-10-16 19:02:00+05:30','BDG-62','ARJ','STAFF_DOOR','ENTRY','Marshal opened staff door for a delivery; delivery manifest lists only fabric rolls.'),
('AC10','2026-10-16 19:03:00+05:30','BDG-62','ARJ','STAFF_DOOR','EXIT','Marshal closed staff door after delivery.')
on conflict(event_id) do update set event_time=excluded.event_time,credential_id=excluded.credential_id,assigned_character_id=excluded.assigned_character_id,zone=excluded.zone,event_type=excluded.event_type,note=excluded.note;

insert into public.sql02_prop_movements(movement_id,event_time,item_id,item_label,from_location,to_location,handled_by,logged_by,reason,seal_status) values
('PM01','2026-10-16 18:20:00+05:30','MASK-ORIG','Starfall Mask — original','LOCKER-A','PROP_STAND','DEV','SAN','Pre-show issue; serial plate SM-041 verified','SEALED'),
('PM02','2026-10-16 18:37:00+05:30','MASK-REPL','Starfall Mask — replica','PROP_CABINET','BACKUP_TRAY','DEV','SAN','Backup prop for camera rehearsal','NOT_APPLICABLE'),
('PM03','2026-10-16 18:51:00+05:30','MASK-ORIG','Starfall Mask — original','PROP_STAND','STAGE_LEFT_WING','SAN','SAN','Approved pre-finale hand-off','SEALED'),
('PM04','2026-10-16 18:57:00+05:30','MASK-ORIG','Starfall Mask — original','STAGE_LEFT_WING','PROP_BAY','DEV','SAN','Returned for clasp inspection after rehearsal snag','OPEN'),
('PM05','2026-10-16 18:59:00+05:30','MASK-REPL','Starfall Mask — replica','BACKUP_TRAY','STAGE_LEFT_WING','DEV','SAN','Marked “finale ready”; no original serial recorded','NOT_APPLICABLE'),
('PM06','2026-10-16 19:06:00+05:30','MASK-REPL','Starfall Mask — replica','STAGE_LEFT_WING','DISPLAY_STAND','SAN','SAN','Used for finale reveal after prop lead sign-off','NOT_APPLICABLE'),
('PM07','2026-10-16 19:14:00+05:30','MASK-ORIG','Starfall Mask — original','PROP_BAY','REPAIR_CASE-2','DEV','DEV','Clasp repair; entered after incident report was filed','OPEN')
on conflict(movement_id) do update set event_time=excluded.event_time,item_id=excluded.item_id,item_label=excluded.item_label,from_location=excluded.from_location,to_location=excluded.to_location,handled_by=excluded.handled_by,logged_by=excluded.logged_by,reason=excluded.reason,seal_status=excluded.seal_status;

insert into public.sql02_inventory_checks(check_id,checked_at,location,item_id,item_label,observed_condition,checked_by,note) values
('IC01','2026-10-16 18:34:00+05:30','PROP_STAND','MASK-ORIG','Starfall Mask — original','PRESENT; serial SM-041 visible','SAN','Pre-rehearsal inventory.'),
('IC02','2026-10-16 18:55:00+05:30','STAGE_LEFT_WING','MASK-ORIG','Starfall Mask — original','PRESENT; clasp catches fabric','SAN','Last independent confirmation of original before return to prop bay.'),
('IC03','2026-10-16 19:08:00+05:30','DISPLAY_STAND','MASK-REPL','Starfall Mask — replica','PRESENT; serial plate absent','SAN','Post-finale check; display item is not the original.'),
('IC04','2026-10-16 19:10:00+05:30','PROP_BAY','MASK-ORIG','Starfall Mask — original','NOT FOUND at expected shelf','SAN','Incident opened; repair case not yet inspected.'),
('IC05','2026-10-16 19:22:00+05:30','REPAIR_CASE-2','MASK-ORIG','Starfall Mask — original','PRESENT; clasp taped for repair','ARJ','Found after Dev disclosed the repair case during follow-up.'),
('IC06','2026-10-16 19:22:00+05:30','REPAIR_CASE-2','MASK-REPL','Starfall Mask — replica','NOT PRESENT','ARJ','Confirms original was moved, not permanently removed from venue.')
on conflict(check_id) do update set checked_at=excluded.checked_at,location=excluded.location,item_id=excluded.item_id,item_label=excluded.item_label,observed_condition=excluded.observed_condition,checked_by=excluded.checked_by,note=excluded.note;

insert into public.sql02_cue_log(cue_event_id,event_time,cue_code,operator_id,planned_item_id,observed_item_id,result,note) values
('CU01','2026-10-16 18:45:00+05:30','CUE-12','KAV','MASK-REPL','MASK-REPL','REHEARSAL','Camera rehearsal used the backup; this is why some footage shows the replica.'),
('CU02','2026-10-16 19:05:00+05:30','CUE-17','KAV','MASK-ORIG','MASK-REPL','EXECUTED','Cue operator followed the run sheet; visual cue cannot establish who supplied the item.'),
('CU03','2026-10-16 19:07:00+05:30','CUE-18','KAV','MASK-ORIG','MASK-REPL','POSTSHOW_CHECK','Operator flagged mismatch after finale; no evidence operator had prop-bay access.')
on conflict(cue_event_id) do update set event_time=excluded.event_time,cue_code=excluded.cue_code,operator_id=excluded.operator_id,planned_item_id=excluded.planned_item_id,observed_item_id=excluded.observed_item_id,result=excluded.result,note=excluded.note;

insert into public.sql02_messages(message_id,sent_at,sender_id,recipient_id,channel,subject,body) values
('MSG01','2026-10-16 18:47:00+05:30','NIK','DEV','TEAM_CHAT','Clasp concern','The clasp snagged my sleeve in rehearsal. We should not use the original until it is checked.'),
('MSG02','2026-10-16 18:53:00+05:30','DEV','SAN','STAGE_CHAT','Quick inspection','Bring the original back to the prop bay for a clasp check; I will sign off before finale.'),
('MSG03','2026-10-16 18:58:00+05:30','DEV','SAN','DIRECT_MESSAGE','Backup plan','Put the backup on the wing for now. I will handle the original. Do not update the producer until the show is over; they will pull the finale if they hear the clasp is cracked.'),
('MSG04','2026-10-16 19:02:00+05:30','DEV','KAV','STAGE_CHAT','Cue confirmation','Run CUE-17 on schedule. The prop is sorted.'),
('MSG05','2026-10-16 19:12:00+05:30','SAN','DEV','DIRECT_MESSAGE','Inventory mismatch','The original is missing from the expected shelf. Please tell me where you put it.'),
('MSG06','2026-10-16 19:16:00+05:30','DEV','SAN','DIRECT_MESSAGE','Follow-up','It is in Repair Case 2. I should have logged the move and told the producer. I did not want the finale cancelled.')
on conflict(message_id) do update set sent_at=excluded.sent_at,sender_id=excluded.sender_id,recipient_id=excluded.recipient_id,channel=excluded.channel,subject=excluded.subject,body=excluded.body;
commit;
