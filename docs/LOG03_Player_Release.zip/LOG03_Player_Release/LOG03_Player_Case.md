# LOG03 — The Silent Call
## Player-facing case file — Duo Edition

**Track:** Logic  
**Recommended team size:** 2 players  
**Objective:** Determine who caused the cancellation of the Pulse demonstration and what the phone records actually prove.

> This is a fictional case. All times, people, call records and event records belong to the case.

## Incident briefing

At the QUBIT Innovation Showcase, a student team is scheduled to demonstrate a prototype called **Pulse** at 4:30 PM. At 4:12 PM, the stage coordinator receives a message that the faculty supervisor has cancelled the demonstration because of an electrical safety concern.

The demonstration is stopped. The audience is redirected, and Pulse is moved into a storage room while staff check the setup. At 4:35 PM, the faculty supervisor arrives and says she never cancelled the demonstration.

Several people insist that they called, received a call, or heard the cancellation confirmed. The phone records appear to disagree with their stories.

Your job is not simply to find who made a call. You must determine **which calls actually connected, what information was communicated, and who knowingly turned an unconfirmed message into an official cancellation**.

## People involved

### 1. Ananya Rao — Faculty supervisor
Responsible for approving safety-related changes to demonstrations. She says she did not cancel Pulse's slot and did not authorize anyone to announce a cancellation.

### 2. Karthik Menon — Stage coordinator
Managed the running order and announced that Pulse was cancelled. He says he received a phone confirmation from the faculty office shortly before making the announcement.

### 3. Sana Ali — Control-desk volunteer
Answered calls at the event control desk. She says the desk received a brief call about a possible electrical issue, but she could not identify the caller.

### 4. Dev Malhotra — Pulse team leader
Built Pulse and was due to demonstrate it. His team had argued with the stage team about a last-minute schedule change. He says he called the control desk to ask whether the slot was still on.

### 5. Ritesh Shah — AV technician
Responsible for stage audio and power distribution. He had raised a genuine concern about a loose cable earlier that afternoon, but says it was fixed before the demonstration.

### 6. Meera Joshi — Faculty office assistant
Works at the faculty office and manages its landline. She says the office phone rang during setup, but no one from the office spoke to Karthik to cancel the demonstration.

---

# Phase 1 — The Claim

## Evidence A — Stage Running Sheet
**Source:** Stage coordinator's event sheet

- 3:50 PM — Pulse demonstration confirmed for 4:30 PM.
- 4:05 PM — Ritesh reports a loose power cable near the stage.
- 4:09 PM — Ritesh marks the cable secured after inspection.
- 4:12 PM — Karthik writes: “Faculty cancelled Pulse — electrical concern.”
- 4:13 PM — Pulse is removed from the running order.
- 4:35 PM — Ananya arrives and disputes the cancellation.

The sheet does not identify who gave Karthik the cancellation instruction.

## Evidence B — Control Desk Call Log
**Source:** Event control desk phone

| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Outgoing call to faculty office | 00:00 | No answer |
| 4:10 PM | Incoming call, caller ID withheld | 00:18 | Answered by Sana |
| 4:11 PM | Outgoing call to Karthik | 00:00 | No answer |
| 4:14 PM | Incoming call from faculty office | 00:00 | Missed |

The desk system records call duration. A duration of `00:00` means the call did not connect in this system. It does not reveal what a caller intended to say.

## Evidence C — Karthik's Statement
**Source:** Initial interview

Karthik says:

*“At about 4:11, the faculty office called me and confirmed the cancellation. I wrote it down immediately. I wouldn't stop a team's demonstration without approval.”*

He says he did not speak to Sana before making the announcement.

## Evidence D — Safety Check
**Source:** Ritesh's signed equipment checklist

- 4:05 PM — Loose cable reported.
- 4:09 PM — Cable secured and tested.
- 4:10 PM — Stage power checked; no continuing fault recorded.
- 4:30 PM — Pulse demonstration remains listed as safe to proceed, pending normal start checks.

## Investigation Task 1
**What does the phone log establish about the alleged 4:11 PM confirmation from the faculty office to Karthik?**

A. The call definitely happened and the cancellation was confirmed.  
B. The listed 4:11 PM call was an outgoing call from the control desk to Karthik that did not connect; it does not support Karthik's claim of a connected faculty-office call at that time.  
C. The faculty supervisor never made any call that day.  
D. The caller at 4:10 was definitely Ananya.

## Investigation Task 2
**Which conclusion is best supported by the safety checklist?**

A. There was a real cable concern, but it was marked fixed before the cancellation was recorded.  
B. The stage was dangerous throughout the afternoon.  
C. Ritesh must have invented the fault.  
D. The faculty supervisor cancelled Pulse because of the cable.


---

# Phase 2 — Two Sides of the Call

## Evidence E — Faculty Office Phone Log
**Source:** Faculty office landline system

| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Incoming call from control desk | 00:00 | Missed |
| 4:10 PM | No incoming or outgoing call recorded | — | — |
| 4:11 PM | No outgoing call to Karthik recorded | — | — |
| 4:14 PM | Outgoing call to control desk | 00:00 | No answer |

The faculty office system and control desk system both show no connected call between the faculty office and Karthik before the cancellation was announced.

## Evidence F — Sana's Clarification
**Source:** Follow-up interview

Sana says the 4:10 call lasted about eighteen seconds. The caller said:

*“There may be an electrical problem. Please hold the Pulse slot until it is checked.”*

Sana did not hear the caller's name. The caller did **not** say that the faculty supervisor had cancelled the demonstration.

Sana says she attempted to call Karthik back at 4:11, but he did not answer. The control desk log shows this outgoing call lasted `00:00`.

## Evidence G — Message Draft
**Source:** Karthik's event messaging app, inspected with permission

At 4:12 PM, Karthik drafts the following announcement:

*“As confirmed by the faculty supervisor, Pulse is cancelled due to an electrical safety concern.”*

The draft is posted to the stage team's internal channel at 4:13 PM. The app records the draft and posting times. It does not show that the faculty supervisor approved the wording. The draft was created after the 4:10 call and before the 4:13 post; the time alone does not establish what Karthik believed.

## Evidence H — Dev's Call History
**Source:** Dev's phone, shown during interview

- 4:06 PM — Outgoing call to the control desk, connected for 24 seconds.
- 4:10 PM — No call to the faculty office.
- 4:15 PM — Message to a teammate: “They've paused us. Nobody has told us why yet.”

Dev says he called to confirm that Pulse was still scheduled. He says the person who answered told him the slot was still listed, but that a safety check was underway.

## Investigation Task 3
**What did the 4:10 incoming call to the control desk actually communicate, according to Sana?**

A. The faculty supervisor had formally cancelled Pulse.  
B. There might be an electrical problem and the slot should be held until checked; the caller did not identify themselves or claim faculty authorization.  
C. Dev demanded that Pulse be cancelled.  
D. The caller confirmed that the cable was still dangerous.

## Investigation Task 4
**Which statement about the call records is correct?**

A. A call appearing in a log always means the people spoke.  
B. The two phone systems show no connected faculty-office call to Karthik before the cancellation announcement.  
C. The logs prove Ananya never used a phone that day.  
D. The 4:14 missed call proves the faculty office approved the cancellation.


---

# Phase 3 — The Missing Confirmation

## Evidence I — Control Desk Procedure Card
**Source:** Printed procedure beside the event phone

For safety-related changes:
1. Record the caller's name and role.
2. If the caller claims faculty authorization, call the faculty office back using the number on the approved contact sheet.
3. Do not change the running order until authorization is confirmed.
4. A request to “hold” a slot is not the same as a cancellation.

Sana's incident note at 4:10 says only: *“Caller unidentified — possible electrical issue — verify.”*

## Evidence J — Approved Contact Sheet
**Source:** Event control desk folder

The faculty office's approved callback number ends in **204**. The control desk log's 4:07 outgoing call was made to that number and did not connect. No connected callback to that number appears before 4:13.

Karthik's phone history shows no incoming call from the faculty office between 4:00 and 4:15.

## Evidence K — Karthik's Private Note
**Source:** Paper running sheet recovered from the stage desk

Beside the 4:12 cancellation entry, Karthik wrote:

*“Need a reason to move Pulse after slot dispute. Safety concern is enough if marked faculty-approved.”*

The handwriting is identified as Karthik's by the event lead. Karthik says he wrote the note as a reminder to verify the instruction, but the note does not say “verify” or “pending.”

## Evidence L — Final Timeline
**Source:** Combined timeline prepared by the event lead

- 4:05 — Ritesh reports a loose cable.
- 4:09 — Cable is secured and tested.
- 4:10 — Unidentified caller asks the control desk to hold Pulse pending a check.
- 4:11 — Sana's attempted call to Karthik does not connect.
- 4:12 — Karthik records “faculty cancelled” and drafts the announcement.
- 4:13 — The announcement is posted.
- 4:14 — The faculty office's return call to the control desk is missed.
- 4:35 — Ananya says she never cancelled Pulse.

The records show that the safety concern was real, but they do not show a connected call in which the faculty office cancelled the demonstration.

## Investigation Task 5
**Which rule was most clearly violated?**

A. A safety concern must never be reported.  
B. A request to hold a slot is not a cancellation, and claimed faculty authorization must be verified before changing the running order.  
C. Photographs must be taken before every demonstration.  
D. Only students can call the control desk.

## Investigation Task 6
**What does Karthik's private note add to the case?**

A. It proves the cable was never loose.  
B. It gives evidence that Karthik had a schedule-related motive and knowingly treated an unconfirmed concern as faculty-approved.  
C. It proves Dev placed the 4:10 call.  
D. It proves Ananya secretly cancelled Pulse.


---

# Final deduction

## Final Question 1 — Who was responsible for the false cancellation?

Select one:

- Ananya Rao
- Karthik Menon
- Sana Ali
- Dev Malhotra
- Ritesh Shah
- Meera Joshi

## Final Question 2 — What most likely happened?

A. The faculty office connected to Karthik and officially cancelled Pulse.  
B. A real but already addressed cable concern prompted an unidentified caller to request a temporary hold; Karthik turned that unconfirmed request into a false claim of faculty cancellation.  
C. Dev cancelled his own team's demonstration to gain attention.  
D. There was never any cable concern, and all safety records were fabricated.

**Submit both answers.** The responsible-person and explanation components are graded independently. The six investigation tasks are worth up to 60 points in total; the final responsible-person selection is worth 25 points and the final explanation is worth 15 points. Each investigation task may be retried. Wrong committed answers incur a 2-point penalty, and each task awards points only once.
