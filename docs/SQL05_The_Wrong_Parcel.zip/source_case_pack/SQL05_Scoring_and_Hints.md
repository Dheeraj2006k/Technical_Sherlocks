# SQL05 Scoring
Six investigation tasks × 10 = 60 points; final responsible person = 25; final explanation = 15; total = 100. Hint reward ladder: 10, 8, 6, 4, 2 for 0–4 hints used. Wrong committed answer: −2, score floor 0. SQL exploration errors are free. Each task/component awards once only. Server controls hints, answer validation and scoring.
