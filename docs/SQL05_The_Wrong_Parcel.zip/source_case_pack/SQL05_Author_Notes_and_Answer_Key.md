# RESTRICTED — SQL05 Author Notes and Answer Key
Never distribute this file to players or include it in client assets.

## Solution
**Responsible person: Ravi Menon.** Ravi deliberately swapped the labels for PX-14 (prototype sensor module) and PX-41 (stage clips) before dispatch. He wanted to delay the demo after discovering the calibration sheet was missing, buying time to find it. The records support deliberate label swapping and concealment, not theft or damage.

## Timeline
- 15:12 — Expected delivery for PX-14, sensor module, Demo Desk.
- 15:18 — PX-41 packed with stage clips for Storage Bay.
- 15:26 — Ravi prints PX-14's correct label.
- 15:29 — Ravi changes PX-14's parcel code to PX-41.
- 15:31 — Ravi changes PX-41's parcel code to PX-14: reciprocal swap.
- 15:38 — Dispatch scans read labels, not parcel contents.
- 15:51 — PX-41 label routes to Demo Desk; PX-14 label routes to Storage Bay.
- 16:02 — Joel receives stage clips at Demo Desk.
- 16:05 — Dashboard marks PX-14 delivered to Storage Bay based on label scans.
- 16:07 — Ravi messages Sana: “If the module goes to storage, the demo has to wait. I need time to find the calibration sheet before they test it.”
- 16:10 — Sana opens a discrepancy report.

## Twists
1. “Delivered” is true for the label's route, not proof that the sensor module reached the demo desk.
2. Both labels were changed in opposite directions: not a random courier mix-up.
3. Scanners read labels, not contents.
4. Sana coordinated the handoff but did not edit the labels.
5. Ravi's message gives a delay motive, not a theft motive.

## Fairness limits
The module's final physical location is not proven beyond its recorded route to Storage Bay; there is no recovery scan. Ravi is identified by both label audit records and his message. Sana is not guilty merely because she coordinated delivery; Joel's receipt proves what arrived, not who swapped labels.
