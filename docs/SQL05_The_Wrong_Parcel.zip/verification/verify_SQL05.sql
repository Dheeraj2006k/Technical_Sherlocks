WITH checks AS (
 SELECT 'case row' check_name,(SELECT count(*)=1 FROM public.sql05_case WHERE case_id='SQL05') ok
 UNION ALL SELECT 'five characters',(SELECT count(*)=5 FROM public.sql05_characters)
 UNION ALL SELECT 'two parcels',(SELECT count(*)=2 FROM public.sql05_parcels)
 UNION ALL SELECT 'five label audit rows',(SELECT count(*)=5 FROM public.sql05_label_audit)
 UNION ALL SELECT 'five route scans',(SELECT count(*)=5 FROM public.sql05_route_scans)
 UNION ALL SELECT 'two receipts',(SELECT count(*)=2 FROM public.sql05_receipts)
 UNION ALL SELECT 'two expectations',(SELECT count(*)=2 FROM public.sql05_delivery_expectations)
 UNION ALL SELECT 'four messages',(SELECT count(*)=4 FROM public.sql05_messages)
 UNION ALL SELECT 'reciprocal swaps present',(SELECT count(*)=2 FROM public.sql05_label_audit WHERE field_changed='PARCEL_CODE' AND ((parcel_id='PX-14' AND old_value='PX-14' AND new_value='PX-41') OR (parcel_id='PX-41' AND old_value='PX-41' AND new_value='PX-14')))
 UNION ALL SELECT 'Ravi authored both code changes',(SELECT count(DISTINCT actor_id)=1 AND min(actor_id)='RAVI' FROM public.sql05_label_audit WHERE field_changed='PARCEL_CODE')
 UNION ALL SELECT 'demo desk got stage clips',(SELECT contents_observed='STAGE-CLIPS' FROM public.sql05_receipts WHERE receipt_id='RC-01')
) SELECT check_name,CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END result FROM checks ORDER BY check_name;

-- Author-side chronology. Do not expose as a player-facing precomputed answer.
SELECT event_at,'label_audit' source,parcel_id subject,field_changed event,actor_id actor,old_value||' -> '||new_value detail FROM public.sql05_label_audit
UNION ALL SELECT event_at,'route_scan',parcel_id,scan_type,scan_location,scanned_label_destination||'; '||note FROM public.sql05_route_scans
ORDER BY event_at;
