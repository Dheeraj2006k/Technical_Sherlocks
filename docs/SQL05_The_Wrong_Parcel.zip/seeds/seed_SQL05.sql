BEGIN;
INSERT INTO public.sql05_case VALUES('SQL05','The Wrong Parcel','1.0.0',1,'content_complete_staging_validation_required') ON CONFLICT(case_id) DO UPDATE SET title=EXCLUDED.title,content_version=EXCLUDED.content_version,intended_team_size=EXCLUDED.intended_team_size,release_status=EXCLUDED.release_status;
INSERT INTO public.sql05_characters VALUES
('RAVI','Ravi Menon','Dispatch clerk'),('SANA','Sana Qureshi','Courier handoff coordinator'),('JOEL','Joel D''Souza','Demo desk receiver'),('MIRA','Mira Patel','Prototype team lead'),('KARAN','Karan Shah','Storage bay attendant')
ON CONFLICT(character_id) DO UPDATE SET display_name=EXCLUDED.display_name,role=EXCLUDED.role;
INSERT INTO public.sql05_parcels VALUES
('PX-14','SENSOR-MODULE','Demo Desk','2026-10-16 15:12:00+05:30','RAVI','Prototype sensor module expected for final demo.'),
('PX-41','STAGE-CLIPS','Storage Bay','2026-10-16 15:18:00+05:30','RAVI','Box of spare stage clips.')
ON CONFLICT(parcel_id) DO UPDATE SET packed_contents=EXCLUDED.packed_contents,intended_destination=EXCLUDED.intended_destination,packed_at=EXCLUDED.packed_at,packed_by=EXCLUDED.packed_by,note=EXCLUDED.note;
INSERT INTO public.sql05_label_audit VALUES
('LA-01','PX-14','2026-10-16 15:26:00+05:30','RAVI','PARCEL_CODE','PX-14','PX-14','Initial correct label.'),
('LA-02','PX-14','2026-10-16 15:29:00+05:30','RAVI','PARCEL_CODE','PX-14','PX-41','Reprint; reason blank.'),
('LA-03','PX-41','2026-10-16 15:31:00+05:30','RAVI','PARCEL_CODE','PX-41','PX-14','Reciprocal label change; reason blank.'),
('LA-04','PX-14','2026-10-16 15:32:00+05:30','RAVI','DESTINATION','Demo Desk','Storage Bay','Destination follows swapped code.'),
('LA-05','PX-41','2026-10-16 15:33:00+05:30','RAVI','DESTINATION','Storage Bay','Demo Desk','Destination follows swapped code.')
ON CONFLICT(audit_id) DO UPDATE SET parcel_id=EXCLUDED.parcel_id,event_at=EXCLUDED.event_at,actor_id=EXCLUDED.actor_id,field_changed=EXCLUDED.field_changed,old_value=EXCLUDED.old_value,new_value=EXCLUDED.new_value,reason=EXCLUDED.reason;
INSERT INTO public.sql05_route_scans VALUES
('RS-01','PX-14','2026-10-16 15:38:00+05:30','Dispatch Exit','OUTBOUND','Storage Bay','Scanner reads current label; no contents inspection.'),
('RS-02','PX-41','2026-10-16 15:38:30+05:30','Dispatch Exit','OUTBOUND','Demo Desk','Scanner reads current label; no contents inspection.'),
('RS-03','PX-41','2026-10-16 15:51:00+05:30','Demo Desk','ARRIVAL','Demo Desk','Arrival follows label code.'),
('RS-04','PX-14','2026-10-16 15:53:00+05:30','Storage Bay','ARRIVAL','Storage Bay','Arrival follows label code.'),
('RS-05','PX-14','2026-10-16 16:05:00+05:30','Storage Bay','DELIVERED','Storage Bay','Dashboard status is route-based, not contents-verified.')
ON CONFLICT(scan_id) DO UPDATE SET parcel_id=EXCLUDED.parcel_id,event_at=EXCLUDED.event_at,scan_location=EXCLUDED.scan_location,scan_type=EXCLUDED.scan_type,scanned_label_destination=EXCLUDED.scanned_label_destination,note=EXCLUDED.note;
INSERT INTO public.sql05_receipts VALUES
('RC-01','PX-41','2026-10-16 16:02:00+05:30','JOEL','Demo Desk','STAGE-CLIPS','Expected sensor module absent.'),
('RC-02','PX-14','2026-10-16 16:06:00+05:30','KARAN','Storage Bay','UNOPENED','Parcel arrived under swapped label; contents not verified.')
ON CONFLICT(receipt_id) DO UPDATE SET parcel_id=EXCLUDED.parcel_id,received_at=EXCLUDED.received_at,received_by=EXCLUDED.received_by,destination=EXCLUDED.destination,contents_observed=EXCLUDED.contents_observed,note=EXCLUDED.note;
INSERT INTO public.sql05_delivery_expectations VALUES
('EX-01','2026-10-16 15:12:00+05:30','MIRA','PX-14','SENSOR-MODULE','Demo Desk','HIGH'),
('EX-02','2026-10-16 15:18:00+05:30','KARAN','PX-41','STAGE-CLIPS','Storage Bay','NORMAL')
ON CONFLICT(expectation_id) DO UPDATE SET created_at=EXCLUDED.created_at,requested_by=EXCLUDED.requested_by,parcel_id=EXCLUDED.parcel_id,expected_contents=EXCLUDED.expected_contents,expected_destination=EXCLUDED.expected_destination,priority=EXCLUDED.priority;
INSERT INTO public.sql05_messages VALUES
('MSG-01','2026-10-16 16:07:00+05:30','RAVI','SANA','If the module goes to storage, the demo has to wait. I need time to find the calibration sheet before they test it.'),
('MSG-02','2026-10-16 16:08:00+05:30','SANA','RAVI','I coordinated courier handoff, but I did not edit either label. The scans follow what was printed.'),
('MSG-03','2026-10-16 16:10:00+05:30','SANA','MIRA','I opened a discrepancy report. Delivered status is based on route scan, not a contents check.'),
('MSG-04','2026-10-16 16:12:00+05:30','JOEL','MIRA','PX-41 arrived at the demo desk. It contains stage clips, not the sensor module.')
ON CONFLICT(message_id) DO UPDATE SET sent_at=EXCLUDED.sent_at,sender_id=EXCLUDED.sender_id,recipient_id=EXCLUDED.recipient_id,message_text=EXCLUDED.message_text;
COMMIT;
