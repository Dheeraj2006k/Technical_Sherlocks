# SQL05 — The Wrong Parcel
Version 1.0.0 · SQL track · Solo · Target 12–18 minutes

## Install in staging
1. Apply `schema/001_sql05_schema.sql`.
2. Run `seeds/seed_SQL05.sql`.
3. Run `verification/verify_SQL05.sql`; all checks should PASS.
4. Register `source_case_pack/SQL05_Tasks.json` with the existing game engine. Keep answer keys and canonical queries server-side.
5. Complete `tests/SQL05_Acceptance_Tests.md` before live use.

The `sql05_*` tables store case evidence only. They do not replace shared runtime tables for assignments, sessions, attempts, completions, hints, score ledger, or leaderboard. Use a restricted read-only query role, never expose a service-role key, reject writes/DDL/multiple statements/system catalog reads, and enforce timeouts, row caps, rate limits, case assignment and phase unlocks server-side.

Release status: content-complete; staging execution, engine integration, security tests and blind solo playtest remain required.
