Player-only file: source_case_pack/LOG05_Player_Case.md. Do not distribute author notes, manifest, seed SQL or scoring files to players.
