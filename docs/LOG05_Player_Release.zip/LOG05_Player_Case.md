# LOG05 — The Duplicate Invitation
## Player-facing case file — Solo Edition

**Track:** Logic | **Recommended team size:** 1 | **Content version:** 1.0.0

> Fictional case. All people, timestamps, event logs and records are invented for this investigation.

## Incident briefing

At the QUBIT Innovation Showcase, Team Orbit nearly lost its first prototype-demo slot after arriving at registration with an invitation that said **4:30 PM**. The signed master run sheet and the official email attachment both say **4:00 PM**. The QR code on the invitation is valid, which makes the mismatch more confusing: the code points to Orbit, but the time is wrong.

No one was disqualified, and the demo schedule was paused while the organisers checked the records. A duplicate-looking invitation was later found in the paper-recycling bin. Your job is to determine who deliberately made the misleading copy and why.

Do not assume the person who had access to the printer must be responsible. Distinguish an account log from a person, a valid QR from an authentic invitation, and a genuine schedule edit from a changed paper copy.

## People involved

- **Aanya Nair — Registration coordinator:** handled invitation delivery and registration materials.
- **Rohan Mehta — Schedule coordinator:** maintained the master run sheet.
- **Irfan Khan — Print-desk volunteer:** operated the shared event printer.
- **Meera Shah — Team Orbit captain:** received the invitation and reported the mismatch.
- **Kabir Sen — Stage runner:** transported sealed event envelopes and cue cards.
- **Sana Reddy — Event photographer:** took timestamped setup photos.

---

# Phase 1 — The Mismatch

## Evidence E01 — The Invitation Received by Team Orbit
**Source:** Team Orbit message archive

At 3:58 PM, Meera saved a photograph of the invitation delivered to her team. It says: “Final Prototype Reveal — check-in 4:30 PM.” The QR code reads **ORB-041**. The paper is ordinary event stock. The photograph timestamp is from Meera’s phone; it proves what she received, not who printed it.

## Evidence E02 — The Master Run Sheet
**Source:** Schedule office export

The signed master run sheet lists Team Orbit check-in at **4:00 PM** and Team Nova check-in at **4:10 PM**. A 3:42 PM revision moved the opening remarks by five minutes but did not change either team’s check-in time. The file history attributes that revision to Rohan Mehta.

## Evidence E03 — The Check-in Desk Note
**Source:** Registration desk incident log

At 4:02 PM, the desk marked Team Orbit “not present.” At 4:12 PM, Meera arrived and showed the invitation with the 4:30 PM time. The desk paused Orbit’s check-in rather than disqualifying the team. A handwritten note says, “QR accepted, time conflicts with master.”

## Evidence E04 — The People on Duty
**Source:** Volunteer shift board

Aanya handled invitation delivery and registration materials from 3:30–4:15 PM. Irfan operated the print desk from 3:35–4:05 PM. Rohan worked at the schedule desk. Kabir carried sealed envelopes between desks. Sana photographed the registration area. Several people could approach the printer; this board alone does not identify who printed any particular page.

---

# Phase 2 — The Duplicate

## Evidence E05 — Official Email Archive
**Source:** Event mailbox export

The archived email sent to Team Orbit at 3:45 PM contains a PDF stating check-in at **4:00 PM** and QR **ORB-041**. The message was delivered successfully. The archive preserves the sent attachment, not a copy of any later paper handed to the team.

## Evidence E06 — Print Queue Receipt
**Source:** Printer administration log

At 3:51 PM, a file named “Orbit_Final_v3.pdf” was printed from the registration printer under account **ANAIR**. The job contained one page. The log records the account and job, not the person standing at the printer or who collected the output.

## Evidence E07 — The Duplicate QR Report
**Source:** Check-in system audit

The QR code **ORB-041** was scanned at 4:12 PM and resolved to Team Orbit’s original registration. The system did not create a second registration or issue a new invitation. The code identifies the team record; it does not authenticate the time printed beside it.

## Evidence E08 — The Printer Tray Photograph
**Source:** Sana’s setup photo, 3:54 PM

A timestamped photo shows Aanya at the registration printer collecting a single sheet. The page is partly turned away; the time printed on it cannot be read. The photo independently places Aanya at the output tray, but does not by itself prove what the sheet said or why she collected it.

---

# Phase 3 — The Motive

## Evidence E09 — The Rejected Proof
**Source:** Recovered from the paper-recycling bin

A discarded proof reads “TEAM ORBIT — CHECK-IN 4:30 PM” and includes QR **ORB-041**. In the lower margin, handwritten in purple ink, are the words “duplicate QR OK.” The shift board’s setup note, written by Aanya, uses the same distinctive purple marker and letter forms. No other recovered proof has this combination of time and code.

## Evidence E10 — Aanya’s Shift Note
**Source:** Registration clipboard, back page

A note in Aanya’s handwriting reads: “If Orbit checks in after sound check, Nova keeps first demo slot. Change Orbit copy only; leave master alone.” It is dated that afternoon. The note does not name a specific method, so it must be read alongside the print and photograph records.

## Evidence E11 — Rohan’s Revision History
**Source:** Schedule file audit

Rohan’s 3:42 PM change moved opening remarks by five minutes. The file’s before-and-after versions show Team Orbit remained at 4:00 PM and Team Nova at 4:10 PM. The schedule change is real, but it cannot explain the 4:30 PM printed invitation.

## Evidence E12 — Team Nova’s Check-in Receipt
**Source:** Registration system receipt

Team Nova checked in at 4:09 PM, one minute before its listed time, and did not receive a revised invitation. The check-in system records the team’s arrival; it does not show that Nova requested or knew about the altered Orbit copy.

---

## Final deduction

Submit two answers independently:
1. **Who was responsible for the misleading invitation?**
2. **Which explanation best accounts for the evidence?**

You are expected to explain the chain of evidence, not simply pick the person who appears most suspicious. A valid QR code can point to a real registration while the paper carrying it is misleading.
