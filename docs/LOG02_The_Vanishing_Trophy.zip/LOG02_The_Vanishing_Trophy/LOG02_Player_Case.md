# LOG02 — The Vanishing Trophy
## Player-facing case file

**Track:** Logic  
**Objective:** Determine who was responsible for the disappearance of the QUBIT Founders' Trophy and what happened to it.

## Incident briefing

The QUBIT Founders' Trophy is due to be presented at the closing ceremony at 5:00 PM. At 4:25 PM, the awards team discovers that the trophy is missing from its display stand.

No broken glass is found. The display cabinet was opened several times during the afternoon for approved photographs and stage preparation. Several people handled nearby equipment, and more than one movement record has an incomplete destination.

The first report calls it a theft. But the records show that the trophy was moved during event preparation—and no one has yet established where it went afterward.

**Your task:** Reconstruct the trophy's chain of custody, test the competing explanations, and determine who was responsible.

## People involved

### Kavya Sen — Awards coordinator
Kavya coordinated the trophy, certificates and final presentation. She signed several awards-preparation forms and was responsible for confirming the trophy was ready for the ceremony.

### Arjun Rao — Stage volunteer
Arjun moved stage risers and podium equipment. He says he moved an empty display stand but never handled the trophy itself.

### Naina Rao — Event photographer
Naina took official photographs of the trophy and the award recipients. She requested that the trophy be moved briefly for a group photograph.

### Sameer Khan — Logistics volunteer
Sameer managed carts, storage crates and equipment returns. He moved a large grey crate near the awards area but says it contained banner hardware.

### Meera Iyer — Engraving liaison
Meera coordinated with the vendor who engraved the trophy's nameplate. She says the final engraving proof had been approved before the event.

### Vikram Sethi — Showcase coordinator
Vikram managed the event schedule. He says the trophy was present when he checked the awards area at approximately 4:05 PM, but he did not inspect it closely.

---

# Phase 1 — Discovery

## Evidence A — Awards Display Checklist
**Source:** Signed awards checklist

- 3:40 PM — Trophy placed on the display stand.
- 3:55 PM — Display area opened for official photographs.
- 4:05 PM — Vikram notes: “Awards display looks ready.”
- 4:25 PM — Missing trophy reported.
- The checklist has no item-by-item verification between 4:05 PM and 4:25 PM.

The checklist confirms that the display was considered ready at 4:05 PM. It does not record a close inspection of the trophy after that time.

## Evidence B — Photograph Contact Sheet
**Source:** Naina's event photo log

- Photo 12, 3:52 PM — Trophy on the display stand.
- Photo 19, 4:09 PM — Empty display stand visible in the background; the trophy is not in frame elsewhere.
- Photo 21, 4:16 PM — Awards table partly obscured by a grey equipment crate and rolled banners.

The contact sheet records what was captured, not everything happening outside the camera frame.

## Evidence C — Movement Notes
**Source:** Volunteer movement sheet

- Arjun moved two empty stage risers at 4:03 PM.
- Sameer moved a grey crate from the awards corridor toward the storage area at 4:11 PM.
- Naina requested a short photo setup near the awards table.
- Kavya signed out an awards-preparation folder at 4:00 PM.
- No entry records the trophy's destination after it left the display stand.

## Evidence D — Ceremony Schedule
**Source:** Final event schedule

The trophy presentation is scheduled for 5:00 PM. At 4:10 PM, the stage manager sends a reminder:

*“Please confirm the trophy and certificates are ready. No changes to the running order after 4:30 without approval.”*

## Question 1
**What does the awards checklist actually establish?**

A. The trophy was definitely on the stand at 4:25 PM.  
B. The display was considered ready at 4:05 PM, but there is no close item verification after that time.  
C. Sameer stole the trophy because he moved a crate.  
D. The trophy could not have been moved because the checklist was signed.

## Question 2
**Which movement is the most useful lead to investigate first?**

A. Arjun's movement of empty stage risers at 4:03 PM.  
B. Sameer's movement of the grey crate at 4:11 PM, because its contents and destination are not independently verified.  
C. Naina's photography, because cameras always reveal the entire room.  
D. Vikram's general note that the awards display looked ready.

## Question 3
**What is the most important fact to establish next?**

A. Who dislikes the winning team.  
B. Whether the trophy was moved for an approved activity, and what record should identify its destination.  
C. Whether the stage risers were heavy.  
D. Whether the closing ceremony can proceed without a trophy.

---

# Phase 2 — Following the Object

## Evidence E — Temporary Movement Slip
**Source:** Awards desk carbon-copy form

A movement slip was opened at 4:06 PM:

- Item: Founders' Trophy
- Reason: “Photo setup”
- Destination field: “Photo Bay”
- Return confirmation: blank
- Initiated by: Kavya Sen

The form authorizes a temporary move for photography. It does not record that the trophy was returned to the display stand.

## Evidence F — Photographer's Statement
**Source:** Naina's recorded interview

Naina says:

*“I asked for the trophy to be brought to the awards table for a group photograph. I took the group shot at about 4:08. I saw the trophy on the table then. I did not take it away, and I did not ask anyone to store it.”*

Her camera's timestamp confirms that the group photograph was taken at 4:08 PM. The photograph includes the trophy on the awards table, but the image does not show who carried it there.

## Evidence G — Storage Crate Register
**Source:** Logistics desk record

- 4:07 PM — Grey crate G-14 assigned to banner hardware.
- 4:11 PM — Sameer records G-14 as moved toward the storage area.
- 4:19 PM — G-14 marked “returned to storage.”
- The register does not list individual contents.
- No one signed a content check at return.

## Evidence H — Engraving Proof
**Source:** Vendor proof sheet found in the awards folder

The approved proof sheet displays the correct event title but lists the wrong winning team in the small nameplate text. A handwritten note beside it says:

*“Check final plate before presentation.”*

The note is initialled “K.S.” The sheet does not show whether the error was corrected.

## Evidence I — Stage Volunteer Statement
**Source:** Arjun's interview

Arjun says he moved only the empty display stand to make room for the photographer. He says the trophy was already on the awards table when he moved the stand. The photo timestamp supports the fact that the trophy was on the table at 4:08, but does not independently confirm the exact time Arjun moved the stand.

## Question 4
**What can investigators conclude from the temporary movement slip?**

A. The trophy was stolen by the photographer.  
B. The trophy was authorized to leave the display for photography, but its return was never recorded.  
C. Kavya definitely hid the trophy in the grey crate.  
D. The movement slip is proof that the trophy was returned.

## Question 5
**Which statement best describes Naina's role based on the evidence?**

A. She had a legitimate reason to have the trophy at the awards table, but the photo alone does not show who later moved it.  
B. She must have stolen it because she requested the photo setup.  
C. She could not have seen the trophy because the checklist was signed earlier.  
D. Her statement proves the trophy stayed on the table until 4:25 PM.

## Question 6
**Which lead most directly connects the missing trophy to a possible reason for concealing it?**

A. The empty stage risers.  
B. The engraving proof with the wrong winning-team name and the handwritten instruction to check the final plate.  
C. The general schedule reminder.  
D. The fact that Naina took a photograph.

---

# Phase 3 — Chain of Custody

## Evidence J — Awards Folder Contents
**Source:** Inventory of Kavya's signed awards-preparation folder

The folder contains:
- The temporary movement slip for the trophy.
- The engraving proof with the incorrect team name.
- A blank correction request form.
- A note reading: *“Do not announce until confirmed.”*

The correction request form has no vendor receipt or submission timestamp.

## Evidence K — Storage Area Inspection
**Source:** Joint inspection report

Grey crate G-14 is found in the storage area behind rolled banners. The crate contains banner brackets and a padded compartment that can hold a trophy upright. The compartment is empty at inspection.

A strip of protective felt inside the compartment matches the felt used under the Founders' Trophy base. This establishes that the crate was suitable for transporting the trophy, but does not prove the trophy was inside it at 4:11 PM.

## Evidence L — Revised Ceremony Draft
**Source:** Schedule file history

At 4:17 PM, Kavya drafts a note stating:

*“Presentation may need a short delay while the award is checked.”*

At 4:23 PM, after the trophy is reported missing, the draft is changed to:

*“Presentation delayed due to missing trophy.”*

The file history records both edits. It does not show that the first draft was sent to anyone.

## Evidence M — Vendor Call Record
**Source:** Event desk call log

At 4:12 PM, Kavya calls the engraving vendor. The call lasts 46 seconds. The desk log records the time and recipient, but not the conversation. Meera confirms that Kavya had been asking whether a replacement nameplate could be prepared quickly.

The call record supports a link between Kavya and the engraving issue; it does not, by itself, establish what she said or did with the trophy.

## Evidence N — Final Location Check
**Source:** Search log completed by event staff

At 4:32 PM, staff check:
- The awards display and table.
- The photo bay.
- The stage wings.
- The AV booth.
- The storage area, including the space behind the rolled banners.

The trophy is not found. G-14 is located, but the padded compartment is empty. The search log does not include a search of the locked awards office, which is opened later by the event lead.

## Question 7
**Which timeline is supported by the records?**

A. The trophy was on the display stand continuously from 3:40 PM until 4:25 PM.  
B. The trophy was moved for photography by 4:08 PM; its return was not recorded, and a storage crate was moved at 4:11 PM.  
C. The trophy was first moved after it was reported missing at 4:25 PM.  
D. The trophy was inside G-14 at 4:32 PM.

## Question 8
**What is the strongest interpretation of the engraving evidence and schedule drafts?**

A. They prove Meera stole the trophy.  
B. They show a possible reason to delay the presentation and connect Kavya to the unresolved engraving problem, but they need to be combined with movement evidence.  
C. They prove the trophy was never real.  
D. They are irrelevant because the nameplate is small.

## Question 9
**Which hypothesis best explains the combined evidence?**

A. Naina took the trophy after the photograph and left the event.  
B. Arjun hid the trophy while moving the empty stand.  
C. Kavya used the authorized photo movement as an opportunity to divert the trophy, failed to record its return, and prepared to delay the presentation while the engraving error was addressed.  
D. Sameer stole the trophy for its metal value.

---

# Final deduction

## Final Question 1 — Who was responsible?

Select one:

- Kavya Sen
- Arjun Rao
- Naina Rao
- Sameer Khan
- Meera Iyer
- Vikram Sethi

## Final Question 2 — What most likely happened?

A. The trophy was taken by a photographer after the group photo and carried out of the venue.  
B. The trophy was diverted after being legitimately moved for photography; the unresolved engraving error gave the awards coordinator a reason to delay the presentation, and the return was not recorded.  
C. The trophy was never delivered to the event.  
D. The trophy was destroyed while the display stand was being moved.

**Submit both answers.** The responsible-person and explanation components are graded independently.
