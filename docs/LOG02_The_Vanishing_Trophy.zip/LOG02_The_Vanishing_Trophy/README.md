# LOG02 — The Vanishing Trophy

**Track:** Logic  
**Version:** 0.1  
**Status:** Complete narrative prototype; requires playtesting before production seeding.

## Files
- `LOG02_Player_Case.md` — player-facing story, evidence and tasks.
- `LOG02_Author_Notes.md` — restricted ground truth, twist map, character reasoning and evidence map.
- `LOG02_Scoring_and_Hints.md` — proposed scoring, answer key and hints.
- `LOG02_Case_Manifest.json` — structured draft manifest.
- `LOG02_Validation_Checklist.md` — checks before implementation.

## Case identity
This case focuses on **chain of custody, document interpretation, and reconstructing an object's movement**. Unlike LOG01, the core puzzle is not a locked-room premise or a replica substitution. The key question is how a legitimate movement was diverted and concealed.

Do not expose author notes, answer keys, or hidden ground truth to players.
