# LOG02 — Author Notes (Restricted)

**Status:** Narrative prototype; review and playtest before seeding.  
**Intended final answer:** Kavya Sen + Final Explanation B.

## 1. Ground truth

Kavya Sen, the awards coordinator, was responsible for diverting the Founders' Trophy after it was legitimately moved from the display stand for the 4:08 PM group photograph. Kavya had discovered that the engraved nameplate showed the wrong winning team. She feared that presenting the trophy would expose the mistake and disrupt the closing ceremony.

Kavya did not return the trophy to the display. She used the awards-preparation process and movement gap to divert it into the grey crate route, then drafted a delay message. Her plan was to buy time to correct the engraving before the mistake became public. She later allowed the incident to be described as a missing trophy rather than immediately explaining the unresolved engraving problem.

**Important production gap:** The current evidence supports Kavya as the strongest explanation but does not yet conclusively prove the trophy was physically placed in G-14 by Kavya. Before seed-ready status, add one independent, fair clue that closes this gap without becoming a direct confession or making the answer trivial.

## 2. Central deductive mechanism

This is a chain-of-custody case, not a locked-room or replica-substitution case.

Players must distinguish:
- an object being checked as present,
- an object being moved for an authorized purpose,
- an object being returned,
- a record being completed,
- and an object being physically verified at a later time.

The key omission is the blank return confirmation on the temporary movement slip. The crate register also records movement but not contents. Neither document alone proves theft or diversion.

## 3. Twist map

### Twist 1 — The movement was initially legitimate
The trophy really was moved for a photograph. The initial story of a simple theft from a display is incomplete.

### Twist 2 — The chain of custody breaks
The temporary movement slip has no return confirmation. The trophy's last confirmed location is the awards table at the group photo, not the display stand at 4:25.

### Twist 3 — A plausible logistics lead is incomplete
Sameer moved the grey crate, and the crate was suitable for carrying the trophy. But the register does not prove its contents. This should be treated as corroboration, not direct proof.

### Twist 4 — The engraving error explains the concealed delay
The wrong nameplate, Kavya's folder, vendor call and evolving schedule draft reveal a plausible reason to prevent the ceremony from proceeding. The motive alone does not establish responsibility; it must be combined with custody and movement evidence.

## 4. Suspect assessment

- **Kavya Sen:** Initiated the authorized trophy movement; owns the awards folder containing the incorrect engraving proof and correction form; called the vendor; drafted a delay before the missing report. Intended responsible person, but physical diversion link must be strengthened.
- **Arjun Rao:** Moved the empty stand, but the trophy was already on the awards table for the photograph. No evidence connects him to later custody.
- **Naina Rao:** Requested the photo setup and documented the trophy on the table. The photograph does not show her taking it afterward.
- **Sameer Khan:** Moved G-14, a suitable crate. Its contents at the critical time are unknown; he is a deliberate red herring.
- **Meera Iyer:** Liaised with the engraving vendor and knew about the proof, but there is no evidence she handled the trophy after the photo.
- **Vikram Sethi:** Made a general display-readiness note but did not inspect the trophy closely.

## 5. Evidence-to-solution map

| Conclusion | Evidence |
|---|---|
| Trophy present at display at 3:52 | A, B |
| Trophy was moved for photo setup | E, F |
| Return was not documented | E |
| Crate movement is a plausible but unproven lead | C, G, K |
| Engraving problem existed | H, J |
| Kavya knew about the engraving issue | H, J, M |
| Delay planning preceded missing report | L |
| Best-supported explanation is diversion during custody gap | E, F, H, J, L, M considered together |

## 6. Gaps to close before production

1. **Physical diversion link:** Add independent evidence that ties Kavya to the trophy's later route, not merely to the paperwork and motive. Example directions: a time-stamped neutral observation of her handling the crate, a signed handoff record with a contradictory destination, or an event photo detail that can be interpreted fairly. Avoid a convenient confession.
2. **Exact destination:** Ground truth says the trophy is temporarily diverted, but the current case does not actually recover it. Decide whether the final outcome should be “concealed at a specific place” or “responsible for the diversion but location unresolved.” The current player evidence supports responsibility better than a precise final location.
3. **Crate ambiguity:** If G-14 is the actual transport route, add a clue that differentiates a real trophy transfer from ordinary banner hardware without claiming the empty compartment proves what it once contained.
4. **Kavya's motive:** Make the causal reason for hiding the trophy clearer and fair. A wrong engraving can explain a delay, but it should not automatically imply a plan to fake a disappearance.
5. **Timeline consistency:** Confirm the photo, movement slip, crate movement and drafts all agree. The current photo at 4:08 and crate movement at 4:11 provide a narrow but plausible window.
6. **Deterministic questions:** Q2 and Q3 ask for best next steps. Confirm the answer options are unambiguously best given currently unlocked evidence.
7. **Question 8 wording:** It asks about combined evidence; make sure all referenced documents have been unlocked by that point.

## 7. Information policy

Never expose this document, ground truth, answer keys or future-phase evidence to players. Keep answer keys server-side. Player-facing endpoints must enforce phase unlocks.
