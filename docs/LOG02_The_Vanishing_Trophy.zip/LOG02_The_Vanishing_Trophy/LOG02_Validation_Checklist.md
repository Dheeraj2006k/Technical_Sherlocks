# LOG02 — Validation Checklist

## Story logic
- [ ] Add an independent clue connecting Kavya to the physical diversion, not only to paperwork and motive.
- [ ] Decide whether the trophy is recovered; if so, establish its location through fair evidence.
- [ ] Ensure the crate clue corroborates the solution without pretending its former contents are directly known.
- [ ] Make the motivation for delaying the presentation clear and believable.
- [ ] Recheck all timestamps and ensure each record's stated scope is precise.
- [ ] Ensure the intended solution is stronger than all alternatives using only unlocked evidence.

## Tasks
- [ ] Make Q2 and Q3 deterministic enough for automatic grading.
- [ ] Verify every task has one unambiguous correct answer.
- [ ] Verify no task requires knowledge from a later phase.
- [ ] Ensure at least two Phase 1 clues gain new meaning in Phase 3.
- [ ] Playtest whether players can explain why Sameer's crate movement is suspicious but not proof.

## Scoring
- [ ] Reconcile the proposed five-point tasks with the global 10, 8, 6, 4, 2 ladder.
- [ ] Verify base score totals 100.
- [ ] Test -2 wrong committed answer penalty, retries, idempotency and score floor.
- [ ] Ensure final person and explanation components are graded independently.

## Implementation
- [ ] Keep answer keys and author notes server-side.
- [ ] Enforce phase unlocks on the server.
- [ ] Prevent API access to future-phase evidence.
- [ ] Store attempts separately from successful task completion.
- [ ] Test solo, duo and trio progression.

## Playtesting
- [ ] Run solo first-time playtest.
- [ ] Run duo and trio playtests.
- [ ] Record time per phase and total completion time.
- [ ] Ask testers to explain the chain-of-custody break.
- [ ] Ask testers to distinguish motive, opportunity, corroboration and direct proof.
