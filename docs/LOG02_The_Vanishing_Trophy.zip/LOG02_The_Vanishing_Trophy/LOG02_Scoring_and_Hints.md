# LOG02 — Scoring, Hints and Answer Key

**Status:** Proposed scoring draft; reconcile with global rules before implementation.

## Proposed base points

| Component | Points proposed |
|---|---:|
| Questions 1–3 | 15 total |
| Questions 4–6 | 15 total |
| Questions 7–9 | 15 total |
| Final responsible person | 35 |
| Final explanation | 20 |
| **Total** | **100** |

This draft uses five points per investigation question with a proposed hint ladder of 5, 4, 3, 2, 1.

**Global scoring compatibility:** The previously agreed standard task ladder is 10, 8, 6, 4, 2. The five-point ladder here is a proposal for this prototype, not an automatic change to global scoring. Before implementation, either consolidate/restructure tasks to use the standard ladder or formally approve a second task type. Wrong committed answers cost -2 under the current global rule. Successful components award points once only; score floor is zero.

## Answer key

| Item | Answer | Rationale |
|---|---|---|
| Q1 | B | The checklist does not verify the trophy after 4:05. |
| Q2 | B | The grey crate has unverified contents and destination. |
| Q3 | B | The next step is to establish the authorized movement and destination. |
| Q4 | B | The movement was authorized for photos, but return was not recorded. |
| Q5 | A | The photo supports Naina's limited role but does not show later movement. |
| Q6 | B | The engraving proof provides a plausible reason for a concealed delay. |
| Q7 | B | The trophy was on the table at 4:08; the return is unrecorded; the crate moved at 4:11. |
| Q8 | B | The documents show a motive/context but need movement evidence. |
| Q9 | C | This best integrates the custody gap, engraving problem and early delay draft. |
| Final person | Kavya Sen | Intended responsible person. |
| Final explanation | B | Trophy diverted after photo movement; unresolved engraving error motivated delay. |

## Hint ladders

### Q1
1. Check the time of the last actual item verification.
2. What does “display looks ready” mean?
3. The checklist is not an item-by-item inspection after 4:05.

### Q2
1. Follow an object whose contents are not checked.
2. Which movement record has both a destination and contents gap?
3. Investigate the grey crate's route and contents.

### Q3
1. Establish the last confirmed location before searching for a culprit.
2. Look for an authorized movement record and its return field.
3. The temporary movement slip is the first break in the chain of custody.

### Q4
1. Separate authorization from proof of return.
2. The slip authorizes the photo movement.
3. Its return confirmation is blank.

### Q5
1. What does the photograph show directly?
2. It shows the trophy on the table at 4:08, not what happened afterward.
3. Naina's role in the photo does not prove later custody.

### Q6
1. Look for a problem that would make the ceremony difficult.
2. Inspect the engraving proof.
3. The wrong team name could explain pressure to delay the presentation.

### Q7
1. Put the photo, crate movement and missing report in order.
2. The trophy was on the table at 4:08; the crate moved at 4:11.
3. The record supports an unrecorded return/diversion window, not continuous presence on the stand.

### Q8
1. Motive and opportunity are separate.
2. The paperwork links Kavya to the engraving issue and a planned delay.
3. Combine this with the movement records; do not treat motive as proof by itself.

### Q9
1. Compare which theory explains both the custody gap and the timing of the draft.
2. Consider the person who handled the authorized movement and knew about the engraving problem.
3. The strongest theory is a diversion during the unrecorded return period to delay the presentation.

## Implementation notes
- Keep answer keys server-side.
- Log attempts separately from successful completions.
- Apply wrong-answer penalties only to committed incorrect submissions.
- Grade final person and explanation independently.
- Make successful completion idempotent.
- Enforce phase unlocks on the server.
