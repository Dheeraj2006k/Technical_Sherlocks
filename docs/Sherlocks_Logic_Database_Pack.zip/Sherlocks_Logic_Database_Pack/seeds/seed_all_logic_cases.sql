-- Seed data for LOG01 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
-- begin omitted for combined transaction
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG01', 'The Locked Room That Wasn''t', 'LOGIC', '0.1', 1, 'draft_not_seed_ready', 'pre-closure substitution and timeline reconstruction', 100, '{"investigation_max_each":5,"hint_rewards":[5,4,3,2,1],"investigation_task_count":9,"final_person_points":35,"final_explanation_points":20,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Legacy authored allocation conflicts with platform standard 10/8/6/4/2 ladder; do not activate until score model is reconciled."}'::jsonb, '{"case_id":"LOG01","title":"The Locked Room That Wasn''t","track":"LOGIC","version":"0.1","status":"prototype_not_seed_ready","language":"en","phases":[{"phase":1,"name":"Discovery","evidence_ids":["A","B","C","D"],"task_ids":["Q1","Q2","Q3"]},{"phase":2,"name":"Investigation","evidence_ids":["E","F","G","H","I"],"task_ids":["Q4","Q5","Q6"]},{"phase":3,"name":"Reconstruction","evidence_ids":["J","K","L","M","N"],"task_ids":["Q7","Q8","Q9"]}],"characters":[{"id":"rohan_mehta","name":"Rohan Mehta","role":"Competing team leader"},{"id":"naina_rao","name":"Naina Rao","role":"Event photographer"},{"id":"imran_shaikh","name":"Imran Shaikh","role":"Lab technician"},{"id":"devika_nair","name":"Devika Nair","role":"Room key custodian"},{"id":"vikram_sethi","name":"Vikram Sethi","role":"Showcase coordinator"},{"id":"aditya_varma","name":"Aditya Varma","role":"Aster''s creator"}],"tasks":[{"task_id":"Q1","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q2","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q3","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q4","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q5","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q6","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q7","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q8","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"},{"task_id":"Q9","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"}],"final_deduction":{"person_points_proposed":35,"correct_person_id":"vikram_sethi","explanation_points_proposed":20,"correct_explanation":"C"},"scoring_proposed":{"ordinary_question_points":5,"hint_ladder":[5,4,3,2,1],"wrong_committed_answer_penalty":-2,"total_base_points":100,"status":"requires_reconciliation_with_global_scoring_rules"},"author_only":{"ground_truth":"Vikram removed the genuine Aster before room closure, substituted the replica, and prepared a security-related delay after learning the prototype had failed its output check.","twists":["Rohan is an initially plausible suspect but proximity and motive do not prove guilt.","The object in the 4:18 photograph is a replica.","The substitution occurred before the room was reported closed.","Vikram''s early schedule draft changes the interpretation of the incident."]},"validation_status":{"story_logic_review":"needs_review","physical_link_to_substitution":"gap_to_resolve","innocent_suspect_opportunity_boundaries":"gap_to_resolve","timeline_consistency":"needs_review","playtest":"not_done","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG01', 1, 'Discovery'),
  ('LOG01', 2, 'Investigation'),
  ('LOG01', 3, 'Reconstruction')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG01', 'rohan_mehta', 'Rohan Mehta', 'Competing team leader', 1),
  ('LOG01', 'naina_rao', 'Naina Rao', 'Event photographer', 2),
  ('LOG01', 'imran_shaikh', 'Imran Shaikh', 'Lab technician', 3),
  ('LOG01', 'devika_nair', 'Devika Nair', 'Room key custodian', 4),
  ('LOG01', 'vikram_sethi', 'Vikram Sethi', 'Showcase coordinator', 5),
  ('LOG01', 'aditya_varma', 'Aditya Varma', 'Aster''s creator', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG01', 'A', 1, 'Room Closure Log', 'Devika''s signed checklist', '- 4:05 PM — Aster checked in the display case.
- 4:16 PM — Final room sweep started.
- 4:20 PM — Room reported closed.
- 4:21 PM — Key returned to the event desk.
- 4:30 PM — Missing prototype reported.

Devika''s note reads: *“Display appeared complete before closure.”*', 1),
  ('LOG01', 'B', 1, 'Access and Movement Notes', 'Staff movement sheet and witness statements', '- Rohan was seen near Innovation Room B around 4:08 PM.
- Imran worked on the display lighting earlier that afternoon.
- Naina was inside the room for official photographs.
- Vikram visited the room during preparation.
- Devika was responsible for the key and closing checklist.

The sheet records **presence near the room**, not proof of entry at the time Aster disappeared.', 2),
  ('LOG01', 'C', 1, 'Two Photographs', 'Naina''s official event photo set', '- Photo 1: 4:07 PM — Aster in its display case.
- Photo 2: 4:18 PM — The display case appears complete from the front.

The second photograph is slightly angled. A small label on the base is partly obscured by glare.', 3),
  ('LOG01', 'D', 1, 'The Rehearsal Note', 'Event preparation notebook', 'At 3:52 PM, Aditya wrote:

*“Check the output before the live demo. If the fault returns, do not present it as fully working.”*

There is no signature beside the note and no indication that the issue was resolved.', 4),
  ('LOG01', 'E', 2, 'The Prototype Identification Sheet', 'Aditya''s pre-event technical checklist', 'The genuine Aster has three identifying features:

1. A small blue inspection mark on the underside of its base.
2. A short scratch beside the left mounting screw.
3. A green indicator that lights up when the device is powered.

The display replica was made for photographs and has the same outer shell, but it has no functioning indicator and no internal electronics.', 5),
  ('LOG01', 'F', 2, 'The Enlarged 4:18 Photograph', 'Enhanced crop of Naina''s original photograph', 'The photograph reveals the display''s left mounting screw and the label on its base. The blue inspection mark is absent. The green indicator is dark, and its lens is a solid piece rather than the transparent lens fitted to the genuine prototype.

The image does not prove that the device is switched off: the lens itself is visibly different.', 6),
  ('LOG01', 'G', 2, 'Rohan''s Account', 'Recorded interview', 'Rohan says:

*“I went to the corridor at about 4:08 to collect our presentation file. I did not enter the room. I saw Vikram carrying a flat black event case near the AV booth, but I thought it held cables.”*

Rohan initially denied being near the room, then corrected himself when shown the movement sheet. His first answer was misleading, but the second part of his account is independently testable.', 7),
  ('LOG01', 'H', 2, 'AV Booth Equipment Register', 'Event equipment checkout sheet', '- 4:02 PM — Vikram signs out a flat black equipment case.
- 4:24 PM — The case is listed as returned to the AV booth.
- The register does not record what was placed inside the case.
- No one records an inspection of the case at return.', 8),
  ('LOG01', 'I', 2, 'Maintenance Record', 'Imran''s signed work note', 'Imran repaired the display lighting at 3:35 PM. He records that he did not remove the display''s backing panel and that the case was left open for Aditya''s inspection afterward.

Aditya''s signature confirms the case was open during the inspection. No evidence places Imran inside the room during the later 4:07–4:20 period.', 9),
  ('LOG01', 'J', 3, 'The Rehearsal Follow-up', 'Aditya''s message to the showcase team', 'At 4:00 PM, Aditya sends the team a message:

*“Aster failed the output check again. I need ten minutes to inspect it. Please don''t announce that it''s ready yet.”*

The message is delivered to the event preparation group, which includes Vikram. The delivery record confirms that Vikram''s account received it at 4:01 PM.', 10),
  ('LOG01', 'K', 3, 'The Unsent Schedule Change', 'Event coordinator''s draft schedule', 'At 4:14 PM, Vikram drafts a schedule update stating that Aster''s demonstration may be delayed because of a *“security incident in Innovation Room B.”*

The draft is never sent. Its creation time is recorded by the event scheduling system. The draft alone does not prove that Vikram caused the incident; it does show he was preparing for a delay before the missing prototype was officially reported.', 11),
  ('LOG01', 'L', 3, 'AV Booth Inspection', 'Joint inspection by the event staff', 'The flat black case Vikram signed out is found in the AV booth. Inside it is a foam insert cut to fit the Aster prototype. A small piece of blue protective tape matching the prototype''s packaging is stuck to the insert.

The prototype is not inside the case when it is inspected. The insert proves the case was configured to carry a device of Aster''s size, but does not independently prove that the genuine Aster was inside it.', 12),
  ('LOG01', 'M', 3, 'Aditya''s Final Identification', 'Comparison of the replica with the genuine prototype''s build notes', 'Aditya confirms that the object in the 4:18 photograph is the replica, not the working Aster. The replica''s solid indicator lens, missing inspection mark and different mounting screw are all consistent with his identification sheet.

He also confirms that the genuine Aster was functioning earlier in the afternoon but had failed the 4:00 PM output check. He had not authorized anyone to replace it with the display model.', 13),
  ('LOG01', 'N', 3, 'The Witness Timeline', 'Independently collected statements', '- **Aditya:** sent the failure warning at 4:00 PM and did not authorize a swap.
- **Rohan:** saw Vikram with the black case near the AV booth around 4:08 PM.
- **Naina:** took the photograph showing the replica at 4:18 PM.
- **Devika:** closed the room at 4:20 PM based on the visual checklist.
- **Vikram:** drafted a security-incident schedule change at 4:14 PM.

The statements and records establish a sequence, but no single item directly captures Vikram physically taking Aster.', 14)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG01', 'Q1', 1, 1, '**Which conclusion is actually supported by the closure log?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q2', 1, 2, '**Which suspect has the clearest apparent motive from the evidence available so far?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q3', 1, 3, '**What is the most useful next step?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q4', 1, 4, '**What does the 4:18 photograph establish?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q5', 1, 5, '**Which conclusion about Rohan is best supported now?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q6', 1, 6, '**Which lead should investigators pursue next to test the removal timeline?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q7', 1, 7, '**Which timeline is consistent with all the evidence?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q8', 1, 8, '**What is the strongest interpretation of the black equipment case?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q9', 1, 9, '**Which hypothesis best explains the full set of evidence with the fewest unsupported assumptions?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG01', 'Q1', 'A', 'Rohan stole Aster because he was near the room.', 1),
  ('LOG01', 'Q1', 'B', 'The room was reported closed at 4:20 PM, but the log does not prove when Aster was last physically present.', 2),
  ('LOG01', 'Q1', 'C', 'Aster was definitely present at 4:20 PM.', 3),
  ('LOG01', 'Q1', 'D', 'Devika must have taken Aster because she held the key.', 4),
  ('LOG01', 'Q2', 'A', 'Rohan', 1),
  ('LOG01', 'Q2', 'B', 'Naina', 2),
  ('LOG01', 'Q2', 'C', 'Imran', 3),
  ('LOG01', 'Q2', 'D', 'Devika', 4),
  ('LOG01', 'Q3', 'A', 'Accuse Rohan before he can leave.', 1),
  ('LOG01', 'Q3', 'B', 'Verify whether the object in the 4:18 photograph is the genuine Aster.', 2),
  ('LOG01', 'Q3', 'C', 'Assume the key register proves no one could have removed the prototype.', 3),
  ('LOG01', 'Q3', 'D', 'Investigate every person who has ever worked in the lab.
---
# Phase 2 — Investigation
## Evidence E — The Prototype Identification Sheet
**Source:** Aditya''s pre-event technical checklist
The genuine Aster has three identifying features:
1. A small blue inspection mark on the underside of its base.
2. A short scratch beside the left mounting screw.
3. A green indicator that lights up when the device is powered.
The display replica was made for photographs and has the same outer shell, but it has no functioning indicator and no internal electronics.
## Evidence F — The Enlarged 4:18 Photograph
**Source:** Enhanced crop of Naina''s original photograph
The photograph reveals the display''s left mounting screw and the label on its base. The blue inspection mark is absent. The green indicator is dark, and its lens is a solid piece rather than the transparent lens fitted to the genuine prototype.
The image does not prove that the device is switched off: the lens itself is visibly different.
## Evidence G — Rohan''s Account
**Source:** Recorded interview
Rohan says:
*“I went to the corridor at about 4:08 to collect our presentation file. I did not enter the room. I saw Vikram carrying a flat black event case near the AV booth, but I thought it held cables.”*
Rohan initially denied being near the room, then corrected himself when shown the movement sheet. His first answer was misleading, but the second part of his account is independently testable.
## Evidence H — AV Booth Equipment Register
**Source:** Event equipment checkout sheet
- 4:02 PM — Vikram signs out a flat black equipment case.
- 4:24 PM — The case is listed as returned to the AV booth.
- The register does not record what was placed inside the case.
- No one records an inspection of the case at return.
## Evidence I — Maintenance Record
**Source:** Imran''s signed work note
Imran repaired the display lighting at 3:35 PM. He records that he did not remove the display''s backing panel and that the case was left open for Aditya''s inspection afterward.
Aditya''s signature confirms the case was open during the inspection. No evidence places Imran inside the room during the later 4:07–4:20 period.', 4),
  ('LOG01', 'Q4', 'A', 'Aster was definitely present because a device-shaped object is visible.', 1),
  ('LOG01', 'Q4', 'B', 'The genuine Aster was likely replaced by the display replica before the room was closed.', 2),
  ('LOG01', 'Q4', 'C', 'Naina stole Aster because she took the photograph.', 3),
  ('LOG01', 'Q4', 'D', 'The room''s lock was defective.', 4),
  ('LOG01', 'Q5', 'A', 'He is guilty because he initially denied being near the room.', 1),
  ('LOG01', 'Q5', 'B', 'His account contains a contradiction that must be checked, but his presence alone does not prove he entered or removed Aster.', 2),
  ('LOG01', 'Q5', 'C', 'He is innocent because he eventually told the truth.', 3),
  ('LOG01', 'Q5', 'D', 'He must have used Imran''s tools.', 4),
  ('LOG01', 'Q6', 'A', 'Search the AV booth and determine whether the returned equipment case could still contain Aster.', 1),
  ('LOG01', 'Q6', 'B', 'Accuse Naina because the replica appears in her photograph.', 2),
  ('LOG01', 'Q6', 'C', 'Reopen Imran''s maintenance work without checking the later timeline.', 3),
  ('LOG01', 'Q6', 'D', 'Treat Devika''s closure checklist as proof that the genuine prototype was present at 4:20.
---
# Phase 3 — Reconstruction
## Evidence J — The Rehearsal Follow-up
**Source:** Aditya''s message to the showcase team
At 4:00 PM, Aditya sends the team a message:
*“Aster failed the output check again. I need ten minutes to inspect it. Please don''t announce that it''s ready yet.”*
The message is delivered to the event preparation group, which includes Vikram. The delivery record confirms that Vikram''s account received it at 4:01 PM.
## Evidence K — The Unsent Schedule Change
**Source:** Event coordinator''s draft schedule
At 4:14 PM, Vikram drafts a schedule update stating that Aster''s demonstration may be delayed because of a *“security incident in Innovation Room B.”*
The draft is never sent. Its creation time is recorded by the event scheduling system. The draft alone does not prove that Vikram caused the incident; it does show he was preparing for a delay before the missing prototype was officially reported.
## Evidence L — AV Booth Inspection
**Source:** Joint inspection by the event staff
The flat black case Vikram signed out is found in the AV booth. Inside it is a foam insert cut to fit the Aster prototype. A small piece of blue protective tape matching the prototype''s packaging is stuck to the insert.
The prototype is not inside the case when it is inspected. The insert proves the case was configured to carry a device of Aster''s size, but does not independently prove that the genuine Aster was inside it.
## Evidence M — Aditya''s Final Identification
**Source:** Comparison of the replica with the genuine prototype''s build notes
Aditya confirms that the object in the 4:18 photograph is the replica, not the working Aster. The replica''s solid indicator lens, missing inspection mark and different mounting screw are all consistent with his identification sheet.
He also confirms that the genuine Aster was functioning earlier in the afternoon but had failed the 4:00 PM output check. He had not authorized anyone to replace it with the display model.
## Evidence N — The Witness Timeline
**Source:** Independently collected statements
- **Aditya:** sent the failure warning at 4:00 PM and did not authorize a swap.
- **Rohan:** saw Vikram with the black case near the AV booth around 4:08 PM.
- **Naina:** took the photograph showing the replica at 4:18 PM.
- **Devika:** closed the room at 4:20 PM based on the visual checklist.
- **Vikram:** drafted a security-incident schedule change at 4:14 PM.
The statements and records establish a sequence, but no single item directly captures Vikram physically taking Aster.', 4),
  ('LOG01', 'Q7', 'A', 'The room was locked at 4:20, then someone entered and replaced Aster with the replica.', 1),
  ('LOG01', 'Q7', 'B', 'Vikram learned about the failed output check, prepared for a possible security-related delay, and the replica was in place before the room closed.', 2),
  ('LOG01', 'Q7', 'C', 'Rohan removed Aster after 4:20, then returned the replica without being seen.', 3),
  ('LOG01', 'Q7', 'D', 'Imran''s 3:35 lighting repair proves he took Aster.', 4),
  ('LOG01', 'Q8', 'A', 'It conclusively proves Vikram transported the genuine Aster.', 1),
  ('LOG01', 'Q8', 'B', 'It is irrelevant because the prototype was not found inside it.', 2),
  ('LOG01', 'Q8', 'C', 'It independently links Vikram to a container prepared for an object of Aster''s size, supporting—but not proving—the removal theory.', 3),
  ('LOG01', 'Q8', 'D', 'It proves Rohan lied about everything.', 4),
  ('LOG01', 'Q9', 'A', 'Rohan entered the locked room after 4:20 and somehow replaced the genuine prototype.', 1),
  ('LOG01', 'Q9', 'B', 'Imran used his maintenance knowledge to bypass the room''s lock after closure.', 2),
  ('LOG01', 'Q9', 'C', 'Vikram used the failed rehearsal as a reason to remove Aster before closure, substitute the replica, and prepare a security-related delay.', 3),
  ('LOG01', 'Q9', 'D', 'Naina accidentally photographed a different prototype and caused the entire incident through a camera error.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG01', 'Q1', 1, 'Separate the record''s timestamp from the conclusion someone draws from it.'),
  ('LOG01', 'Q1', 2, 'What did the staff actually verify?'),
  ('LOG01', 'Q1', 3, 'The checklist records a closure process, not a forensic identification of the object.'),
  ('LOG01', 'Q2', 1, 'Identify the person with a documented conflict involving Aster''s team.'),
  ('LOG01', 'Q2', 2, 'Which conflict could plausibly motivate interference?'),
  ('LOG01', 'Q2', 3, 'Rohan has the clearest apparent motive so far, but motive is not proof.'),
  ('LOG01', 'Q3', 1, 'Before asking how an object left, verify which object is visible.'),
  ('LOG01', 'Q3', 2, 'Compare the photograph with the identification sheet.'),
  ('LOG01', 'Q3', 3, 'Look for physical features that cannot be explained by the device merely being switched off.'),
  ('LOG01', 'Q4', 1, 'Compare the identification sheet with the enlarged photograph.'),
  ('LOG01', 'Q4', 2, 'Look at the inspection mark and indicator lens.'),
  ('LOG01', 'Q4', 3, 'The lens itself is different, not merely unlit.'),
  ('LOG01', 'Q5', 1, 'Evaluate each part of Rohan''s account separately.'),
  ('LOG01', 'Q5', 2, 'Check the claim about the black case against an independent record.'),
  ('LOG01', 'Q5', 3, 'The register confirms Vikram checked out a case, but neither fact alone proves theft.'),
  ('LOG01', 'Q6', 1, 'Which object has an unverified chain of custody?'),
  ('LOG01', 'Q6', 2, 'The equipment register does not state what the case contained.'),
  ('LOG01', 'Q6', 3, 'Inspect the returned case and its insert.'),
  ('LOG01', 'Q7', 1, 'Put the message, draft, photograph and closure log in time order.'),
  ('LOG01', 'Q7', 2, 'The replica appears before the room is reported closed.'),
  ('LOG01', 'Q7', 3, 'The evidence supports a pre-closure substitution, not a post-lock entry.'),
  ('LOG01', 'Q8', 1, 'Separate what the case physically proves from what investigators infer.'),
  ('LOG01', 'Q8', 2, 'The case has a fitted insert and packaging trace, but the prototype is absent.'),
  ('LOG01', 'Q8', 3, 'It supports the removal theory without conclusively proving the case''s contents at the critical time.'),
  ('LOG01', 'Q9', 1, 'Compare how many independent records each hypothesis explains.'),
  ('LOG01', 'Q9', 2, 'Consider who knew about the failed prototype and prepared for a security-related delay.'),
  ('LOG01', 'Q9', 3, 'Combine the rehearsal warning, early draft, case evidence and pre-closure replica.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG01', 35, 'vikram_sethi', 20, 'C', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG01', 'rohan_mehta', 1),
  ('LOG01', 'naina_rao', 2),
  ('LOG01', 'imran_shaikh', 3),
  ('LOG01', 'devika_nair', 4),
  ('LOG01', 'vikram_sethi', 5),
  ('LOG01', 'aditya_varma', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG01', 'A', 'The genuine Aster was stolen after the room was locked, using an unknown way into the room.', 1),
  ('LOG01', 'B', 'The genuine Aster was accidentally damaged during maintenance, and the display model was substituted to hide the damage.', 2),
  ('LOG01', 'C', 'The genuine Aster was removed before closure and replaced with a replica; the disappearance was used to create a security-related delay after the rehearsal failure.', 3),
  ('LOG01', 'D', 'The genuine Aster was never placed in the room; the entire event team mistakenly believed a replica was the real prototype.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG01', 'story_logic_review', 'pending', 'Review timeline and ensure phase evidence is internally consistent.'),
  ('LOG01', 'physical_link_to_substitution', 'fail', 'Current authored case lacks independent time-bounded proof linking Vikram to the physical swap.'),
  ('LOG01', 'opportunity_boundaries', 'fail', 'Presence/opportunity boundaries for innocent suspects are not independently established.'),
  ('LOG01', 'scoring_reconciliation', 'fail', '5-point task ladder conflicts with the platform-wide 10/8/6/4/2 ladder.'),
  ('LOG01', 'hint_content', 'fail', 'Only three hints are authored per task while the legacy scoring text describes a five-level ladder.'),
  ('LOG01', 'playtest', 'pending', 'No first-time solo playtest documented.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

-- commit omitted for combined transaction


-- Seed data for LOG02 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
-- begin omitted for combined transaction
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG02', 'The Vanishing Trophy', 'LOGIC', '0.1', 1, 'draft_not_seed_ready', 'chain_of_custody_and_object_movement', 100, '{"investigation_max_each":5,"hint_rewards":[5,4,3,2,1],"investigation_task_count":9,"final_person_points":35,"final_explanation_points":20,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Legacy authored allocation conflicts with platform standard 10/8/6/4/2 ladder; do not activate until score model is reconciled."}'::jsonb, '{"case_id":"LOG02","title":"The Vanishing Trophy","track":"LOGIC","version":"0.1","status":"prototype_not_seed_ready","core_mechanism":"chain_of_custody_and_object_movement","phases":[{"phase":1,"name":"Discovery","evidence_ids":["A","B","C","D"],"task_ids":["Q1","Q2","Q3"]},{"phase":2,"name":"Following the Object","evidence_ids":["E","F","G","H","I"],"task_ids":["Q4","Q5","Q6"]},{"phase":3,"name":"Chain of Custody","evidence_ids":["J","K","L","M","N"],"task_ids":["Q7","Q8","Q9"]}],"characters":[{"id":"kavya_sen","name":"Kavya Sen","role":"Awards coordinator"},{"id":"arjun_rao","name":"Arjun Rao","role":"Stage volunteer"},{"id":"naina_rao","name":"Naina Rao","role":"Event photographer"},{"id":"sameer_khan","name":"Sameer Khan","role":"Logistics volunteer"},{"id":"meera_iyer","name":"Meera Iyer","role":"Engraving liaison"},{"id":"vikram_sethi","name":"Vikram Sethi","role":"Showcase coordinator"}],"tasks":[{"task_id":"Q1","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q2","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q3","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q4","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q5","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q6","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q7","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q8","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q9","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"}],"final_deduction":{"person_points_proposed":35,"correct_person_id":"kavya_sen","explanation_points_proposed":20,"correct_explanation":"B"},"scoring_proposed":{"ordinary_question_points":5,"hint_ladder":[5,4,3,2,1],"wrong_committed_answer_penalty":-2,"total_base_points":100,"status":"requires_reconciliation_with_global_scoring_rules"},"author_only":{"ground_truth":"Kavya diverted the Founders'' Trophy after the authorized photo movement, failed to record its return, and sought to delay the presentation while an incorrect engraving was addressed.","twists":["The initial theft framing is incomplete: the trophy was moved for an authorized photo.","The return field on the movement slip is blank.","The grey crate is a plausible lead, but its recorded contents are unverified.","The engraving error and early schedule draft explain the pressure to delay the presentation."]},"validation_status":{"chain_of_custody":"needs_closure","physical_link_to_diversion":"gap_to_resolve","exact_trophy_location":"not_established_in_player_evidence","timeline_consistency":"needs_review","deterministic_task_review":"needed","playtest":"not_done","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG02', 1, 'Discovery'),
  ('LOG02', 2, 'Following the Object'),
  ('LOG02', 3, 'Chain of Custody')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG02', 'kavya_sen', 'Kavya Sen', 'Awards coordinator', 1),
  ('LOG02', 'arjun_rao', 'Arjun Rao', 'Stage volunteer', 2),
  ('LOG02', 'naina_rao', 'Naina Rao', 'Event photographer', 3),
  ('LOG02', 'sameer_khan', 'Sameer Khan', 'Logistics volunteer', 4),
  ('LOG02', 'meera_iyer', 'Meera Iyer', 'Engraving liaison', 5),
  ('LOG02', 'vikram_sethi', 'Vikram Sethi', 'Showcase coordinator', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG02', 'A', 1, 'Awards Display Checklist', 'Signed awards checklist', '- 3:40 PM — Trophy placed on the display stand.
- 3:55 PM — Display area opened for official photographs.
- 4:05 PM — Vikram notes: “Awards display looks ready.”
- 4:25 PM — Missing trophy reported.
- The checklist has no item-by-item verification between 4:05 PM and 4:25 PM.

The checklist confirms that the display was considered ready at 4:05 PM. It does not record a close inspection of the trophy after that time.', 1),
  ('LOG02', 'B', 1, 'Photograph Contact Sheet', 'Naina''s event photo log', '- Photo 12, 3:52 PM — Trophy on the display stand.
- Photo 19, 4:09 PM — Empty display stand visible in the background; the trophy is not in frame elsewhere.
- Photo 21, 4:16 PM — Awards table partly obscured by a grey equipment crate and rolled banners.

The contact sheet records what was captured, not everything happening outside the camera frame.', 2),
  ('LOG02', 'C', 1, 'Movement Notes', 'Volunteer movement sheet', '- Arjun moved two empty stage risers at 4:03 PM.
- Sameer moved a grey crate from the awards corridor toward the storage area at 4:11 PM.
- Naina requested a short photo setup near the awards table.
- Kavya signed out an awards-preparation folder at 4:00 PM.
- No entry records the trophy''s destination after it left the display stand.', 3),
  ('LOG02', 'D', 1, 'Ceremony Schedule', 'Final event schedule', 'The trophy presentation is scheduled for 5:00 PM. At 4:10 PM, the stage manager sends a reminder:

*“Please confirm the trophy and certificates are ready. No changes to the running order after 4:30 without approval.”*', 4),
  ('LOG02', 'E', 2, 'Temporary Movement Slip', 'Awards desk carbon-copy form', 'A movement slip was opened at 4:06 PM:

- Item: Founders'' Trophy
- Reason: “Photo setup”
- Destination field: “Photo Bay”
- Return confirmation: blank
- Initiated by: Kavya Sen

The form authorizes a temporary move for photography. It does not record that the trophy was returned to the display stand.', 5),
  ('LOG02', 'F', 2, 'Photographer''s Statement', 'Naina''s recorded interview', 'Naina says:

*“I asked for the trophy to be brought to the awards table for a group photograph. I took the group shot at about 4:08. I saw the trophy on the table then. I did not take it away, and I did not ask anyone to store it.”*

Her camera''s timestamp confirms that the group photograph was taken at 4:08 PM. The photograph includes the trophy on the awards table, but the image does not show who carried it there.', 6),
  ('LOG02', 'G', 2, 'Storage Crate Register', 'Logistics desk record', '- 4:07 PM — Grey crate G-14 assigned to banner hardware.
- 4:11 PM — Sameer records G-14 as moved toward the storage area.
- 4:19 PM — G-14 marked “returned to storage.”
- The register does not list individual contents.
- No one signed a content check at return.', 7),
  ('LOG02', 'H', 2, 'Engraving Proof', 'Vendor proof sheet found in the awards folder', 'The approved proof sheet displays the correct event title but lists the wrong winning team in the small nameplate text. A handwritten note beside it says:

*“Check final plate before presentation.”*

The note is initialled “K.S.” The sheet does not show whether the error was corrected.', 8),
  ('LOG02', 'I', 2, 'Stage Volunteer Statement', 'Arjun''s interview', 'Arjun says he moved only the empty display stand to make room for the photographer. He says the trophy was already on the awards table when he moved the stand. The photo timestamp supports the fact that the trophy was on the table at 4:08, but does not independently confirm the exact time Arjun moved the stand.', 9),
  ('LOG02', 'J', 3, 'Awards Folder Contents', 'Inventory of Kavya''s signed awards-preparation folder', 'The folder contains:
- The temporary movement slip for the trophy.
- The engraving proof with the incorrect team name.
- A blank correction request form.
- A note reading: *“Do not announce until confirmed.”*

The correction request form has no vendor receipt or submission timestamp.', 10),
  ('LOG02', 'K', 3, 'Storage Area Inspection', 'Joint inspection report', 'Grey crate G-14 is found in the storage area behind rolled banners. The crate contains banner brackets and a padded compartment that can hold a trophy upright. The compartment is empty at inspection.

A strip of protective felt inside the compartment matches the felt used under the Founders'' Trophy base. This establishes that the crate was suitable for transporting the trophy, but does not prove the trophy was inside it at 4:11 PM.', 11),
  ('LOG02', 'L', 3, 'Revised Ceremony Draft', 'Schedule file history', 'At 4:17 PM, Kavya drafts a note stating:

*“Presentation may need a short delay while the award is checked.”*

At 4:23 PM, after the trophy is reported missing, the draft is changed to:

*“Presentation delayed due to missing trophy.”*

The file history records both edits. It does not show that the first draft was sent to anyone.', 12),
  ('LOG02', 'M', 3, 'Vendor Call Record', 'Event desk call log', 'At 4:12 PM, Kavya calls the engraving vendor. The call lasts 46 seconds. The desk log records the time and recipient, but not the conversation. Meera confirms that Kavya had been asking whether a replacement nameplate could be prepared quickly.

The call record supports a link between Kavya and the engraving issue; it does not, by itself, establish what she said or did with the trophy.', 13),
  ('LOG02', 'N', 3, 'Final Location Check', 'Search log completed by event staff', 'At 4:32 PM, staff check:
- The awards display and table.
- The photo bay.
- The stage wings.
- The AV booth.
- The storage area, including the space behind the rolled banners.

The trophy is not found. G-14 is located, but the padded compartment is empty. The search log does not include a search of the locked awards office, which is opened later by the event lead.', 14)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG02', 'Q1', 1, 1, '**What does the awards checklist actually establish?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q2', 1, 2, '**Which movement is the most useful lead to investigate first?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q3', 1, 3, '**What is the most important fact to establish next?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q4', 1, 4, '**What can investigators conclude from the temporary movement slip?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q5', 1, 5, '**Which statement best describes Naina''s role based on the evidence?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q6', 1, 6, '**Which lead most directly connects the missing trophy to a possible reason for concealing it?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q7', 1, 7, '**Which timeline is supported by the records?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q8', 1, 8, '**What is the strongest interpretation of the engraving evidence and schedule drafts?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q9', 1, 9, '**Which hypothesis best explains the combined evidence?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG02', 'Q1', 'A', 'The trophy was definitely on the stand at 4:25 PM.', 1),
  ('LOG02', 'Q1', 'B', 'The display was considered ready at 4:05 PM, but there is no close item verification after that time.', 2),
  ('LOG02', 'Q1', 'C', 'Sameer stole the trophy because he moved a crate.', 3),
  ('LOG02', 'Q1', 'D', 'The trophy could not have been moved because the checklist was signed.', 4),
  ('LOG02', 'Q2', 'A', 'Arjun''s movement of empty stage risers at 4:03 PM.', 1),
  ('LOG02', 'Q2', 'B', 'Sameer''s movement of the grey crate at 4:11 PM, because its contents and destination are not independently verified.', 2),
  ('LOG02', 'Q2', 'C', 'Naina''s photography, because cameras always reveal the entire room.', 3),
  ('LOG02', 'Q2', 'D', 'Vikram''s general note that the awards display looked ready.', 4),
  ('LOG02', 'Q3', 'A', 'Who dislikes the winning team.', 1),
  ('LOG02', 'Q3', 'B', 'Whether the trophy was moved for an approved activity, and what record should identify its destination.', 2),
  ('LOG02', 'Q3', 'C', 'Whether the stage risers were heavy.', 3),
  ('LOG02', 'Q3', 'D', 'Whether the closing ceremony can proceed without a trophy.
---
# Phase 2 — Following the Object
## Evidence E — Temporary Movement Slip
**Source:** Awards desk carbon-copy form
A movement slip was opened at 4:06 PM:
- Item: Founders'' Trophy
- Reason: “Photo setup”
- Destination field: “Photo Bay”
- Return confirmation: blank
- Initiated by: Kavya Sen
The form authorizes a temporary move for photography. It does not record that the trophy was returned to the display stand.
## Evidence F — Photographer''s Statement
**Source:** Naina''s recorded interview
Naina says:
*“I asked for the trophy to be brought to the awards table for a group photograph. I took the group shot at about 4:08. I saw the trophy on the table then. I did not take it away, and I did not ask anyone to store it.”*
Her camera''s timestamp confirms that the group photograph was taken at 4:08 PM. The photograph includes the trophy on the awards table, but the image does not show who carried it there.
## Evidence G — Storage Crate Register
**Source:** Logistics desk record
- 4:07 PM — Grey crate G-14 assigned to banner hardware.
- 4:11 PM — Sameer records G-14 as moved toward the storage area.
- 4:19 PM — G-14 marked “returned to storage.”
- The register does not list individual contents.
- No one signed a content check at return.
## Evidence H — Engraving Proof
**Source:** Vendor proof sheet found in the awards folder
The approved proof sheet displays the correct event title but lists the wrong winning team in the small nameplate text. A handwritten note beside it says:
*“Check final plate before presentation.”*
The note is initialled “K.S.” The sheet does not show whether the error was corrected.
## Evidence I — Stage Volunteer Statement
**Source:** Arjun''s interview
Arjun says he moved only the empty display stand to make room for the photographer. He says the trophy was already on the awards table when he moved the stand. The photo timestamp supports the fact that the trophy was on the table at 4:08, but does not independently confirm the exact time Arjun moved the stand.', 4),
  ('LOG02', 'Q4', 'A', 'The trophy was stolen by the photographer.', 1),
  ('LOG02', 'Q4', 'B', 'The trophy was authorized to leave the display for photography, but its return was never recorded.', 2),
  ('LOG02', 'Q4', 'C', 'Kavya definitely hid the trophy in the grey crate.', 3),
  ('LOG02', 'Q4', 'D', 'The movement slip is proof that the trophy was returned.', 4),
  ('LOG02', 'Q5', 'A', 'She had a legitimate reason to have the trophy at the awards table, but the photo alone does not show who later moved it.', 1),
  ('LOG02', 'Q5', 'B', 'She must have stolen it because she requested the photo setup.', 2),
  ('LOG02', 'Q5', 'C', 'She could not have seen the trophy because the checklist was signed earlier.', 3),
  ('LOG02', 'Q5', 'D', 'Her statement proves the trophy stayed on the table until 4:25 PM.', 4),
  ('LOG02', 'Q6', 'A', 'The empty stage risers.', 1),
  ('LOG02', 'Q6', 'B', 'The engraving proof with the wrong winning-team name and the handwritten instruction to check the final plate.', 2),
  ('LOG02', 'Q6', 'C', 'The general schedule reminder.', 3),
  ('LOG02', 'Q6', 'D', 'The fact that Naina took a photograph.
---
# Phase 3 — Chain of Custody
## Evidence J — Awards Folder Contents
**Source:** Inventory of Kavya''s signed awards-preparation folder
The folder contains:
- The temporary movement slip for the trophy.
- The engraving proof with the incorrect team name.
- A blank correction request form.
- A note reading: *“Do not announce until confirmed.”*
The correction request form has no vendor receipt or submission timestamp.
## Evidence K — Storage Area Inspection
**Source:** Joint inspection report
Grey crate G-14 is found in the storage area behind rolled banners. The crate contains banner brackets and a padded compartment that can hold a trophy upright. The compartment is empty at inspection.
A strip of protective felt inside the compartment matches the felt used under the Founders'' Trophy base. This establishes that the crate was suitable for transporting the trophy, but does not prove the trophy was inside it at 4:11 PM.
## Evidence L — Revised Ceremony Draft
**Source:** Schedule file history
At 4:17 PM, Kavya drafts a note stating:
*“Presentation may need a short delay while the award is checked.”*
At 4:23 PM, after the trophy is reported missing, the draft is changed to:
*“Presentation delayed due to missing trophy.”*
The file history records both edits. It does not show that the first draft was sent to anyone.
## Evidence M — Vendor Call Record
**Source:** Event desk call log
At 4:12 PM, Kavya calls the engraving vendor. The call lasts 46 seconds. The desk log records the time and recipient, but not the conversation. Meera confirms that Kavya had been asking whether a replacement nameplate could be prepared quickly.
The call record supports a link between Kavya and the engraving issue; it does not, by itself, establish what she said or did with the trophy.
## Evidence N — Final Location Check
**Source:** Search log completed by event staff
At 4:32 PM, staff check:
- The awards display and table.
- The photo bay.
- The stage wings.
- The AV booth.
- The storage area, including the space behind the rolled banners.
The trophy is not found. G-14 is located, but the padded compartment is empty. The search log does not include a search of the locked awards office, which is opened later by the event lead.', 4),
  ('LOG02', 'Q7', 'A', 'The trophy was on the display stand continuously from 3:40 PM until 4:25 PM.', 1),
  ('LOG02', 'Q7', 'B', 'The trophy was moved for photography by 4:08 PM; its return was not recorded, and a storage crate was moved at 4:11 PM.', 2),
  ('LOG02', 'Q7', 'C', 'The trophy was first moved after it was reported missing at 4:25 PM.', 3),
  ('LOG02', 'Q7', 'D', 'The trophy was inside G-14 at 4:32 PM.', 4),
  ('LOG02', 'Q8', 'A', 'They prove Meera stole the trophy.', 1),
  ('LOG02', 'Q8', 'B', 'They show a possible reason to delay the presentation and connect Kavya to the unresolved engraving problem, but they need to be combined with movement evidence.', 2),
  ('LOG02', 'Q8', 'C', 'They prove the trophy was never real.', 3),
  ('LOG02', 'Q8', 'D', 'They are irrelevant because the nameplate is small.', 4),
  ('LOG02', 'Q9', 'A', 'Naina took the trophy after the photograph and left the event.', 1),
  ('LOG02', 'Q9', 'B', 'Arjun hid the trophy while moving the empty stand.', 2),
  ('LOG02', 'Q9', 'C', 'Kavya used the authorized photo movement as an opportunity to divert the trophy, failed to record its return, and prepared to delay the presentation while the engraving error was addressed.', 3),
  ('LOG02', 'Q9', 'D', 'Sameer stole the trophy for its metal value.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG02', 'Q1', 1, 'Check the time of the last actual item verification.'),
  ('LOG02', 'Q1', 2, 'What does “display looks ready” mean?'),
  ('LOG02', 'Q1', 3, 'The checklist is not an item-by-item inspection after 4:05.'),
  ('LOG02', 'Q2', 1, 'Follow an object whose contents are not checked.'),
  ('LOG02', 'Q2', 2, 'Which movement record has both a destination and contents gap?'),
  ('LOG02', 'Q2', 3, 'Investigate the grey crate''s route and contents.'),
  ('LOG02', 'Q3', 1, 'Establish the last confirmed location before searching for a culprit.'),
  ('LOG02', 'Q3', 2, 'Look for an authorized movement record and its return field.'),
  ('LOG02', 'Q3', 3, 'The temporary movement slip is the first break in the chain of custody.'),
  ('LOG02', 'Q4', 1, 'Separate authorization from proof of return.'),
  ('LOG02', 'Q4', 2, 'The slip authorizes the photo movement.'),
  ('LOG02', 'Q4', 3, 'Its return confirmation is blank.'),
  ('LOG02', 'Q5', 1, 'What does the photograph show directly?'),
  ('LOG02', 'Q5', 2, 'It shows the trophy on the table at 4:08, not what happened afterward.'),
  ('LOG02', 'Q5', 3, 'Naina''s role in the photo does not prove later custody.'),
  ('LOG02', 'Q6', 1, 'Look for a problem that would make the ceremony difficult.'),
  ('LOG02', 'Q6', 2, 'Inspect the engraving proof.'),
  ('LOG02', 'Q6', 3, 'The wrong team name could explain pressure to delay the presentation.'),
  ('LOG02', 'Q7', 1, 'Put the photo, crate movement and missing report in order.'),
  ('LOG02', 'Q7', 2, 'The trophy was on the table at 4:08; the crate moved at 4:11.'),
  ('LOG02', 'Q7', 3, 'The record supports an unrecorded return/diversion window, not continuous presence on the stand.'),
  ('LOG02', 'Q8', 1, 'Motive and opportunity are separate.'),
  ('LOG02', 'Q8', 2, 'The paperwork links Kavya to the engraving issue and a planned delay.'),
  ('LOG02', 'Q8', 3, 'Combine this with the movement records; do not treat motive as proof by itself.'),
  ('LOG02', 'Q9', 1, 'Compare which theory explains both the custody gap and the timing of the draft.'),
  ('LOG02', 'Q9', 2, 'Consider the person who handled the authorized movement and knew about the engraving problem.'),
  ('LOG02', 'Q9', 3, 'The strongest theory is a diversion during the unrecorded return period to delay the presentation.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG02', 35, 'kavya_sen', 20, 'B', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG02', 'kavya_sen', 1),
  ('LOG02', 'arjun_rao', 2),
  ('LOG02', 'naina_rao', 3),
  ('LOG02', 'sameer_khan', 4),
  ('LOG02', 'meera_iyer', 5),
  ('LOG02', 'vikram_sethi', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG02', 'A', 'The trophy was taken by a photographer after the group photo and carried out of the venue.', 1),
  ('LOG02', 'B', 'The trophy was diverted after being legitimately moved for photography; the unresolved engraving error gave the awards coordinator a reason to delay the presentation, and the return was not recorded.', 2),
  ('LOG02', 'C', 'The trophy was never delivered to the event.', 3),
  ('LOG02', 'D', 'The trophy was destroyed while the display stand was being moved.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG02', 'chain_of_custody', 'pending', 'Movement sequence needs final review.'),
  ('LOG02', 'physical_link_to_diversion', 'fail', 'Current authored case lacks an independent clue proving Kavya physically diverted the trophy.'),
  ('LOG02', 'exact_trophy_location', 'fail', 'Current player evidence does not establish recovery/location.'),
  ('LOG02', 'scoring_reconciliation', 'fail', '5-point task ladder conflicts with the platform-wide 10/8/6/4/2 ladder.'),
  ('LOG02', 'hint_content', 'fail', 'Only three hints are authored per task while the legacy scoring text describes a five-level ladder.'),
  ('LOG02', 'playtest', 'pending', 'No first-time solo playtest documented.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

-- commit omitted for combined transaction


-- Seed data for LOG03 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
-- begin omitted for combined transaction
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG03', 'The Silent Call', 'LOGIC', '1.0.0', 2, 'content_final_pending_platform_qa_and_live_playtest', 'distinguish_call_attempts_from_connected_calls_and_authorized_instructions', 100, '{"investigation_max_each":10,"hint_rewards":[10,8,6,4,2],"investigation_task_count":6,"final_person_points":25,"final_explanation_points":15,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Content allocation matches the platform standard."}'::jsonb, '{"case_id":"LOG03","title":"The Silent Call","track":"LOGIC","team_size":2,"content_version":"1.0.0","status":"content_final_pending_platform_QA_and_live_playtest","core_mechanism":"distinguish_call_attempts_from_connected_calls_and_authorized_instructions","player_asset":"LOG03_Player_Case.md","restricted_assets":["LOG03_Case_Manifest.json","LOG03_Author_Notes.md","LOG03_Scoring_and_Hints.md","LOG03_Validation_Checklist.md"],"phases":[{"phase":1,"name":"The Claim","evidence_ids":["A","B","C","D"],"task_ids":["T1","T2"]},{"phase":2,"name":"Two Sides of the Call","evidence_ids":["E","F","G","H"],"task_ids":["T3","T4"]},{"phase":3,"name":"The Missing Confirmation","evidence_ids":["I","J","K","L"],"task_ids":["T5","T6"]}],"characters":[{"id":"ananya_rao","name":"Ananya Rao","role":"Faculty supervisor"},{"id":"karthik_menon","name":"Karthik Menon","role":"Stage coordinator"},{"id":"sana_ali","name":"Sana Ali","role":"Control-desk volunteer"},{"id":"dev_malhotra","name":"Dev Malhotra","role":"Pulse team leader"},{"id":"ritesh_shah","name":"Ritesh Shah","role":"AV technician"},{"id":"meera_joshi","name":"Meera Joshi","role":"Faculty office assistant"}],"tasks":[{"task_id":"T1","phase":1,"player_heading":"Investigation Task 1","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T2","phase":1,"player_heading":"Investigation Task 2","correct_option":"A","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T3","phase":2,"player_heading":"Investigation Task 3","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T4","phase":2,"player_heading":"Investigation Task 4","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T5","phase":3,"player_heading":"Investigation Task 5","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T6","phase":3,"player_heading":"Investigation Task 6","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2}],"final_deduction":{"responsible_person_field":"responsible_person_id","responsible_person":"karthik_menon","responsible_person_points":25,"explanation_field":"explanation_option","explanation_option":"B","explanation_points":15,"wrong_answer_penalty":2,"components_graded_independently":true,"correct_person_id":"karthik_menon","correct_explanation":"B","person_points_proposed":25,"explanation_points_proposed":15},"scoring":{"ordinary_tasks_max":60,"final_deduction_max":40,"base_total":100,"hint_rewards_by_hints_used":{"0":10,"1":8,"2":6,"3":4,"4":2},"wrong_committed_answer_penalty":-2,"score_floor":0,"retry_allowed":true,"award_success_once":true,"server_authoritative":true},"author_only":{"ground_truth":"Karthik knowingly presented an unverified request to hold Pulse as a confirmed faculty cancellation after a schedule dispute.","unknown_fact":"The identity of the 4:10 caller is not established and is not required for the solution.","evidence_logic":"The genuine cable concern explains the temporary hold request; independent call logs contradict the claimed connected confirmation; the published announcement and authenticated private note support knowing misrepresentation.","do_not_grade":["identity of the 4:10 caller","free-text theories","client-side timestamps"]},"release_gates":{"content_review":"complete_in_this_pack","json_parse_and_schema_validation":"required_before_seed","server_side_answer_key_and_phase_access_test":"required_before_seed","two_player_shared_state_test":"required_before_seed","first_time_duo_playtests":"required_before_live_event","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG03', 1, 'The Claim'),
  ('LOG03', 2, 'Two Sides of the Call'),
  ('LOG03', 3, 'The Missing Confirmation')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG03', 'ananya_rao', 'Ananya Rao', 'Faculty supervisor', 1),
  ('LOG03', 'karthik_menon', 'Karthik Menon', 'Stage coordinator', 2),
  ('LOG03', 'sana_ali', 'Sana Ali', 'Control-desk volunteer', 3),
  ('LOG03', 'dev_malhotra', 'Dev Malhotra', 'Pulse team leader', 4),
  ('LOG03', 'ritesh_shah', 'Ritesh Shah', 'AV technician', 5),
  ('LOG03', 'meera_joshi', 'Meera Joshi', 'Faculty office assistant', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG03', 'A', 1, 'Stage Running Sheet', 'Stage coordinator''s event sheet', '- 3:50 PM — Pulse demonstration confirmed for 4:30 PM.
- 4:05 PM — Ritesh reports a loose power cable near the stage.
- 4:09 PM — Ritesh marks the cable secured after inspection.
- 4:12 PM — Karthik writes: “Faculty cancelled Pulse — electrical concern.”
- 4:13 PM — Pulse is removed from the running order.
- 4:35 PM — Ananya arrives and disputes the cancellation.

The sheet does not identify who gave Karthik the cancellation instruction.', 1),
  ('LOG03', 'B', 1, 'Control Desk Call Log', 'Event control desk phone', '| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Outgoing call to faculty office | 00:00 | No answer |
| 4:10 PM | Incoming call, caller ID withheld | 00:18 | Answered by Sana |
| 4:11 PM | Outgoing call to Karthik | 00:00 | No answer |
| 4:14 PM | Incoming call from faculty office | 00:00 | Missed |

The desk system records call duration. A duration of `00:00` means the call did not connect in this system. It does not reveal what a caller intended to say.', 2),
  ('LOG03', 'C', 1, 'Karthik''s Statement', 'Initial interview', 'Karthik says:

*“At about 4:11, the faculty office called me and confirmed the cancellation. I wrote it down immediately. I wouldn''t stop a team''s demonstration without approval.”*

He says he did not speak to Sana before making the announcement.', 3),
  ('LOG03', 'D', 1, 'Safety Check', 'Ritesh''s signed equipment checklist', '- 4:05 PM — Loose cable reported.
- 4:09 PM — Cable secured and tested.
- 4:10 PM — Stage power checked; no continuing fault recorded.
- 4:30 PM — Pulse demonstration remains listed as safe to proceed, pending normal start checks.', 4),
  ('LOG03', 'E', 2, 'Faculty Office Phone Log', 'Faculty office landline system', '| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Incoming call from control desk | 00:00 | Missed |
| 4:10 PM | No incoming or outgoing call recorded | — | — |
| 4:11 PM | No outgoing call to Karthik recorded | — | — |
| 4:14 PM | Outgoing call to control desk | 00:00 | No answer |

The faculty office system and control desk system both show no connected call between the faculty office and Karthik before the cancellation was announced.', 5),
  ('LOG03', 'F', 2, 'Sana''s Clarification', 'Follow-up interview', 'Sana says the 4:10 call lasted about eighteen seconds. The caller said:

*“There may be an electrical problem. Please hold the Pulse slot until it is checked.”*

Sana did not hear the caller''s name. The caller did **not** say that the faculty supervisor had cancelled the demonstration.

Sana says she attempted to call Karthik back at 4:11, but he did not answer. The control desk log shows this outgoing call lasted `00:00`.', 6),
  ('LOG03', 'G', 2, 'Message Draft', 'Karthik''s event messaging app, inspected with permission', 'At 4:12 PM, Karthik drafts the following announcement:

*“As confirmed by the faculty supervisor, Pulse is cancelled due to an electrical safety concern.”*

The draft is posted to the stage team''s internal channel at 4:13 PM. The app records the draft and posting times. It does not show that the faculty supervisor approved the wording. The draft was created after the 4:10 call and before the 4:13 post; the time alone does not establish what Karthik believed.', 7),
  ('LOG03', 'H', 2, 'Dev''s Call History', 'Dev''s phone, shown during interview', '- 4:06 PM — Outgoing call to the control desk, connected for 24 seconds.
- 4:10 PM — No call to the faculty office.
- 4:15 PM — Message to a teammate: “They''ve paused us. Nobody has told us why yet.”

Dev says he called to confirm that Pulse was still scheduled. He says the person who answered told him the slot was still listed, but that a safety check was underway.', 8),
  ('LOG03', 'I', 3, 'Control Desk Procedure Card', 'Printed procedure beside the event phone', 'For safety-related changes:
1. Record the caller''s name and role.
2. If the caller claims faculty authorization, call the faculty office back using the number on the approved contact sheet.
3. Do not change the running order until authorization is confirmed.
4. A request to “hold” a slot is not the same as a cancellation.

Sana''s incident note at 4:10 says only: *“Caller unidentified — possible electrical issue — verify.”*', 9),
  ('LOG03', 'J', 3, 'Approved Contact Sheet', 'Event control desk folder', 'The faculty office''s approved callback number ends in **204**. The control desk log''s 4:07 outgoing call was made to that number and did not connect. No connected callback to that number appears before 4:13.

Karthik''s phone history shows no incoming call from the faculty office between 4:00 and 4:15.', 10),
  ('LOG03', 'K', 3, 'Karthik''s Private Note', 'Paper running sheet recovered from the stage desk', 'Beside the 4:12 cancellation entry, Karthik wrote:

*“Need a reason to move Pulse after slot dispute. Safety concern is enough if marked faculty-approved.”*

The handwriting is identified as Karthik''s by the event lead. Karthik says he wrote the note as a reminder to verify the instruction, but the note does not say “verify” or “pending.”', 11),
  ('LOG03', 'L', 3, 'Final Timeline', 'Combined timeline prepared by the event lead', '- 4:05 — Ritesh reports a loose cable.
- 4:09 — Cable is secured and tested.
- 4:10 — Unidentified caller asks the control desk to hold Pulse pending a check.
- 4:11 — Sana''s attempted call to Karthik does not connect.
- 4:12 — Karthik records “faculty cancelled” and drafts the announcement.
- 4:13 — The announcement is posted.
- 4:14 — The faculty office''s return call to the control desk is missed.
- 4:35 — Ananya says she never cancelled Pulse.

The records show that the safety concern was real, but they do not show a connected call in which the faculty office cancelled the demonstration.', 12)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG03', 'T1', 1, 1, '**What does the phone log establish about the alleged 4:11 PM confirmation from the faculty office to Karthik?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T2', 1, 2, '**Which conclusion is best supported by the safety checklist?**', 'single_choice', 10, 'A', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T3', 1, 3, '**What did the 4:10 incoming call to the control desk actually communicate, according to Sana?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T4', 1, 4, '**Which statement about the call records is correct?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T5', 1, 5, '**Which rule was most clearly violated?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T6', 1, 6, '**What does Karthik''s private note add to the case?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG03', 'T1', 'A', 'The call definitely happened and the cancellation was confirmed.', 1),
  ('LOG03', 'T1', 'B', 'The listed 4:11 PM call was an outgoing call from the control desk to Karthik that did not connect; it does not support Karthik''s claim of a connected faculty-office call at that time.', 2),
  ('LOG03', 'T1', 'C', 'The faculty supervisor never made any call that day.', 3),
  ('LOG03', 'T1', 'D', 'The caller at 4:10 was definitely Ananya.', 4),
  ('LOG03', 'T2', 'A', 'There was a real cable concern, but it was marked fixed before the cancellation was recorded.', 1),
  ('LOG03', 'T2', 'B', 'The stage was dangerous throughout the afternoon.', 2),
  ('LOG03', 'T2', 'C', 'Ritesh must have invented the fault.', 3),
  ('LOG03', 'T2', 'D', 'The faculty supervisor cancelled Pulse because of the cable.
---
# Phase 2 — Two Sides of the Call
## Evidence E — Faculty Office Phone Log
**Source:** Faculty office landline system
| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Incoming call from control desk | 00:00 | Missed |
| 4:10 PM | No incoming or outgoing call recorded | — | — |
| 4:11 PM | No outgoing call to Karthik recorded | — | — |
| 4:14 PM | Outgoing call to control desk | 00:00 | No answer |
The faculty office system and control desk system both show no connected call between the faculty office and Karthik before the cancellation was announced.
## Evidence F — Sana''s Clarification
**Source:** Follow-up interview
Sana says the 4:10 call lasted about eighteen seconds. The caller said:
*“There may be an electrical problem. Please hold the Pulse slot until it is checked.”*
Sana did not hear the caller''s name. The caller did **not** say that the faculty supervisor had cancelled the demonstration.
Sana says she attempted to call Karthik back at 4:11, but he did not answer. The control desk log shows this outgoing call lasted `00:00`.
## Evidence G — Message Draft
**Source:** Karthik''s event messaging app, inspected with permission
At 4:12 PM, Karthik drafts the following announcement:
*“As confirmed by the faculty supervisor, Pulse is cancelled due to an electrical safety concern.”*
The draft is posted to the stage team''s internal channel at 4:13 PM. The app records the draft and posting times. It does not show that the faculty supervisor approved the wording. The draft was created after the 4:10 call and before the 4:13 post; the time alone does not establish what Karthik believed.
## Evidence H — Dev''s Call History
**Source:** Dev''s phone, shown during interview
- 4:06 PM — Outgoing call to the control desk, connected for 24 seconds.
- 4:10 PM — No call to the faculty office.
- 4:15 PM — Message to a teammate: “They''ve paused us. Nobody has told us why yet.”
Dev says he called to confirm that Pulse was still scheduled. He says the person who answered told him the slot was still listed, but that a safety check was underway.', 4),
  ('LOG03', 'T3', 'A', 'The faculty supervisor had formally cancelled Pulse.', 1),
  ('LOG03', 'T3', 'B', 'There might be an electrical problem and the slot should be held until checked; the caller did not identify themselves or claim faculty authorization.', 2),
  ('LOG03', 'T3', 'C', 'Dev demanded that Pulse be cancelled.', 3),
  ('LOG03', 'T3', 'D', 'The caller confirmed that the cable was still dangerous.', 4),
  ('LOG03', 'T4', 'A', 'A call appearing in a log always means the people spoke.', 1),
  ('LOG03', 'T4', 'B', 'The two phone systems show no connected faculty-office call to Karthik before the cancellation announcement.', 2),
  ('LOG03', 'T4', 'C', 'The logs prove Ananya never used a phone that day.', 3),
  ('LOG03', 'T4', 'D', 'The 4:14 missed call proves the faculty office approved the cancellation.
---
# Phase 3 — The Missing Confirmation
## Evidence I — Control Desk Procedure Card
**Source:** Printed procedure beside the event phone
For safety-related changes:
1. Record the caller''s name and role.
2. If the caller claims faculty authorization, call the faculty office back using the number on the approved contact sheet.
3. Do not change the running order until authorization is confirmed.
4. A request to “hold” a slot is not the same as a cancellation.
Sana''s incident note at 4:10 says only: *“Caller unidentified — possible electrical issue — verify.”*
## Evidence J — Approved Contact Sheet
**Source:** Event control desk folder
The faculty office''s approved callback number ends in **204**. The control desk log''s 4:07 outgoing call was made to that number and did not connect. No connected callback to that number appears before 4:13.
Karthik''s phone history shows no incoming call from the faculty office between 4:00 and 4:15.
## Evidence K — Karthik''s Private Note
**Source:** Paper running sheet recovered from the stage desk
Beside the 4:12 cancellation entry, Karthik wrote:
*“Need a reason to move Pulse after slot dispute. Safety concern is enough if marked faculty-approved.”*
The handwriting is identified as Karthik''s by the event lead. Karthik says he wrote the note as a reminder to verify the instruction, but the note does not say “verify” or “pending.”
## Evidence L — Final Timeline
**Source:** Combined timeline prepared by the event lead
- 4:05 — Ritesh reports a loose cable.
- 4:09 — Cable is secured and tested.
- 4:10 — Unidentified caller asks the control desk to hold Pulse pending a check.
- 4:11 — Sana''s attempted call to Karthik does not connect.
- 4:12 — Karthik records “faculty cancelled” and drafts the announcement.
- 4:13 — The announcement is posted.
- 4:14 — The faculty office''s return call to the control desk is missed.
- 4:35 — Ananya says she never cancelled Pulse.
The records show that the safety concern was real, but they do not show a connected call in which the faculty office cancelled the demonstration.', 4),
  ('LOG03', 'T5', 'A', 'A safety concern must never be reported.', 1),
  ('LOG03', 'T5', 'B', 'A request to hold a slot is not a cancellation, and claimed faculty authorization must be verified before changing the running order.', 2),
  ('LOG03', 'T5', 'C', 'Photographs must be taken before every demonstration.', 3),
  ('LOG03', 'T5', 'D', 'Only students can call the control desk.', 4),
  ('LOG03', 'T6', 'A', 'It proves the cable was never loose.', 1),
  ('LOG03', 'T6', 'B', 'It gives evidence that Karthik had a schedule-related motive and knowingly treated an unconfirmed concern as faculty-approved.', 2),
  ('LOG03', 'T6', 'C', 'It proves Dev placed the 4:10 call.', 3),
  ('LOG03', 'T6', 'D', 'It proves Ananya secretly cancelled Pulse.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG03', 'T1', 1, 'Read the direction column, not just the time.'),
  ('LOG03', 'T1', 2, 'Compare the 4:11 entry with Karthik''s claim.'),
  ('LOG03', 'T1', 3, 'An outgoing control-desk call is not a call from the faculty office.'),
  ('LOG03', 'T1', 4, 'The 4:11 call did not connect, so it cannot be the claimed confirmation.'),
  ('LOG03', 'T2', 1, 'Compare the time the cable was reported with the time it was checked.'),
  ('LOG03', 'T2', 2, 'Read the status recorded at 4:09 and 4:10.'),
  ('LOG03', 'T2', 3, 'The checklist says the cable was secured and tested before the cancellation entry.'),
  ('LOG03', 'T2', 4, 'The genuine earlier concern explains why someone might request a hold; it does not prove faculty cancellation.'),
  ('LOG03', 'T3', 1, 'Use Sana''s account of the words spoken, not Karthik''s later wording.'),
  ('LOG03', 'T3', 2, 'Notice the difference between “hold” and “cancel.”'),
  ('LOG03', 'T3', 3, 'The caller did not identify themselves or claim faculty authority.'),
  ('LOG03', 'T3', 4, 'The call requested a temporary hold pending a check, not a formal cancellation.'),
  ('LOG03', 'T4', 1, 'Check both phone systems.'),
  ('LOG03', 'T4', 2, 'A missed or zero-duration call is not proof that a conversation took place.'),
  ('LOG03', 'T4', 3, 'Neither system records a connected faculty-office call to Karthik before the announcement.'),
  ('LOG03', 'T4', 4, 'The claimed confirmation is unsupported by the independent logs.'),
  ('LOG03', 'T5', 1, 'Read all four steps on the procedure card.'),
  ('LOG03', 'T5', 2, 'A safety report is not the same as authorization to change the running order.'),
  ('LOG03', 'T5', 3, 'The policy requires verification and explicitly distinguishes a hold from a cancellation.'),
  ('LOG03', 'T5', 4, 'The rule against changing the running order before confirmed authorization was violated.'),
  ('LOG03', 'T6', 1, 'Consider the note''s wording and where it appears on the running sheet.'),
  ('LOG03', 'T6', 2, 'The note links moving Pulse to a schedule dispute.'),
  ('LOG03', 'T6', 3, 'It says the safety concern is enough if marked faculty-approved.'),
  ('LOG03', 'T6', 4, 'Together with the unsupported announcement, the note supports knowing misrepresentation rather than a simple misunderstanding.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG03', 25, 'karthik_menon', 15, 'B', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG03', 'ananya_rao', 1),
  ('LOG03', 'karthik_menon', 2),
  ('LOG03', 'sana_ali', 3),
  ('LOG03', 'dev_malhotra', 4),
  ('LOG03', 'ritesh_shah', 5),
  ('LOG03', 'meera_joshi', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG03', 'A', 'The faculty office connected to Karthik and officially cancelled Pulse.', 1),
  ('LOG03', 'B', 'A real but already addressed cable concern prompted an unidentified caller to request a temporary hold; Karthik turned that unconfirmed request into a false claim of faculty cancellation.', 2),
  ('LOG03', 'C', 'Dev cancelled his own team''s demonstration to gain attention.', 3),
  ('LOG03', 'D', 'There was never any cable concern, and all safety records were fabricated.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG03', 'content_review', 'pass', 'Narrative pack states content review complete.'),
  ('LOG03', 'call_log_consistency', 'pending', 'Recheck the direction/duration consistency across both phone systems.'),
  ('LOG03', 'answer_key_security', 'pending', 'Confirm no client route exposes answer-key fields.'),
  ('LOG03', 'two_player_shared_state', 'pending', 'Test two clients using the same team session.'),
  ('LOG03', 'duo_playtest', 'pending', 'Run first-time duo playtests before event use.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

-- commit omitted for combined transaction

