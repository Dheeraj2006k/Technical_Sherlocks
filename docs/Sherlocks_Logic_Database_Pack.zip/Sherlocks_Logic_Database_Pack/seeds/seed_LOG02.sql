-- Seed data for LOG02 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
begin;
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG02', 'The Vanishing Trophy', 'LOGIC', '0.1', 1, 'draft_not_seed_ready', 'chain_of_custody_and_object_movement', 100, '{"investigation_max_each":5,"hint_rewards":[5,4,3,2,1],"investigation_task_count":9,"final_person_points":35,"final_explanation_points":20,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Legacy authored allocation conflicts with platform standard 10/8/6/4/2 ladder; do not activate until score model is reconciled."}'::jsonb, '{"case_id":"LOG02","title":"The Vanishing Trophy","track":"LOGIC","version":"0.1","status":"prototype_not_seed_ready","core_mechanism":"chain_of_custody_and_object_movement","phases":[{"phase":1,"name":"Discovery","evidence_ids":["A","B","C","D"],"task_ids":["Q1","Q2","Q3"]},{"phase":2,"name":"Following the Object","evidence_ids":["E","F","G","H","I"],"task_ids":["Q4","Q5","Q6"]},{"phase":3,"name":"Chain of Custody","evidence_ids":["J","K","L","M","N"],"task_ids":["Q7","Q8","Q9"]}],"characters":[{"id":"kavya_sen","name":"Kavya Sen","role":"Awards coordinator"},{"id":"arjun_rao","name":"Arjun Rao","role":"Stage volunteer"},{"id":"naina_rao","name":"Naina Rao","role":"Event photographer"},{"id":"sameer_khan","name":"Sameer Khan","role":"Logistics volunteer"},{"id":"meera_iyer","name":"Meera Iyer","role":"Engraving liaison"},{"id":"vikram_sethi","name":"Vikram Sethi","role":"Showcase coordinator"}],"tasks":[{"task_id":"Q1","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q2","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q3","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q4","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q5","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q6","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q7","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q8","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q9","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"}],"final_deduction":{"person_points_proposed":35,"correct_person_id":"kavya_sen","explanation_points_proposed":20,"correct_explanation":"B"},"scoring_proposed":{"ordinary_question_points":5,"hint_ladder":[5,4,3,2,1],"wrong_committed_answer_penalty":-2,"total_base_points":100,"status":"requires_reconciliation_with_global_scoring_rules"},"author_only":{"ground_truth":"Kavya diverted the Founders'' Trophy after the authorized photo movement, failed to record its return, and sought to delay the presentation while an incorrect engraving was addressed.","twists":["The initial theft framing is incomplete: the trophy was moved for an authorized photo.","The return field on the movement slip is blank.","The grey crate is a plausible lead, but its recorded contents are unverified.","The engraving error and early schedule draft explain the pressure to delay the presentation."]},"validation_status":{"chain_of_custody":"needs_closure","physical_link_to_diversion":"gap_to_resolve","exact_trophy_location":"not_established_in_player_evidence","timeline_consistency":"needs_review","deterministic_task_review":"needed","playtest":"not_done","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG02', 1, 'Discovery'),
  ('LOG02', 2, 'Following the Object'),
  ('LOG02', 3, 'Chain of Custody')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG02', 'kavya_sen', 'Kavya Sen', 'Awards coordinator', 1),
  ('LOG02', 'arjun_rao', 'Arjun Rao', 'Stage volunteer', 2),
  ('LOG02', 'naina_rao', 'Naina Rao', 'Event photographer', 3),
  ('LOG02', 'sameer_khan', 'Sameer Khan', 'Logistics volunteer', 4),
  ('LOG02', 'meera_iyer', 'Meera Iyer', 'Engraving liaison', 5),
  ('LOG02', 'vikram_sethi', 'Vikram Sethi', 'Showcase coordinator', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG02', 'A', 1, 'Awards Display Checklist', 'Signed awards checklist', '- 3:40 PM — Trophy placed on the display stand.
- 3:55 PM — Display area opened for official photographs.
- 4:05 PM — Vikram notes: “Awards display looks ready.”
- 4:25 PM — Missing trophy reported.
- The checklist has no item-by-item verification between 4:05 PM and 4:25 PM.

The checklist confirms that the display was considered ready at 4:05 PM. It does not record a close inspection of the trophy after that time.', 1),
  ('LOG02', 'B', 1, 'Photograph Contact Sheet', 'Naina''s event photo log', '- Photo 12, 3:52 PM — Trophy on the display stand.
- Photo 19, 4:09 PM — Empty display stand visible in the background; the trophy is not in frame elsewhere.
- Photo 21, 4:16 PM — Awards table partly obscured by a grey equipment crate and rolled banners.

The contact sheet records what was captured, not everything happening outside the camera frame.', 2),
  ('LOG02', 'C', 1, 'Movement Notes', 'Volunteer movement sheet', '- Arjun moved two empty stage risers at 4:03 PM.
- Sameer moved a grey crate from the awards corridor toward the storage area at 4:11 PM.
- Naina requested a short photo setup near the awards table.
- Kavya signed out an awards-preparation folder at 4:00 PM.
- No entry records the trophy''s destination after it left the display stand.', 3),
  ('LOG02', 'D', 1, 'Ceremony Schedule', 'Final event schedule', 'The trophy presentation is scheduled for 5:00 PM. At 4:10 PM, the stage manager sends a reminder:

*“Please confirm the trophy and certificates are ready. No changes to the running order after 4:30 without approval.”*', 4),
  ('LOG02', 'E', 2, 'Temporary Movement Slip', 'Awards desk carbon-copy form', 'A movement slip was opened at 4:06 PM:

- Item: Founders'' Trophy
- Reason: “Photo setup”
- Destination field: “Photo Bay”
- Return confirmation: blank
- Initiated by: Kavya Sen

The form authorizes a temporary move for photography. It does not record that the trophy was returned to the display stand.', 5),
  ('LOG02', 'F', 2, 'Photographer''s Statement', 'Naina''s recorded interview', 'Naina says:

*“I asked for the trophy to be brought to the awards table for a group photograph. I took the group shot at about 4:08. I saw the trophy on the table then. I did not take it away, and I did not ask anyone to store it.”*

Her camera''s timestamp confirms that the group photograph was taken at 4:08 PM. The photograph includes the trophy on the awards table, but the image does not show who carried it there.', 6),
  ('LOG02', 'G', 2, 'Storage Crate Register', 'Logistics desk record', '- 4:07 PM — Grey crate G-14 assigned to banner hardware.
- 4:11 PM — Sameer records G-14 as moved toward the storage area.
- 4:19 PM — G-14 marked “returned to storage.”
- The register does not list individual contents.
- No one signed a content check at return.', 7),
  ('LOG02', 'H', 2, 'Engraving Proof', 'Vendor proof sheet found in the awards folder', 'The approved proof sheet displays the correct event title but lists the wrong winning team in the small nameplate text. A handwritten note beside it says:

*“Check final plate before presentation.”*

The note is initialled “K.S.” The sheet does not show whether the error was corrected.', 8),
  ('LOG02', 'I', 2, 'Stage Volunteer Statement', 'Arjun''s interview', 'Arjun says he moved only the empty display stand to make room for the photographer. He says the trophy was already on the awards table when he moved the stand. The photo timestamp supports the fact that the trophy was on the table at 4:08, but does not independently confirm the exact time Arjun moved the stand.', 9),
  ('LOG02', 'J', 3, 'Awards Folder Contents', 'Inventory of Kavya''s signed awards-preparation folder', 'The folder contains:
- The temporary movement slip for the trophy.
- The engraving proof with the incorrect team name.
- A blank correction request form.
- A note reading: *“Do not announce until confirmed.”*

The correction request form has no vendor receipt or submission timestamp.', 10),
  ('LOG02', 'K', 3, 'Storage Area Inspection', 'Joint inspection report', 'Grey crate G-14 is found in the storage area behind rolled banners. The crate contains banner brackets and a padded compartment that can hold a trophy upright. The compartment is empty at inspection.

A strip of protective felt inside the compartment matches the felt used under the Founders'' Trophy base. This establishes that the crate was suitable for transporting the trophy, but does not prove the trophy was inside it at 4:11 PM.', 11),
  ('LOG02', 'L', 3, 'Revised Ceremony Draft', 'Schedule file history', 'At 4:17 PM, Kavya drafts a note stating:

*“Presentation may need a short delay while the award is checked.”*

At 4:23 PM, after the trophy is reported missing, the draft is changed to:

*“Presentation delayed due to missing trophy.”*

The file history records both edits. It does not show that the first draft was sent to anyone.', 12),
  ('LOG02', 'M', 3, 'Vendor Call Record', 'Event desk call log', 'At 4:12 PM, Kavya calls the engraving vendor. The call lasts 46 seconds. The desk log records the time and recipient, but not the conversation. Meera confirms that Kavya had been asking whether a replacement nameplate could be prepared quickly.

The call record supports a link between Kavya and the engraving issue; it does not, by itself, establish what she said or did with the trophy.', 13),
  ('LOG02', 'N', 3, 'Final Location Check', 'Search log completed by event staff', 'At 4:32 PM, staff check:
- The awards display and table.
- The photo bay.
- The stage wings.
- The AV booth.
- The storage area, including the space behind the rolled banners.

The trophy is not found. G-14 is located, but the padded compartment is empty. The search log does not include a search of the locked awards office, which is opened later by the event lead.', 14)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG02', 'Q1', 1, 1, '**What does the awards checklist actually establish?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q2', 1, 2, '**Which movement is the most useful lead to investigate first?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q3', 1, 3, '**What is the most important fact to establish next?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q4', 1, 4, '**What can investigators conclude from the temporary movement slip?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q5', 1, 5, '**Which statement best describes Naina''s role based on the evidence?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q6', 1, 6, '**Which lead most directly connects the missing trophy to a possible reason for concealing it?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q7', 1, 7, '**Which timeline is supported by the records?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q8', 1, 8, '**What is the strongest interpretation of the engraving evidence and schedule drafts?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG02', 'Q9', 1, 9, '**Which hypothesis best explains the combined evidence?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG02', 'Q1', 'A', 'The trophy was definitely on the stand at 4:25 PM.', 1),
  ('LOG02', 'Q1', 'B', 'The display was considered ready at 4:05 PM, but there is no close item verification after that time.', 2),
  ('LOG02', 'Q1', 'C', 'Sameer stole the trophy because he moved a crate.', 3),
  ('LOG02', 'Q1', 'D', 'The trophy could not have been moved because the checklist was signed.', 4),
  ('LOG02', 'Q2', 'A', 'Arjun''s movement of empty stage risers at 4:03 PM.', 1),
  ('LOG02', 'Q2', 'B', 'Sameer''s movement of the grey crate at 4:11 PM, because its contents and destination are not independently verified.', 2),
  ('LOG02', 'Q2', 'C', 'Naina''s photography, because cameras always reveal the entire room.', 3),
  ('LOG02', 'Q2', 'D', 'Vikram''s general note that the awards display looked ready.', 4),
  ('LOG02', 'Q3', 'A', 'Who dislikes the winning team.', 1),
  ('LOG02', 'Q3', 'B', 'Whether the trophy was moved for an approved activity, and what record should identify its destination.', 2),
  ('LOG02', 'Q3', 'C', 'Whether the stage risers were heavy.', 3),
  ('LOG02', 'Q3', 'D', 'Whether the closing ceremony can proceed without a trophy.
---
# Phase 2 — Following the Object
## Evidence E — Temporary Movement Slip
**Source:** Awards desk carbon-copy form
A movement slip was opened at 4:06 PM:
- Item: Founders'' Trophy
- Reason: “Photo setup”
- Destination field: “Photo Bay”
- Return confirmation: blank
- Initiated by: Kavya Sen
The form authorizes a temporary move for photography. It does not record that the trophy was returned to the display stand.
## Evidence F — Photographer''s Statement
**Source:** Naina''s recorded interview
Naina says:
*“I asked for the trophy to be brought to the awards table for a group photograph. I took the group shot at about 4:08. I saw the trophy on the table then. I did not take it away, and I did not ask anyone to store it.”*
Her camera''s timestamp confirms that the group photograph was taken at 4:08 PM. The photograph includes the trophy on the awards table, but the image does not show who carried it there.
## Evidence G — Storage Crate Register
**Source:** Logistics desk record
- 4:07 PM — Grey crate G-14 assigned to banner hardware.
- 4:11 PM — Sameer records G-14 as moved toward the storage area.
- 4:19 PM — G-14 marked “returned to storage.”
- The register does not list individual contents.
- No one signed a content check at return.
## Evidence H — Engraving Proof
**Source:** Vendor proof sheet found in the awards folder
The approved proof sheet displays the correct event title but lists the wrong winning team in the small nameplate text. A handwritten note beside it says:
*“Check final plate before presentation.”*
The note is initialled “K.S.” The sheet does not show whether the error was corrected.
## Evidence I — Stage Volunteer Statement
**Source:** Arjun''s interview
Arjun says he moved only the empty display stand to make room for the photographer. He says the trophy was already on the awards table when he moved the stand. The photo timestamp supports the fact that the trophy was on the table at 4:08, but does not independently confirm the exact time Arjun moved the stand.', 4),
  ('LOG02', 'Q4', 'A', 'The trophy was stolen by the photographer.', 1),
  ('LOG02', 'Q4', 'B', 'The trophy was authorized to leave the display for photography, but its return was never recorded.', 2),
  ('LOG02', 'Q4', 'C', 'Kavya definitely hid the trophy in the grey crate.', 3),
  ('LOG02', 'Q4', 'D', 'The movement slip is proof that the trophy was returned.', 4),
  ('LOG02', 'Q5', 'A', 'She had a legitimate reason to have the trophy at the awards table, but the photo alone does not show who later moved it.', 1),
  ('LOG02', 'Q5', 'B', 'She must have stolen it because she requested the photo setup.', 2),
  ('LOG02', 'Q5', 'C', 'She could not have seen the trophy because the checklist was signed earlier.', 3),
  ('LOG02', 'Q5', 'D', 'Her statement proves the trophy stayed on the table until 4:25 PM.', 4),
  ('LOG02', 'Q6', 'A', 'The empty stage risers.', 1),
  ('LOG02', 'Q6', 'B', 'The engraving proof with the wrong winning-team name and the handwritten instruction to check the final plate.', 2),
  ('LOG02', 'Q6', 'C', 'The general schedule reminder.', 3),
  ('LOG02', 'Q6', 'D', 'The fact that Naina took a photograph.
---
# Phase 3 — Chain of Custody
## Evidence J — Awards Folder Contents
**Source:** Inventory of Kavya''s signed awards-preparation folder
The folder contains:
- The temporary movement slip for the trophy.
- The engraving proof with the incorrect team name.
- A blank correction request form.
- A note reading: *“Do not announce until confirmed.”*
The correction request form has no vendor receipt or submission timestamp.
## Evidence K — Storage Area Inspection
**Source:** Joint inspection report
Grey crate G-14 is found in the storage area behind rolled banners. The crate contains banner brackets and a padded compartment that can hold a trophy upright. The compartment is empty at inspection.
A strip of protective felt inside the compartment matches the felt used under the Founders'' Trophy base. This establishes that the crate was suitable for transporting the trophy, but does not prove the trophy was inside it at 4:11 PM.
## Evidence L — Revised Ceremony Draft
**Source:** Schedule file history
At 4:17 PM, Kavya drafts a note stating:
*“Presentation may need a short delay while the award is checked.”*
At 4:23 PM, after the trophy is reported missing, the draft is changed to:
*“Presentation delayed due to missing trophy.”*
The file history records both edits. It does not show that the first draft was sent to anyone.
## Evidence M — Vendor Call Record
**Source:** Event desk call log
At 4:12 PM, Kavya calls the engraving vendor. The call lasts 46 seconds. The desk log records the time and recipient, but not the conversation. Meera confirms that Kavya had been asking whether a replacement nameplate could be prepared quickly.
The call record supports a link between Kavya and the engraving issue; it does not, by itself, establish what she said or did with the trophy.
## Evidence N — Final Location Check
**Source:** Search log completed by event staff
At 4:32 PM, staff check:
- The awards display and table.
- The photo bay.
- The stage wings.
- The AV booth.
- The storage area, including the space behind the rolled banners.
The trophy is not found. G-14 is located, but the padded compartment is empty. The search log does not include a search of the locked awards office, which is opened later by the event lead.', 4),
  ('LOG02', 'Q7', 'A', 'The trophy was on the display stand continuously from 3:40 PM until 4:25 PM.', 1),
  ('LOG02', 'Q7', 'B', 'The trophy was moved for photography by 4:08 PM; its return was not recorded, and a storage crate was moved at 4:11 PM.', 2),
  ('LOG02', 'Q7', 'C', 'The trophy was first moved after it was reported missing at 4:25 PM.', 3),
  ('LOG02', 'Q7', 'D', 'The trophy was inside G-14 at 4:32 PM.', 4),
  ('LOG02', 'Q8', 'A', 'They prove Meera stole the trophy.', 1),
  ('LOG02', 'Q8', 'B', 'They show a possible reason to delay the presentation and connect Kavya to the unresolved engraving problem, but they need to be combined with movement evidence.', 2),
  ('LOG02', 'Q8', 'C', 'They prove the trophy was never real.', 3),
  ('LOG02', 'Q8', 'D', 'They are irrelevant because the nameplate is small.', 4),
  ('LOG02', 'Q9', 'A', 'Naina took the trophy after the photograph and left the event.', 1),
  ('LOG02', 'Q9', 'B', 'Arjun hid the trophy while moving the empty stand.', 2),
  ('LOG02', 'Q9', 'C', 'Kavya used the authorized photo movement as an opportunity to divert the trophy, failed to record its return, and prepared to delay the presentation while the engraving error was addressed.', 3),
  ('LOG02', 'Q9', 'D', 'Sameer stole the trophy for its metal value.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG02', 'Q1', 1, 'Check the time of the last actual item verification.'),
  ('LOG02', 'Q1', 2, 'What does “display looks ready” mean?'),
  ('LOG02', 'Q1', 3, 'The checklist is not an item-by-item inspection after 4:05.'),
  ('LOG02', 'Q2', 1, 'Follow an object whose contents are not checked.'),
  ('LOG02', 'Q2', 2, 'Which movement record has both a destination and contents gap?'),
  ('LOG02', 'Q2', 3, 'Investigate the grey crate''s route and contents.'),
  ('LOG02', 'Q3', 1, 'Establish the last confirmed location before searching for a culprit.'),
  ('LOG02', 'Q3', 2, 'Look for an authorized movement record and its return field.'),
  ('LOG02', 'Q3', 3, 'The temporary movement slip is the first break in the chain of custody.'),
  ('LOG02', 'Q4', 1, 'Separate authorization from proof of return.'),
  ('LOG02', 'Q4', 2, 'The slip authorizes the photo movement.'),
  ('LOG02', 'Q4', 3, 'Its return confirmation is blank.'),
  ('LOG02', 'Q5', 1, 'What does the photograph show directly?'),
  ('LOG02', 'Q5', 2, 'It shows the trophy on the table at 4:08, not what happened afterward.'),
  ('LOG02', 'Q5', 3, 'Naina''s role in the photo does not prove later custody.'),
  ('LOG02', 'Q6', 1, 'Look for a problem that would make the ceremony difficult.'),
  ('LOG02', 'Q6', 2, 'Inspect the engraving proof.'),
  ('LOG02', 'Q6', 3, 'The wrong team name could explain pressure to delay the presentation.'),
  ('LOG02', 'Q7', 1, 'Put the photo, crate movement and missing report in order.'),
  ('LOG02', 'Q7', 2, 'The trophy was on the table at 4:08; the crate moved at 4:11.'),
  ('LOG02', 'Q7', 3, 'The record supports an unrecorded return/diversion window, not continuous presence on the stand.'),
  ('LOG02', 'Q8', 1, 'Motive and opportunity are separate.'),
  ('LOG02', 'Q8', 2, 'The paperwork links Kavya to the engraving issue and a planned delay.'),
  ('LOG02', 'Q8', 3, 'Combine this with the movement records; do not treat motive as proof by itself.'),
  ('LOG02', 'Q9', 1, 'Compare which theory explains both the custody gap and the timing of the draft.'),
  ('LOG02', 'Q9', 2, 'Consider the person who handled the authorized movement and knew about the engraving problem.'),
  ('LOG02', 'Q9', 3, 'The strongest theory is a diversion during the unrecorded return period to delay the presentation.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG02', 35, 'kavya_sen', 20, 'B', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG02', 'kavya_sen', 1),
  ('LOG02', 'arjun_rao', 2),
  ('LOG02', 'naina_rao', 3),
  ('LOG02', 'sameer_khan', 4),
  ('LOG02', 'meera_iyer', 5),
  ('LOG02', 'vikram_sethi', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG02', 'A', 'The trophy was taken by a photographer after the group photo and carried out of the venue.', 1),
  ('LOG02', 'B', 'The trophy was diverted after being legitimately moved for photography; the unresolved engraving error gave the awards coordinator a reason to delay the presentation, and the return was not recorded.', 2),
  ('LOG02', 'C', 'The trophy was never delivered to the event.', 3),
  ('LOG02', 'D', 'The trophy was destroyed while the display stand was being moved.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG02', 'chain_of_custody', 'pending', 'Movement sequence needs final review.'),
  ('LOG02', 'physical_link_to_diversion', 'fail', 'Current authored case lacks an independent clue proving Kavya physically diverted the trophy.'),
  ('LOG02', 'exact_trophy_location', 'fail', 'Current player evidence does not establish recovery/location.'),
  ('LOG02', 'scoring_reconciliation', 'fail', '5-point task ladder conflicts with the platform-wide 10/8/6/4/2 ladder.'),
  ('LOG02', 'hint_content', 'fail', 'Only three hints are authored per task while the legacy scoring text describes a five-level ladder.'),
  ('LOG02', 'playtest', 'pending', 'No first-time solo playtest documented.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

commit;
