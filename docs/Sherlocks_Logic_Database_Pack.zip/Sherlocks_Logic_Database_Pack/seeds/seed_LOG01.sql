-- Seed data for LOG01 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
begin;
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG01', 'The Locked Room That Wasn''t', 'LOGIC', '0.1', 1, 'draft_not_seed_ready', 'pre-closure substitution and timeline reconstruction', 100, '{"investigation_max_each":5,"hint_rewards":[5,4,3,2,1],"investigation_task_count":9,"final_person_points":35,"final_explanation_points":20,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Legacy authored allocation conflicts with platform standard 10/8/6/4/2 ladder; do not activate until score model is reconciled."}'::jsonb, '{"case_id":"LOG01","title":"The Locked Room That Wasn''t","track":"LOGIC","version":"0.1","status":"prototype_not_seed_ready","language":"en","phases":[{"phase":1,"name":"Discovery","evidence_ids":["A","B","C","D"],"task_ids":["Q1","Q2","Q3"]},{"phase":2,"name":"Investigation","evidence_ids":["E","F","G","H","I"],"task_ids":["Q4","Q5","Q6"]},{"phase":3,"name":"Reconstruction","evidence_ids":["J","K","L","M","N"],"task_ids":["Q7","Q8","Q9"]}],"characters":[{"id":"rohan_mehta","name":"Rohan Mehta","role":"Competing team leader"},{"id":"naina_rao","name":"Naina Rao","role":"Event photographer"},{"id":"imran_shaikh","name":"Imran Shaikh","role":"Lab technician"},{"id":"devika_nair","name":"Devika Nair","role":"Room key custodian"},{"id":"vikram_sethi","name":"Vikram Sethi","role":"Showcase coordinator"},{"id":"aditya_varma","name":"Aditya Varma","role":"Aster''s creator"}],"tasks":[{"task_id":"Q1","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q2","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q3","phase":1,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q4","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q5","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q6","phase":2,"type":"single_choice","points_proposed":5,"correct_option":"A"},{"task_id":"Q7","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"B"},{"task_id":"Q8","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"},{"task_id":"Q9","phase":3,"type":"single_choice","points_proposed":5,"correct_option":"C"}],"final_deduction":{"person_points_proposed":35,"correct_person_id":"vikram_sethi","explanation_points_proposed":20,"correct_explanation":"C"},"scoring_proposed":{"ordinary_question_points":5,"hint_ladder":[5,4,3,2,1],"wrong_committed_answer_penalty":-2,"total_base_points":100,"status":"requires_reconciliation_with_global_scoring_rules"},"author_only":{"ground_truth":"Vikram removed the genuine Aster before room closure, substituted the replica, and prepared a security-related delay after learning the prototype had failed its output check.","twists":["Rohan is an initially plausible suspect but proximity and motive do not prove guilt.","The object in the 4:18 photograph is a replica.","The substitution occurred before the room was reported closed.","Vikram''s early schedule draft changes the interpretation of the incident."]},"validation_status":{"story_logic_review":"needs_review","physical_link_to_substitution":"gap_to_resolve","innocent_suspect_opportunity_boundaries":"gap_to_resolve","timeline_consistency":"needs_review","playtest":"not_done","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG01', 1, 'Discovery'),
  ('LOG01', 2, 'Investigation'),
  ('LOG01', 3, 'Reconstruction')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG01', 'rohan_mehta', 'Rohan Mehta', 'Competing team leader', 1),
  ('LOG01', 'naina_rao', 'Naina Rao', 'Event photographer', 2),
  ('LOG01', 'imran_shaikh', 'Imran Shaikh', 'Lab technician', 3),
  ('LOG01', 'devika_nair', 'Devika Nair', 'Room key custodian', 4),
  ('LOG01', 'vikram_sethi', 'Vikram Sethi', 'Showcase coordinator', 5),
  ('LOG01', 'aditya_varma', 'Aditya Varma', 'Aster''s creator', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG01', 'A', 1, 'Room Closure Log', 'Devika''s signed checklist', '- 4:05 PM — Aster checked in the display case.
- 4:16 PM — Final room sweep started.
- 4:20 PM — Room reported closed.
- 4:21 PM — Key returned to the event desk.
- 4:30 PM — Missing prototype reported.

Devika''s note reads: *“Display appeared complete before closure.”*', 1),
  ('LOG01', 'B', 1, 'Access and Movement Notes', 'Staff movement sheet and witness statements', '- Rohan was seen near Innovation Room B around 4:08 PM.
- Imran worked on the display lighting earlier that afternoon.
- Naina was inside the room for official photographs.
- Vikram visited the room during preparation.
- Devika was responsible for the key and closing checklist.

The sheet records **presence near the room**, not proof of entry at the time Aster disappeared.', 2),
  ('LOG01', 'C', 1, 'Two Photographs', 'Naina''s official event photo set', '- Photo 1: 4:07 PM — Aster in its display case.
- Photo 2: 4:18 PM — The display case appears complete from the front.

The second photograph is slightly angled. A small label on the base is partly obscured by glare.', 3),
  ('LOG01', 'D', 1, 'The Rehearsal Note', 'Event preparation notebook', 'At 3:52 PM, Aditya wrote:

*“Check the output before the live demo. If the fault returns, do not present it as fully working.”*

There is no signature beside the note and no indication that the issue was resolved.', 4),
  ('LOG01', 'E', 2, 'The Prototype Identification Sheet', 'Aditya''s pre-event technical checklist', 'The genuine Aster has three identifying features:

1. A small blue inspection mark on the underside of its base.
2. A short scratch beside the left mounting screw.
3. A green indicator that lights up when the device is powered.

The display replica was made for photographs and has the same outer shell, but it has no functioning indicator and no internal electronics.', 5),
  ('LOG01', 'F', 2, 'The Enlarged 4:18 Photograph', 'Enhanced crop of Naina''s original photograph', 'The photograph reveals the display''s left mounting screw and the label on its base. The blue inspection mark is absent. The green indicator is dark, and its lens is a solid piece rather than the transparent lens fitted to the genuine prototype.

The image does not prove that the device is switched off: the lens itself is visibly different.', 6),
  ('LOG01', 'G', 2, 'Rohan''s Account', 'Recorded interview', 'Rohan says:

*“I went to the corridor at about 4:08 to collect our presentation file. I did not enter the room. I saw Vikram carrying a flat black event case near the AV booth, but I thought it held cables.”*

Rohan initially denied being near the room, then corrected himself when shown the movement sheet. His first answer was misleading, but the second part of his account is independently testable.', 7),
  ('LOG01', 'H', 2, 'AV Booth Equipment Register', 'Event equipment checkout sheet', '- 4:02 PM — Vikram signs out a flat black equipment case.
- 4:24 PM — The case is listed as returned to the AV booth.
- The register does not record what was placed inside the case.
- No one records an inspection of the case at return.', 8),
  ('LOG01', 'I', 2, 'Maintenance Record', 'Imran''s signed work note', 'Imran repaired the display lighting at 3:35 PM. He records that he did not remove the display''s backing panel and that the case was left open for Aditya''s inspection afterward.

Aditya''s signature confirms the case was open during the inspection. No evidence places Imran inside the room during the later 4:07–4:20 period.', 9),
  ('LOG01', 'J', 3, 'The Rehearsal Follow-up', 'Aditya''s message to the showcase team', 'At 4:00 PM, Aditya sends the team a message:

*“Aster failed the output check again. I need ten minutes to inspect it. Please don''t announce that it''s ready yet.”*

The message is delivered to the event preparation group, which includes Vikram. The delivery record confirms that Vikram''s account received it at 4:01 PM.', 10),
  ('LOG01', 'K', 3, 'The Unsent Schedule Change', 'Event coordinator''s draft schedule', 'At 4:14 PM, Vikram drafts a schedule update stating that Aster''s demonstration may be delayed because of a *“security incident in Innovation Room B.”*

The draft is never sent. Its creation time is recorded by the event scheduling system. The draft alone does not prove that Vikram caused the incident; it does show he was preparing for a delay before the missing prototype was officially reported.', 11),
  ('LOG01', 'L', 3, 'AV Booth Inspection', 'Joint inspection by the event staff', 'The flat black case Vikram signed out is found in the AV booth. Inside it is a foam insert cut to fit the Aster prototype. A small piece of blue protective tape matching the prototype''s packaging is stuck to the insert.

The prototype is not inside the case when it is inspected. The insert proves the case was configured to carry a device of Aster''s size, but does not independently prove that the genuine Aster was inside it.', 12),
  ('LOG01', 'M', 3, 'Aditya''s Final Identification', 'Comparison of the replica with the genuine prototype''s build notes', 'Aditya confirms that the object in the 4:18 photograph is the replica, not the working Aster. The replica''s solid indicator lens, missing inspection mark and different mounting screw are all consistent with his identification sheet.

He also confirms that the genuine Aster was functioning earlier in the afternoon but had failed the 4:00 PM output check. He had not authorized anyone to replace it with the display model.', 13),
  ('LOG01', 'N', 3, 'The Witness Timeline', 'Independently collected statements', '- **Aditya:** sent the failure warning at 4:00 PM and did not authorize a swap.
- **Rohan:** saw Vikram with the black case near the AV booth around 4:08 PM.
- **Naina:** took the photograph showing the replica at 4:18 PM.
- **Devika:** closed the room at 4:20 PM based on the visual checklist.
- **Vikram:** drafted a security-incident schedule change at 4:14 PM.

The statements and records establish a sequence, but no single item directly captures Vikram physically taking Aster.', 14)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG01', 'Q1', 1, 1, '**Which conclusion is actually supported by the closure log?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q2', 1, 2, '**Which suspect has the clearest apparent motive from the evidence available so far?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q3', 1, 3, '**What is the most useful next step?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q4', 1, 4, '**What does the 4:18 photograph establish?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q5', 1, 5, '**Which conclusion about Rohan is best supported now?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q6', 1, 6, '**Which lead should investigators pursue next to test the removal timeline?**', 'single_choice', 5, 'A', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q7', 1, 7, '**Which timeline is consistent with all the evidence?**', 'single_choice', 5, 'B', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q8', 1, 8, '**What is the strongest interpretation of the black equipment case?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2),
  ('LOG01', 'Q9', 1, 9, '**Which hypothesis best explains the full set of evidence with the fewest unsupported assumptions?**', 'single_choice', 5, 'C', array[5, 4, 3, 2, 1], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG01', 'Q1', 'A', 'Rohan stole Aster because he was near the room.', 1),
  ('LOG01', 'Q1', 'B', 'The room was reported closed at 4:20 PM, but the log does not prove when Aster was last physically present.', 2),
  ('LOG01', 'Q1', 'C', 'Aster was definitely present at 4:20 PM.', 3),
  ('LOG01', 'Q1', 'D', 'Devika must have taken Aster because she held the key.', 4),
  ('LOG01', 'Q2', 'A', 'Rohan', 1),
  ('LOG01', 'Q2', 'B', 'Naina', 2),
  ('LOG01', 'Q2', 'C', 'Imran', 3),
  ('LOG01', 'Q2', 'D', 'Devika', 4),
  ('LOG01', 'Q3', 'A', 'Accuse Rohan before he can leave.', 1),
  ('LOG01', 'Q3', 'B', 'Verify whether the object in the 4:18 photograph is the genuine Aster.', 2),
  ('LOG01', 'Q3', 'C', 'Assume the key register proves no one could have removed the prototype.', 3),
  ('LOG01', 'Q3', 'D', 'Investigate every person who has ever worked in the lab.
---
# Phase 2 — Investigation
## Evidence E — The Prototype Identification Sheet
**Source:** Aditya''s pre-event technical checklist
The genuine Aster has three identifying features:
1. A small blue inspection mark on the underside of its base.
2. A short scratch beside the left mounting screw.
3. A green indicator that lights up when the device is powered.
The display replica was made for photographs and has the same outer shell, but it has no functioning indicator and no internal electronics.
## Evidence F — The Enlarged 4:18 Photograph
**Source:** Enhanced crop of Naina''s original photograph
The photograph reveals the display''s left mounting screw and the label on its base. The blue inspection mark is absent. The green indicator is dark, and its lens is a solid piece rather than the transparent lens fitted to the genuine prototype.
The image does not prove that the device is switched off: the lens itself is visibly different.
## Evidence G — Rohan''s Account
**Source:** Recorded interview
Rohan says:
*“I went to the corridor at about 4:08 to collect our presentation file. I did not enter the room. I saw Vikram carrying a flat black event case near the AV booth, but I thought it held cables.”*
Rohan initially denied being near the room, then corrected himself when shown the movement sheet. His first answer was misleading, but the second part of his account is independently testable.
## Evidence H — AV Booth Equipment Register
**Source:** Event equipment checkout sheet
- 4:02 PM — Vikram signs out a flat black equipment case.
- 4:24 PM — The case is listed as returned to the AV booth.
- The register does not record what was placed inside the case.
- No one records an inspection of the case at return.
## Evidence I — Maintenance Record
**Source:** Imran''s signed work note
Imran repaired the display lighting at 3:35 PM. He records that he did not remove the display''s backing panel and that the case was left open for Aditya''s inspection afterward.
Aditya''s signature confirms the case was open during the inspection. No evidence places Imran inside the room during the later 4:07–4:20 period.', 4),
  ('LOG01', 'Q4', 'A', 'Aster was definitely present because a device-shaped object is visible.', 1),
  ('LOG01', 'Q4', 'B', 'The genuine Aster was likely replaced by the display replica before the room was closed.', 2),
  ('LOG01', 'Q4', 'C', 'Naina stole Aster because she took the photograph.', 3),
  ('LOG01', 'Q4', 'D', 'The room''s lock was defective.', 4),
  ('LOG01', 'Q5', 'A', 'He is guilty because he initially denied being near the room.', 1),
  ('LOG01', 'Q5', 'B', 'His account contains a contradiction that must be checked, but his presence alone does not prove he entered or removed Aster.', 2),
  ('LOG01', 'Q5', 'C', 'He is innocent because he eventually told the truth.', 3),
  ('LOG01', 'Q5', 'D', 'He must have used Imran''s tools.', 4),
  ('LOG01', 'Q6', 'A', 'Search the AV booth and determine whether the returned equipment case could still contain Aster.', 1),
  ('LOG01', 'Q6', 'B', 'Accuse Naina because the replica appears in her photograph.', 2),
  ('LOG01', 'Q6', 'C', 'Reopen Imran''s maintenance work without checking the later timeline.', 3),
  ('LOG01', 'Q6', 'D', 'Treat Devika''s closure checklist as proof that the genuine prototype was present at 4:20.
---
# Phase 3 — Reconstruction
## Evidence J — The Rehearsal Follow-up
**Source:** Aditya''s message to the showcase team
At 4:00 PM, Aditya sends the team a message:
*“Aster failed the output check again. I need ten minutes to inspect it. Please don''t announce that it''s ready yet.”*
The message is delivered to the event preparation group, which includes Vikram. The delivery record confirms that Vikram''s account received it at 4:01 PM.
## Evidence K — The Unsent Schedule Change
**Source:** Event coordinator''s draft schedule
At 4:14 PM, Vikram drafts a schedule update stating that Aster''s demonstration may be delayed because of a *“security incident in Innovation Room B.”*
The draft is never sent. Its creation time is recorded by the event scheduling system. The draft alone does not prove that Vikram caused the incident; it does show he was preparing for a delay before the missing prototype was officially reported.
## Evidence L — AV Booth Inspection
**Source:** Joint inspection by the event staff
The flat black case Vikram signed out is found in the AV booth. Inside it is a foam insert cut to fit the Aster prototype. A small piece of blue protective tape matching the prototype''s packaging is stuck to the insert.
The prototype is not inside the case when it is inspected. The insert proves the case was configured to carry a device of Aster''s size, but does not independently prove that the genuine Aster was inside it.
## Evidence M — Aditya''s Final Identification
**Source:** Comparison of the replica with the genuine prototype''s build notes
Aditya confirms that the object in the 4:18 photograph is the replica, not the working Aster. The replica''s solid indicator lens, missing inspection mark and different mounting screw are all consistent with his identification sheet.
He also confirms that the genuine Aster was functioning earlier in the afternoon but had failed the 4:00 PM output check. He had not authorized anyone to replace it with the display model.
## Evidence N — The Witness Timeline
**Source:** Independently collected statements
- **Aditya:** sent the failure warning at 4:00 PM and did not authorize a swap.
- **Rohan:** saw Vikram with the black case near the AV booth around 4:08 PM.
- **Naina:** took the photograph showing the replica at 4:18 PM.
- **Devika:** closed the room at 4:20 PM based on the visual checklist.
- **Vikram:** drafted a security-incident schedule change at 4:14 PM.
The statements and records establish a sequence, but no single item directly captures Vikram physically taking Aster.', 4),
  ('LOG01', 'Q7', 'A', 'The room was locked at 4:20, then someone entered and replaced Aster with the replica.', 1),
  ('LOG01', 'Q7', 'B', 'Vikram learned about the failed output check, prepared for a possible security-related delay, and the replica was in place before the room closed.', 2),
  ('LOG01', 'Q7', 'C', 'Rohan removed Aster after 4:20, then returned the replica without being seen.', 3),
  ('LOG01', 'Q7', 'D', 'Imran''s 3:35 lighting repair proves he took Aster.', 4),
  ('LOG01', 'Q8', 'A', 'It conclusively proves Vikram transported the genuine Aster.', 1),
  ('LOG01', 'Q8', 'B', 'It is irrelevant because the prototype was not found inside it.', 2),
  ('LOG01', 'Q8', 'C', 'It independently links Vikram to a container prepared for an object of Aster''s size, supporting—but not proving—the removal theory.', 3),
  ('LOG01', 'Q8', 'D', 'It proves Rohan lied about everything.', 4),
  ('LOG01', 'Q9', 'A', 'Rohan entered the locked room after 4:20 and somehow replaced the genuine prototype.', 1),
  ('LOG01', 'Q9', 'B', 'Imran used his maintenance knowledge to bypass the room''s lock after closure.', 2),
  ('LOG01', 'Q9', 'C', 'Vikram used the failed rehearsal as a reason to remove Aster before closure, substitute the replica, and prepare a security-related delay.', 3),
  ('LOG01', 'Q9', 'D', 'Naina accidentally photographed a different prototype and caused the entire incident through a camera error.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG01', 'Q1', 1, 'Separate the record''s timestamp from the conclusion someone draws from it.'),
  ('LOG01', 'Q1', 2, 'What did the staff actually verify?'),
  ('LOG01', 'Q1', 3, 'The checklist records a closure process, not a forensic identification of the object.'),
  ('LOG01', 'Q2', 1, 'Identify the person with a documented conflict involving Aster''s team.'),
  ('LOG01', 'Q2', 2, 'Which conflict could plausibly motivate interference?'),
  ('LOG01', 'Q2', 3, 'Rohan has the clearest apparent motive so far, but motive is not proof.'),
  ('LOG01', 'Q3', 1, 'Before asking how an object left, verify which object is visible.'),
  ('LOG01', 'Q3', 2, 'Compare the photograph with the identification sheet.'),
  ('LOG01', 'Q3', 3, 'Look for physical features that cannot be explained by the device merely being switched off.'),
  ('LOG01', 'Q4', 1, 'Compare the identification sheet with the enlarged photograph.'),
  ('LOG01', 'Q4', 2, 'Look at the inspection mark and indicator lens.'),
  ('LOG01', 'Q4', 3, 'The lens itself is different, not merely unlit.'),
  ('LOG01', 'Q5', 1, 'Evaluate each part of Rohan''s account separately.'),
  ('LOG01', 'Q5', 2, 'Check the claim about the black case against an independent record.'),
  ('LOG01', 'Q5', 3, 'The register confirms Vikram checked out a case, but neither fact alone proves theft.'),
  ('LOG01', 'Q6', 1, 'Which object has an unverified chain of custody?'),
  ('LOG01', 'Q6', 2, 'The equipment register does not state what the case contained.'),
  ('LOG01', 'Q6', 3, 'Inspect the returned case and its insert.'),
  ('LOG01', 'Q7', 1, 'Put the message, draft, photograph and closure log in time order.'),
  ('LOG01', 'Q7', 2, 'The replica appears before the room is reported closed.'),
  ('LOG01', 'Q7', 3, 'The evidence supports a pre-closure substitution, not a post-lock entry.'),
  ('LOG01', 'Q8', 1, 'Separate what the case physically proves from what investigators infer.'),
  ('LOG01', 'Q8', 2, 'The case has a fitted insert and packaging trace, but the prototype is absent.'),
  ('LOG01', 'Q8', 3, 'It supports the removal theory without conclusively proving the case''s contents at the critical time.'),
  ('LOG01', 'Q9', 1, 'Compare how many independent records each hypothesis explains.'),
  ('LOG01', 'Q9', 2, 'Consider who knew about the failed prototype and prepared for a security-related delay.'),
  ('LOG01', 'Q9', 3, 'Combine the rehearsal warning, early draft, case evidence and pre-closure replica.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG01', 35, 'vikram_sethi', 20, 'C', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG01', 'rohan_mehta', 1),
  ('LOG01', 'naina_rao', 2),
  ('LOG01', 'imran_shaikh', 3),
  ('LOG01', 'devika_nair', 4),
  ('LOG01', 'vikram_sethi', 5),
  ('LOG01', 'aditya_varma', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG01', 'A', 'The genuine Aster was stolen after the room was locked, using an unknown way into the room.', 1),
  ('LOG01', 'B', 'The genuine Aster was accidentally damaged during maintenance, and the display model was substituted to hide the damage.', 2),
  ('LOG01', 'C', 'The genuine Aster was removed before closure and replaced with a replica; the disappearance was used to create a security-related delay after the rehearsal failure.', 3),
  ('LOG01', 'D', 'The genuine Aster was never placed in the room; the entire event team mistakenly believed a replica was the real prototype.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG01', 'story_logic_review', 'pending', 'Review timeline and ensure phase evidence is internally consistent.'),
  ('LOG01', 'physical_link_to_substitution', 'fail', 'Current authored case lacks independent time-bounded proof linking Vikram to the physical swap.'),
  ('LOG01', 'opportunity_boundaries', 'fail', 'Presence/opportunity boundaries for innocent suspects are not independently established.'),
  ('LOG01', 'scoring_reconciliation', 'fail', '5-point task ladder conflicts with the platform-wide 10/8/6/4/2 ladder.'),
  ('LOG01', 'hint_content', 'fail', 'Only three hints are authored per task while the legacy scoring text describes a five-level ladder.'),
  ('LOG01', 'playtest', 'pending', 'No first-time solo playtest documented.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

commit;
