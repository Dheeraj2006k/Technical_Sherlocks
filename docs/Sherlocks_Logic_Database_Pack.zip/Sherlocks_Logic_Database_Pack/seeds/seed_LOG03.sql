-- Seed data for LOG03 — generated from the current authored case pack.
-- Restricted case content: execute only in the server-side Supabase project.
begin;
insert into public.logic_case_catalog (case_id, title, track, content_version, recommended_team_size, release_status, core_mechanism, max_score, scoring_config, source_manifest) values
  ('LOG03', 'The Silent Call', 'LOGIC', '1.0.0', 2, 'content_final_pending_platform_qa_and_live_playtest', 'distinguish_call_attempts_from_connected_calls_and_authorized_instructions', 100, '{"investigation_max_each":10,"hint_rewards":[10,8,6,4,2],"investigation_task_count":6,"final_person_points":25,"final_explanation_points":15,"wrong_committed_answer_penalty":2,"score_floor":0,"note":"Content allocation matches the platform standard."}'::jsonb, '{"case_id":"LOG03","title":"The Silent Call","track":"LOGIC","team_size":2,"content_version":"1.0.0","status":"content_final_pending_platform_QA_and_live_playtest","core_mechanism":"distinguish_call_attempts_from_connected_calls_and_authorized_instructions","player_asset":"LOG03_Player_Case.md","restricted_assets":["LOG03_Case_Manifest.json","LOG03_Author_Notes.md","LOG03_Scoring_and_Hints.md","LOG03_Validation_Checklist.md"],"phases":[{"phase":1,"name":"The Claim","evidence_ids":["A","B","C","D"],"task_ids":["T1","T2"]},{"phase":2,"name":"Two Sides of the Call","evidence_ids":["E","F","G","H"],"task_ids":["T3","T4"]},{"phase":3,"name":"The Missing Confirmation","evidence_ids":["I","J","K","L"],"task_ids":["T5","T6"]}],"characters":[{"id":"ananya_rao","name":"Ananya Rao","role":"Faculty supervisor"},{"id":"karthik_menon","name":"Karthik Menon","role":"Stage coordinator"},{"id":"sana_ali","name":"Sana Ali","role":"Control-desk volunteer"},{"id":"dev_malhotra","name":"Dev Malhotra","role":"Pulse team leader"},{"id":"ritesh_shah","name":"Ritesh Shah","role":"AV technician"},{"id":"meera_joshi","name":"Meera Joshi","role":"Faculty office assistant"}],"tasks":[{"task_id":"T1","phase":1,"player_heading":"Investigation Task 1","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T2","phase":1,"player_heading":"Investigation Task 2","correct_option":"A","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T3","phase":2,"player_heading":"Investigation Task 3","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T4","phase":2,"player_heading":"Investigation Task 4","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T5","phase":3,"player_heading":"Investigation Task 5","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2},{"task_id":"T6","phase":3,"player_heading":"Investigation Task 6","correct_option":"B","max_points":10,"hint_rewards":[10,8,6,4,2],"wrong_answer_penalty":2}],"final_deduction":{"responsible_person_field":"responsible_person_id","responsible_person":"karthik_menon","responsible_person_points":25,"explanation_field":"explanation_option","explanation_option":"B","explanation_points":15,"wrong_answer_penalty":2,"components_graded_independently":true,"correct_person_id":"karthik_menon","correct_explanation":"B","person_points_proposed":25,"explanation_points_proposed":15},"scoring":{"ordinary_tasks_max":60,"final_deduction_max":40,"base_total":100,"hint_rewards_by_hints_used":{"0":10,"1":8,"2":6,"3":4,"4":2},"wrong_committed_answer_penalty":-2,"score_floor":0,"retry_allowed":true,"award_success_once":true,"server_authoritative":true},"author_only":{"ground_truth":"Karthik knowingly presented an unverified request to hold Pulse as a confirmed faculty cancellation after a schedule dispute.","unknown_fact":"The identity of the 4:10 caller is not established and is not required for the solution.","evidence_logic":"The genuine cable concern explains the temporary hold request; independent call logs contradict the claimed connected confirmation; the published announcement and authenticated private note support knowing misrepresentation.","do_not_grade":["identity of the 4:10 caller","free-text theories","client-side timestamps"]},"release_gates":{"content_review":"complete_in_this_pack","json_parse_and_schema_validation":"required_before_seed","server_side_answer_key_and_phase_access_test":"required_before_seed","two_player_shared_state_test":"required_before_seed","first_time_duo_playtests":"required_before_live_event","seed_ready":false}}'::jsonb)
on conflict  (case_id) do update set title=excluded.title, content_version=excluded.content_version, recommended_team_size=excluded.recommended_team_size, release_status=excluded.release_status, core_mechanism=excluded.core_mechanism, scoring_config=excluded.scoring_config, source_manifest=excluded.source_manifest, updated_at=now();

insert into public.logic_case_phases (case_id, phase_number, phase_name) values
  ('LOG03', 1, 'The Claim'),
  ('LOG03', 2, 'Two Sides of the Call'),
  ('LOG03', 3, 'The Missing Confirmation')
on conflict  (case_id, phase_number) do update set phase_name=excluded.phase_name;

insert into public.logic_case_characters (case_id, character_id, display_name, role, sort_order) values
  ('LOG03', 'ananya_rao', 'Ananya Rao', 'Faculty supervisor', 1),
  ('LOG03', 'karthik_menon', 'Karthik Menon', 'Stage coordinator', 2),
  ('LOG03', 'sana_ali', 'Sana Ali', 'Control-desk volunteer', 3),
  ('LOG03', 'dev_malhotra', 'Dev Malhotra', 'Pulse team leader', 4),
  ('LOG03', 'ritesh_shah', 'Ritesh Shah', 'AV technician', 5),
  ('LOG03', 'meera_joshi', 'Meera Joshi', 'Faculty office assistant', 6)
on conflict  (case_id, character_id) do update set display_name=excluded.display_name, role=excluded.role, sort_order=excluded.sort_order;

insert into public.logic_case_evidence (case_id, evidence_id, phase_number, title, source_label, body_markdown, sort_order) values
  ('LOG03', 'A', 1, 'Stage Running Sheet', 'Stage coordinator''s event sheet', '- 3:50 PM — Pulse demonstration confirmed for 4:30 PM.
- 4:05 PM — Ritesh reports a loose power cable near the stage.
- 4:09 PM — Ritesh marks the cable secured after inspection.
- 4:12 PM — Karthik writes: “Faculty cancelled Pulse — electrical concern.”
- 4:13 PM — Pulse is removed from the running order.
- 4:35 PM — Ananya arrives and disputes the cancellation.

The sheet does not identify who gave Karthik the cancellation instruction.', 1),
  ('LOG03', 'B', 1, 'Control Desk Call Log', 'Event control desk phone', '| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Outgoing call to faculty office | 00:00 | No answer |
| 4:10 PM | Incoming call, caller ID withheld | 00:18 | Answered by Sana |
| 4:11 PM | Outgoing call to Karthik | 00:00 | No answer |
| 4:14 PM | Incoming call from faculty office | 00:00 | Missed |

The desk system records call duration. A duration of `00:00` means the call did not connect in this system. It does not reveal what a caller intended to say.', 2),
  ('LOG03', 'C', 1, 'Karthik''s Statement', 'Initial interview', 'Karthik says:

*“At about 4:11, the faculty office called me and confirmed the cancellation. I wrote it down immediately. I wouldn''t stop a team''s demonstration without approval.”*

He says he did not speak to Sana before making the announcement.', 3),
  ('LOG03', 'D', 1, 'Safety Check', 'Ritesh''s signed equipment checklist', '- 4:05 PM — Loose cable reported.
- 4:09 PM — Cable secured and tested.
- 4:10 PM — Stage power checked; no continuing fault recorded.
- 4:30 PM — Pulse demonstration remains listed as safe to proceed, pending normal start checks.', 4),
  ('LOG03', 'E', 2, 'Faculty Office Phone Log', 'Faculty office landline system', '| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Incoming call from control desk | 00:00 | Missed |
| 4:10 PM | No incoming or outgoing call recorded | — | — |
| 4:11 PM | No outgoing call to Karthik recorded | — | — |
| 4:14 PM | Outgoing call to control desk | 00:00 | No answer |

The faculty office system and control desk system both show no connected call between the faculty office and Karthik before the cancellation was announced.', 5),
  ('LOG03', 'F', 2, 'Sana''s Clarification', 'Follow-up interview', 'Sana says the 4:10 call lasted about eighteen seconds. The caller said:

*“There may be an electrical problem. Please hold the Pulse slot until it is checked.”*

Sana did not hear the caller''s name. The caller did **not** say that the faculty supervisor had cancelled the demonstration.

Sana says she attempted to call Karthik back at 4:11, but he did not answer. The control desk log shows this outgoing call lasted `00:00`.', 6),
  ('LOG03', 'G', 2, 'Message Draft', 'Karthik''s event messaging app, inspected with permission', 'At 4:12 PM, Karthik drafts the following announcement:

*“As confirmed by the faculty supervisor, Pulse is cancelled due to an electrical safety concern.”*

The draft is posted to the stage team''s internal channel at 4:13 PM. The app records the draft and posting times. It does not show that the faculty supervisor approved the wording. The draft was created after the 4:10 call and before the 4:13 post; the time alone does not establish what Karthik believed.', 7),
  ('LOG03', 'H', 2, 'Dev''s Call History', 'Dev''s phone, shown during interview', '- 4:06 PM — Outgoing call to the control desk, connected for 24 seconds.
- 4:10 PM — No call to the faculty office.
- 4:15 PM — Message to a teammate: “They''ve paused us. Nobody has told us why yet.”

Dev says he called to confirm that Pulse was still scheduled. He says the person who answered told him the slot was still listed, but that a safety check was underway.', 8),
  ('LOG03', 'I', 3, 'Control Desk Procedure Card', 'Printed procedure beside the event phone', 'For safety-related changes:
1. Record the caller''s name and role.
2. If the caller claims faculty authorization, call the faculty office back using the number on the approved contact sheet.
3. Do not change the running order until authorization is confirmed.
4. A request to “hold” a slot is not the same as a cancellation.

Sana''s incident note at 4:10 says only: *“Caller unidentified — possible electrical issue — verify.”*', 9),
  ('LOG03', 'J', 3, 'Approved Contact Sheet', 'Event control desk folder', 'The faculty office''s approved callback number ends in **204**. The control desk log''s 4:07 outgoing call was made to that number and did not connect. No connected callback to that number appears before 4:13.

Karthik''s phone history shows no incoming call from the faculty office between 4:00 and 4:15.', 10),
  ('LOG03', 'K', 3, 'Karthik''s Private Note', 'Paper running sheet recovered from the stage desk', 'Beside the 4:12 cancellation entry, Karthik wrote:

*“Need a reason to move Pulse after slot dispute. Safety concern is enough if marked faculty-approved.”*

The handwriting is identified as Karthik''s by the event lead. Karthik says he wrote the note as a reminder to verify the instruction, but the note does not say “verify” or “pending.”', 11),
  ('LOG03', 'L', 3, 'Final Timeline', 'Combined timeline prepared by the event lead', '- 4:05 — Ritesh reports a loose cable.
- 4:09 — Cable is secured and tested.
- 4:10 — Unidentified caller asks the control desk to hold Pulse pending a check.
- 4:11 — Sana''s attempted call to Karthik does not connect.
- 4:12 — Karthik records “faculty cancelled” and drafts the announcement.
- 4:13 — The announcement is posted.
- 4:14 — The faculty office''s return call to the control desk is missed.
- 4:35 — Ananya says she never cancelled Pulse.

The records show that the safety concern was real, but they do not show a connected call in which the faculty office cancelled the demonstration.', 12)
on conflict  (case_id, evidence_id) do update set phase_number=excluded.phase_number, title=excluded.title, source_label=excluded.source_label, body_markdown=excluded.body_markdown, sort_order=excluded.sort_order;

insert into public.logic_case_tasks (case_id, task_id, phase_number, task_number, prompt_markdown, task_type, max_points, correct_option_key, hint_rewards, wrong_answer_penalty) values
  ('LOG03', 'T1', 1, 1, '**What does the phone log establish about the alleged 4:11 PM confirmation from the faculty office to Karthik?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T2', 1, 2, '**Which conclusion is best supported by the safety checklist?**', 'single_choice', 10, 'A', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T3', 1, 3, '**What did the 4:10 incoming call to the control desk actually communicate, according to Sana?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T4', 1, 4, '**Which statement about the call records is correct?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T5', 1, 5, '**Which rule was most clearly violated?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2),
  ('LOG03', 'T6', 1, 6, '**What does Karthik''s private note add to the case?**', 'single_choice', 10, 'B', array[10, 8, 6, 4, 2], 2)
on conflict  (case_id, task_id) do update set phase_number=excluded.phase_number, task_number=excluded.task_number, prompt_markdown=excluded.prompt_markdown, max_points=excluded.max_points, correct_option_key=excluded.correct_option_key, hint_rewards=excluded.hint_rewards, wrong_answer_penalty=excluded.wrong_answer_penalty;

insert into public.logic_case_task_options (case_id, task_id, option_key, option_text, sort_order) values
  ('LOG03', 'T1', 'A', 'The call definitely happened and the cancellation was confirmed.', 1),
  ('LOG03', 'T1', 'B', 'The listed 4:11 PM call was an outgoing call from the control desk to Karthik that did not connect; it does not support Karthik''s claim of a connected faculty-office call at that time.', 2),
  ('LOG03', 'T1', 'C', 'The faculty supervisor never made any call that day.', 3),
  ('LOG03', 'T1', 'D', 'The caller at 4:10 was definitely Ananya.', 4),
  ('LOG03', 'T2', 'A', 'There was a real cable concern, but it was marked fixed before the cancellation was recorded.', 1),
  ('LOG03', 'T2', 'B', 'The stage was dangerous throughout the afternoon.', 2),
  ('LOG03', 'T2', 'C', 'Ritesh must have invented the fault.', 3),
  ('LOG03', 'T2', 'D', 'The faculty supervisor cancelled Pulse because of the cable.
---
# Phase 2 — Two Sides of the Call
## Evidence E — Faculty Office Phone Log
**Source:** Faculty office landline system
| Time | Record | Duration | Note |
|---|---|---:|---|
| 4:07 PM | Incoming call from control desk | 00:00 | Missed |
| 4:10 PM | No incoming or outgoing call recorded | — | — |
| 4:11 PM | No outgoing call to Karthik recorded | — | — |
| 4:14 PM | Outgoing call to control desk | 00:00 | No answer |
The faculty office system and control desk system both show no connected call between the faculty office and Karthik before the cancellation was announced.
## Evidence F — Sana''s Clarification
**Source:** Follow-up interview
Sana says the 4:10 call lasted about eighteen seconds. The caller said:
*“There may be an electrical problem. Please hold the Pulse slot until it is checked.”*
Sana did not hear the caller''s name. The caller did **not** say that the faculty supervisor had cancelled the demonstration.
Sana says she attempted to call Karthik back at 4:11, but he did not answer. The control desk log shows this outgoing call lasted `00:00`.
## Evidence G — Message Draft
**Source:** Karthik''s event messaging app, inspected with permission
At 4:12 PM, Karthik drafts the following announcement:
*“As confirmed by the faculty supervisor, Pulse is cancelled due to an electrical safety concern.”*
The draft is posted to the stage team''s internal channel at 4:13 PM. The app records the draft and posting times. It does not show that the faculty supervisor approved the wording. The draft was created after the 4:10 call and before the 4:13 post; the time alone does not establish what Karthik believed.
## Evidence H — Dev''s Call History
**Source:** Dev''s phone, shown during interview
- 4:06 PM — Outgoing call to the control desk, connected for 24 seconds.
- 4:10 PM — No call to the faculty office.
- 4:15 PM — Message to a teammate: “They''ve paused us. Nobody has told us why yet.”
Dev says he called to confirm that Pulse was still scheduled. He says the person who answered told him the slot was still listed, but that a safety check was underway.', 4),
  ('LOG03', 'T3', 'A', 'The faculty supervisor had formally cancelled Pulse.', 1),
  ('LOG03', 'T3', 'B', 'There might be an electrical problem and the slot should be held until checked; the caller did not identify themselves or claim faculty authorization.', 2),
  ('LOG03', 'T3', 'C', 'Dev demanded that Pulse be cancelled.', 3),
  ('LOG03', 'T3', 'D', 'The caller confirmed that the cable was still dangerous.', 4),
  ('LOG03', 'T4', 'A', 'A call appearing in a log always means the people spoke.', 1),
  ('LOG03', 'T4', 'B', 'The two phone systems show no connected faculty-office call to Karthik before the cancellation announcement.', 2),
  ('LOG03', 'T4', 'C', 'The logs prove Ananya never used a phone that day.', 3),
  ('LOG03', 'T4', 'D', 'The 4:14 missed call proves the faculty office approved the cancellation.
---
# Phase 3 — The Missing Confirmation
## Evidence I — Control Desk Procedure Card
**Source:** Printed procedure beside the event phone
For safety-related changes:
1. Record the caller''s name and role.
2. If the caller claims faculty authorization, call the faculty office back using the number on the approved contact sheet.
3. Do not change the running order until authorization is confirmed.
4. A request to “hold” a slot is not the same as a cancellation.
Sana''s incident note at 4:10 says only: *“Caller unidentified — possible electrical issue — verify.”*
## Evidence J — Approved Contact Sheet
**Source:** Event control desk folder
The faculty office''s approved callback number ends in **204**. The control desk log''s 4:07 outgoing call was made to that number and did not connect. No connected callback to that number appears before 4:13.
Karthik''s phone history shows no incoming call from the faculty office between 4:00 and 4:15.
## Evidence K — Karthik''s Private Note
**Source:** Paper running sheet recovered from the stage desk
Beside the 4:12 cancellation entry, Karthik wrote:
*“Need a reason to move Pulse after slot dispute. Safety concern is enough if marked faculty-approved.”*
The handwriting is identified as Karthik''s by the event lead. Karthik says he wrote the note as a reminder to verify the instruction, but the note does not say “verify” or “pending.”
## Evidence L — Final Timeline
**Source:** Combined timeline prepared by the event lead
- 4:05 — Ritesh reports a loose cable.
- 4:09 — Cable is secured and tested.
- 4:10 — Unidentified caller asks the control desk to hold Pulse pending a check.
- 4:11 — Sana''s attempted call to Karthik does not connect.
- 4:12 — Karthik records “faculty cancelled” and drafts the announcement.
- 4:13 — The announcement is posted.
- 4:14 — The faculty office''s return call to the control desk is missed.
- 4:35 — Ananya says she never cancelled Pulse.
The records show that the safety concern was real, but they do not show a connected call in which the faculty office cancelled the demonstration.', 4),
  ('LOG03', 'T5', 'A', 'A safety concern must never be reported.', 1),
  ('LOG03', 'T5', 'B', 'A request to hold a slot is not a cancellation, and claimed faculty authorization must be verified before changing the running order.', 2),
  ('LOG03', 'T5', 'C', 'Photographs must be taken before every demonstration.', 3),
  ('LOG03', 'T5', 'D', 'Only students can call the control desk.', 4),
  ('LOG03', 'T6', 'A', 'It proves the cable was never loose.', 1),
  ('LOG03', 'T6', 'B', 'It gives evidence that Karthik had a schedule-related motive and knowingly treated an unconfirmed concern as faculty-approved.', 2),
  ('LOG03', 'T6', 'C', 'It proves Dev placed the 4:10 call.', 3),
  ('LOG03', 'T6', 'D', 'It proves Ananya secretly cancelled Pulse.
---', 4)
on conflict  (case_id, task_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_task_hints (case_id, task_id, hint_number, hint_text) values
  ('LOG03', 'T1', 1, 'Read the direction column, not just the time.'),
  ('LOG03', 'T1', 2, 'Compare the 4:11 entry with Karthik''s claim.'),
  ('LOG03', 'T1', 3, 'An outgoing control-desk call is not a call from the faculty office.'),
  ('LOG03', 'T1', 4, 'The 4:11 call did not connect, so it cannot be the claimed confirmation.'),
  ('LOG03', 'T2', 1, 'Compare the time the cable was reported with the time it was checked.'),
  ('LOG03', 'T2', 2, 'Read the status recorded at 4:09 and 4:10.'),
  ('LOG03', 'T2', 3, 'The checklist says the cable was secured and tested before the cancellation entry.'),
  ('LOG03', 'T2', 4, 'The genuine earlier concern explains why someone might request a hold; it does not prove faculty cancellation.'),
  ('LOG03', 'T3', 1, 'Use Sana''s account of the words spoken, not Karthik''s later wording.'),
  ('LOG03', 'T3', 2, 'Notice the difference between “hold” and “cancel.”'),
  ('LOG03', 'T3', 3, 'The caller did not identify themselves or claim faculty authority.'),
  ('LOG03', 'T3', 4, 'The call requested a temporary hold pending a check, not a formal cancellation.'),
  ('LOG03', 'T4', 1, 'Check both phone systems.'),
  ('LOG03', 'T4', 2, 'A missed or zero-duration call is not proof that a conversation took place.'),
  ('LOG03', 'T4', 3, 'Neither system records a connected faculty-office call to Karthik before the announcement.'),
  ('LOG03', 'T4', 4, 'The claimed confirmation is unsupported by the independent logs.'),
  ('LOG03', 'T5', 1, 'Read all four steps on the procedure card.'),
  ('LOG03', 'T5', 2, 'A safety report is not the same as authorization to change the running order.'),
  ('LOG03', 'T5', 3, 'The policy requires verification and explicitly distinguishes a hold from a cancellation.'),
  ('LOG03', 'T5', 4, 'The rule against changing the running order before confirmed authorization was violated.'),
  ('LOG03', 'T6', 1, 'Consider the note''s wording and where it appears on the running sheet.'),
  ('LOG03', 'T6', 2, 'The note links moving Pulse to a schedule dispute.'),
  ('LOG03', 'T6', 3, 'It says the safety concern is enough if marked faculty-approved.'),
  ('LOG03', 'T6', 4, 'Together with the unsupported announcement, the note supports knowing misrepresentation rather than a simple misunderstanding.')
on conflict  (case_id, task_id, hint_number) do update set hint_text=excluded.hint_text;

insert into public.logic_case_final_deductions (case_id, responsible_person_points, correct_character_id, explanation_points, correct_explanation_key, wrong_answer_penalty, components_graded_independently) values
  ('LOG03', 25, 'karthik_menon', 15, 'B', 2, true)
on conflict  (case_id) do update set responsible_person_points=excluded.responsible_person_points, correct_character_id=excluded.correct_character_id, explanation_points=excluded.explanation_points, correct_explanation_key=excluded.correct_explanation_key, wrong_answer_penalty=excluded.wrong_answer_penalty, components_graded_independently=excluded.components_graded_independently;

insert into public.logic_case_final_person_options (case_id, character_id, sort_order) values
  ('LOG03', 'ananya_rao', 1),
  ('LOG03', 'karthik_menon', 2),
  ('LOG03', 'sana_ali', 3),
  ('LOG03', 'dev_malhotra', 4),
  ('LOG03', 'ritesh_shah', 5),
  ('LOG03', 'meera_joshi', 6)
on conflict  (case_id, character_id) do update set sort_order=excluded.sort_order;

insert into public.logic_case_final_explanation_options (case_id, option_key, option_text, sort_order) values
  ('LOG03', 'A', 'The faculty office connected to Karthik and officially cancelled Pulse.', 1),
  ('LOG03', 'B', 'A real but already addressed cable concern prompted an unidentified caller to request a temporary hold; Karthik turned that unconfirmed request into a false claim of faculty cancellation.', 2),
  ('LOG03', 'C', 'Dev cancelled his own team''s demonstration to gain attention.', 3),
  ('LOG03', 'D', 'There was never any cable concern, and all safety records were fabricated.', 4)
on conflict  (case_id, option_key) do update set option_text=excluded.option_text, sort_order=excluded.sort_order;

insert into public.logic_case_release_gates (case_id, gate_key, gate_status, notes) values
  ('LOG03', 'content_review', 'pass', 'Narrative pack states content review complete.'),
  ('LOG03', 'call_log_consistency', 'pending', 'Recheck the direction/duration consistency across both phone systems.'),
  ('LOG03', 'answer_key_security', 'pending', 'Confirm no client route exposes answer-key fields.'),
  ('LOG03', 'two_player_shared_state', 'pending', 'Test two clients using the same team session.'),
  ('LOG03', 'duo_playtest', 'pending', 'Run first-time duo playtests before event use.')
on conflict  (case_id, gate_key) do update set gate_status=excluded.gate_status, notes=excluded.notes;

commit;
