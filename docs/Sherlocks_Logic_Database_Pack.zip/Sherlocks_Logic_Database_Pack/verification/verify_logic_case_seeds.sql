-- Run after schema + seeds. All result rows should show pass=true except the documented release gates.
with counts as (
 select c.case_id,
   count(distinct p.phase_number) as phases,
   count(distinct ch.character_id) as characters,
   count(distinct e.evidence_id) as evidence,
   count(distinct t.task_id) as tasks,
   count(distinct fd.case_id) as final_deduction,
   count(distinct fp.character_id) as final_person_options,
   count(distinct fe.option_key) as final_explanations,
   coalesce(sum(t.max_points),0) + coalesce(max(fd.responsible_person_points + fd.explanation_points),0) as theoretical_base_points
 from public.logic_case_catalog c
 left join public.logic_case_phases p using(case_id)
 left join public.logic_case_characters ch using(case_id)
 left join public.logic_case_evidence e using(case_id)
 left join public.logic_case_tasks t using(case_id)
 left join public.logic_case_final_deductions fd using(case_id)
 left join public.logic_case_final_person_options fp using(case_id)
 left join public.logic_case_final_explanation_options fe using(case_id)
 group by c.case_id
)
select *, phases=3 as has_three_phases,
       characters=6 as has_six_characters,
       final_deduction=1 as has_final_deduction,
       final_person_options=6 as has_six_final_person_options,
       final_explanations=4 as has_four_explanations
from counts order by case_id;

-- Task-option and correct-answer integrity: every task should have four options and its correct key must exist.
select t.case_id,t.task_id,t.correct_option_key,count(o.option_key) as option_count,
       bool_or(o.option_key=t.correct_option_key) as correct_key_exists
from public.logic_case_tasks t
left join public.logic_case_task_options o using(case_id,task_id)
group by t.case_id,t.task_id,t.correct_option_key
having count(o.option_key)<>4 or not bool_or(o.option_key=t.correct_option_key);

-- Evidence phase foreign keys ensure phase validity. Check release gates separately:
select case_id,gate_key,gate_status,notes
from public.logic_case_release_gates
where gate_status in ('fail','pending')
order by case_id,gate_key;
