# LOG03 — Scoring, Hints and Answer Key

**Track:** LOGIC  
**Team size:** Duo (2 players)  
**Content version:** 1.0.0  
**Access:** RESTRICTED — organiser/server only. Never expose this file to players.

## Final scoring model — approved case allocation

| Component | Maximum points |
|---|---:|
| Investigation Tasks 1–6 | 60 (10 each before hints) |
| Final responsible person | 25 |
| Final explanation | 15 |
| **Maximum case score** | **100** |

Each investigation task has the standard shared hint ladder: **10, 8, 6, 4, 2 points** based on the number of hints used (0–4). The fifth hint, if the engine exposes one, should reveal the answer and award 0 points; do not expose more than four scored hints unless the global rules are changed. A correct task is awarded once only. Each incorrect committed answer costs **−2 points**. Exploration and opening evidence do not cost points. Total score cannot fall below zero.

Final responsible-person and explanation components are scored independently and are each awarded once only. The final components have no hint ladder in this case. Incorrect final submissions cost −2 each, under the same global rule. Retries are permitted. Use server-authoritative scoring, idempotency keys, and separate attempt/completion records.

## Answer key

| Task | Correct option | Points before hints | Rationale |
|---|---|---:|---|
| Investigation Task 1 | B | 10 | The 4:11 entry is an outgoing control-desk call to Karthik that did not connect; it cannot substantiate a connected faculty-office call to him at that time. |
| Investigation Task 2 | A | 10 | The cable concern was genuine but was marked secured and tested before the cancellation entry. This does not prove there was no possible risk, only that the available record does not support the claimed confirmed cancellation. |
| Investigation Task 3 | B | 10 | Sana's account is that the unidentified caller requested a temporary hold pending a check, not a formal cancellation or faculty approval. |
| Investigation Task 4 | B | 10 | The independent logs show no connected faculty-office call to Karthik before the 4:13 announcement. A listed attempt or missed call is not a conversation. |
| Investigation Task 5 | B | 10 | The procedure distinguishes a hold from a cancellation and requires verification before changing the running order. |
| Investigation Task 6 | B | 10 | The note supports both a schedule-related motive and the inference that Karthik knowingly used an unverified concern as if it were faculty-approved. |
| Final responsible person | Karthik Menon | 25 | Karthik records and announces the cancellation, claims confirmation unsupported by either phone log, and has a note linking the action to the schedule dispute. |
| Final explanation | B | 15 | This is the only option that accounts for the real but addressed cable concern, the limited unidentified call, the missing confirmation, and Karthik's announcement and note. |

## Hints

Hints are shared across the team. Show them in order; do not reveal future-phase evidence through a hint. Hint 1 is the lightest nudge and Hint 4 is the strongest. The reward for a correct answer is determined by the number of hints used, not by how quickly the team answers.

### Investigation Task 1
1. Read the direction column, not just the time.
2. Compare the 4:11 entry with Karthik's claim.
3. An outgoing control-desk call is not a call from the faculty office.
4. The 4:11 call did not connect, so it cannot be the claimed confirmation.

### Investigation Task 2
1. Compare the time the cable was reported with the time it was checked.
2. Read the status recorded at 4:09 and 4:10.
3. The checklist says the cable was secured and tested before the cancellation entry.
4. The genuine earlier concern explains why someone might request a hold; it does not prove faculty cancellation.

### Investigation Task 3
1. Use Sana's account of the words spoken, not Karthik's later wording.
2. Notice the difference between “hold” and “cancel.”
3. The caller did not identify themselves or claim faculty authority.
4. The call requested a temporary hold pending a check, not a formal cancellation.

### Investigation Task 4
1. Check both phone systems.
2. A missed or zero-duration call is not proof that a conversation took place.
3. Neither system records a connected faculty-office call to Karthik before the announcement.
4. The claimed confirmation is unsupported by the independent logs.

### Investigation Task 5
1. Read all four steps on the procedure card.
2. A safety report is not the same as authorization to change the running order.
3. The policy requires verification and explicitly distinguishes a hold from a cancellation.
4. The rule against changing the running order before confirmed authorization was violated.

### Investigation Task 6
1. Consider the note's wording and where it appears on the running sheet.
2. The note links moving Pulse to a schedule dispute.
3. It says the safety concern is enough if marked faculty-approved.
4. Together with the unsupported announcement, the note supports knowing misrepresentation rather than a simple misunderstanding.

## Final deduction grading

- **Responsible person:** exact enum `karthik_menon` earns 25 points.
- **Explanation:** option `B` earns 15 points.
- Grade the components independently. A correct person with the wrong explanation earns 25; the correct explanation with the wrong person earns 15.
- Do not accept or grade free-text alternatives. Do not infer the unidentified caller's identity.

## Tie-break and event mechanics

Use the platform-wide tie-break rule: earliest server timestamp at which a team correctly resolves its final required deduction component. Never use client device time. Hints, answers, scoring rules and future-phase evidence remain server-side until unlocked by the server.
