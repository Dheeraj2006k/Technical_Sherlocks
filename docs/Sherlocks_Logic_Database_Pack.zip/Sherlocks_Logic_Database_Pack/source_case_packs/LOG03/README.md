# LOG03 — The Silent Call

**Logic track · Duo case · Content version 1.0.0**

This pack contains the final authored case content and consistent scoring allocation for the Sherlock's Last Case game engine.

## Files
- `LOG03_Player_Case.md` — player-facing case file; safe to adapt into the game UI.
- `LOG03_Case_Manifest.json` — structured manifest and answer keys; **restricted server-side only**.
- `LOG03_Author_Notes.md` — canonical truth, chronology, evidence logic and author guardrails; restricted.
- `LOG03_Scoring_and_Hints.md` — answer key, hint ladders and scoring rules; restricted.
- `LOG03_Validation_Checklist.md` — release gate for content, platform QA and playtesting.

## Final scoring
Six investigation tasks: up to 10 points each before hints (60 total); final responsible person: 25; final explanation: 15. Maximum score is 100. Investigation-task hint rewards are 10, 8, 6, 4, 2 for zero to four hints used. Incorrect committed answers cost 2 points; total score cannot fall below zero.

## Release status
The **case content is finalised** at version 1.0.0. This is not a claim that the production platform has been tested. Before live seeding, complete the unchecked platform QA and duo playtest items in `LOG03_Validation_Checklist.md`. Do not send restricted files to players or expose the manifest in the public client bundle.
