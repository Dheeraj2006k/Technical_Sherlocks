# LOG03 — Release Validation Checklist

**Content version:** 1.0.0  
**Purpose:** Final release gate for case seeding. The case story, answer key and scoring allocation are finalised; platform QA and playtesting must still pass before a live event.

## A. Canonical story and evidence
- [x] The central conclusion is supported by multiple independent evidence items.
- [x] The real cable concern is distinguished from verified authorization.
- [x] `00:00` is explicitly defined as a call that did not connect.
- [x] The 4:14 call is clearly a return call to the control desk after the 4:13 announcement, not a confirmation to Karthik.
- [x] The 4:10 caller remains unidentified and is not required for the answer.
- [x] Karthik's private note is explicitly authenticated by the event lead.
- [x] Character, prototype and incident names are consistent: Pulse is the demonstration/prototype.

## B. Questions and answer determinism
- [x] Six scored investigation tasks, two per phase.
- [x] Every task has one intended correct option and three distinguishable distractors.
- [x] No task asks players to infer the unknown caller's identity.
- [x] Final person and final explanation are independently graded.
- [ ] Verify the live UI's option labels and task IDs match the player case and manifest.
- [ ] Run an adversarial review: ask a reviewer to argue for each wrong option using only unlocked evidence.

## C. Scoring
- [x] Six tasks × 10 points = 60 maximum before hints.
- [x] Final responsible person = 25; final explanation = 15; maximum = 100.
- [x] Hint rewards are 10, 8, 6, 4, 2 for zero through four hints used.
- [x] Wrong committed answer penalty is −2; score floor is zero.
- [ ] Automated tests confirm a successful task/component can be awarded only once.
- [ ] Automated tests confirm duplicate requests/idempotency cannot duplicate points or penalties.
- [ ] Automated tests confirm retries, hint counts and score floor work after reconnect.

## D. Security and platform
- [ ] Keep this manifest, author notes, answer key and hints server-side; scan the client bundle/network responses for leaks.
- [ ] Direct API requests cannot read future-phase evidence.
- [ ] Team members see shared task completion and hint usage after refresh/reconnect.
- [ ] Unauthorized teams cannot access the case by guessing its ID.
- [ ] Admin reset/reassignment does not leave stale sessions or score records.
- [ ] Server timestamps—not client clocks—drive tie-breaks.

## E. Required playtest before live release
- [ ] Run at least two first-time duo playtests without author assistance.
- [ ] Record total duration and per-phase duration.
- [ ] Ask each pair to explain why a missed/zero-duration call is not a confirmed conversation.
- [ ] Ask each pair to explain why the unidentified caller's identity is not necessary.
- [ ] Confirm both pairs choose Karthik for evidence-based reasons, not solely because he has a motive.
- [ ] Confirm the story can be solved using only evidence unlocked by the normal flow.
- [ ] Freeze and record the exact content version used for event seeding.

## Release decision

**Do not mark the case live until all unchecked items in Sections B–E are passed.** Any content change after playtesting increments `content_version` and requires relevant tests to be rerun.
