# Sherlock’s Last Case — Logic Track Database Pack

Includes exact PostgreSQL/Supabase table definitions and seed data for LOG01, LOG02, and LOG03, based on the currently authored player case files and manifests.

## Contents
- `schema/001_logic_case_content_schema.sql` — normalized case-content schema.
- `seeds/seed_LOG01.sql`, `seed_LOG02.sql`, `seed_LOG03.sql` — idempotent case seeds.
- `seeds/seed_all_logic_cases.sql` — combined seed script.
- `verification/verify_logic_case_seeds.sql` — row counts, option integrity, and release-gate queries.
- `source_case_packs/` — copies of the authored case packs used to generate the seeds.

## Apply in Supabase
1. Create a development/staging Supabase project or use a non-production branch.
2. Open SQL Editor and run `schema/001_logic_case_content_schema.sql` once.
3. Run either each case seed separately, or `seed_all_logic_cases.sql` (not both unless intentionally re-running; seeds use `ON CONFLICT` updates).
4. Run `verification/verify_logic_case_seeds.sql`.
5. Review every `pending`/`fail` release gate before activating any case.

## Important release status
**These are database-complete seeds, not a claim that all three narratives are production-approved.** The source content has known gaps that are recorded in `logic_case_release_gates`. LOG01 still needs an independent physical link from Vikram to the substitution and a consistent approved scoring allocation. LOG02 still needs an independent physical link to Kavya’s diversion, a defined trophy outcome/location, and scoring reconciliation. LOG03 has a finalised narrative allocation but still requires platform QA and duo playtests. Do not mark a case live while any required gate is `fail` or `pending`.

## Scoring caveat
LOG01/LOG02 retain their authored 9 × 5-point investigation-question model and 35 + 20 final model because those are the existing case packs. This does **not** match the global platform default of 10/8/6/4/2 hint rewards for 10-point tasks. The seed deliberately flags that mismatch as a failed release gate rather than silently changing points or the player-facing prompts. LOG03 uses six 10-point tasks (10/8/6/4/2 hint ladder) plus 25 + 15 final points = 100. Resolve the LOG01/LOG02 scoring decision before live activation.

## Security notes
- All content tables have RLS enabled and no browser-role policies. `anon` and `authenticated` are explicitly revoked. Trusted server code must enforce assignment and phase access before returning evidence.
- `logic_case_tasks.correct_option_key` and `logic_case_final_deductions` are answer-key data; never expose them through a client query or public API response.
- Do not use the Supabase service-role key in the browser.
- These tables are case content only; they do not replace runtime tables for teams, sessions, attempts, completions, scoring ledger, assignments, or leaderboard.
- The `source_manifest` column intentionally stores the source manifest for audit/versioning; it includes answer keys and must remain server-side.

## Content IDs
Evidence IDs preserve the source labels A–N. Task IDs preserve Q1–Q9 for LOG01/LOG02 and T1–T6 for LOG03. IDs are scoped by `case_id`, so repeated labels are safe.
