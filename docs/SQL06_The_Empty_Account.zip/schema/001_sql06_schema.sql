-- SQL06: The Empty Account — case-specific evidence schema
-- Run after the shared Sherlock's Last Case runtime schema.
-- Idempotent: CREATE TABLE IF NOT EXISTS; seed script uses upserts.
CREATE SCHEMA IF NOT EXISTS sql06;

CREATE TABLE IF NOT EXISTS sql06.account_snapshots (
  snapshot_id text PRIMARY KEY,
  account_name text NOT NULL,
  recorded_at timestamptz NOT NULL,
  available_balance numeric(10,2) NOT NULL,
  pending_balance numeric(10,2) NOT NULL,
  source_system text NOT NULL,
  note text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.ledger_entries (
  entry_id text PRIMARY KEY,
  posted_at timestamptz NOT NULL,
  account_code text NOT NULL,
  entry_type text NOT NULL CHECK (entry_type IN ('CREDIT','DEBIT','REVERSAL')),
  amount numeric(10,2) NOT NULL CHECK (amount > 0),
  reference_code text NOT NULL,
  entered_by text NOT NULL,
  description text NOT NULL,
  status text NOT NULL CHECK (status IN ('POSTED','PENDING','REVERSED'))
);

CREATE TABLE IF NOT EXISTS sql06.payment_requests (
  request_id text PRIMARY KEY,
  requested_at timestamptz NOT NULL,
  requested_by text NOT NULL,
  payee text NOT NULL,
  amount numeric(10,2) NOT NULL,
  purpose text NOT NULL,
  approval_code text,
  request_status text NOT NULL,
  submitted_channel text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.approval_registry (
  approval_code text PRIMARY KEY,
  approver text NOT NULL,
  approved_at timestamptz NOT NULL,
  amount_limit numeric(10,2) NOT NULL,
  approved_payee text NOT NULL,
  approved_purpose text NOT NULL,
  status text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.gateway_events (
  event_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  reference_code text NOT NULL,
  event_type text NOT NULL,
  gateway_status text NOT NULL,
  amount numeric(10,2) NOT NULL,
  destination_fingerprint text NOT NULL,
  terminal_id text NOT NULL,
  operator_note text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.reconciliation_notes (
  note_id text PRIMARY KEY,
  created_at timestamptz NOT NULL,
  author text NOT NULL,
  topic text NOT NULL,
  note_text text NOT NULL,
  visibility text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.access_audit (
  audit_id text PRIMARY KEY,
  event_at timestamptz NOT NULL,
  actor text NOT NULL,
  action text NOT NULL,
  object_ref text NOT NULL,
  result text NOT NULL,
  workstation text NOT NULL
);

CREATE TABLE IF NOT EXISTS sql06.staff_directory (
  staff_id text PRIMARY KEY,
  full_name text NOT NULL,
  role_title text NOT NULL,
  normal_duties text NOT NULL,
  known_context text NOT NULL
);
