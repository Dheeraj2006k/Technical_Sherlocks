-- SQL06 verification checks. Expected: every check returns PASS.
WITH checks AS (
  SELECT 'schema_tables' AS check_name,
    (SELECT count(*) FROM information_schema.tables WHERE table_schema='sql06'
      AND table_name IN ('account_snapshots','ledger_entries','payment_requests','approval_registry','gateway_events','reconciliation_notes','access_audit','staff_directory')) = 8 AS ok
  UNION ALL SELECT 'opening_grant', (SELECT count(*) FROM sql06.ledger_entries WHERE entry_id='L001' AND amount=42000 AND entry_type='CREDIT')=1
  UNION ALL SELECT 'duplicate_approval_reference', (SELECT count(*) FROM sql06.payment_requests WHERE approval_code='APR-103')=2
  UNION ALL SELECT 'destination_change', (SELECT count(DISTINCT destination_fingerprint) FROM sql06.gateway_events WHERE reference_code IN ('PAY-712','PAY-712B'))=2
  UNION ALL SELECT 'settled_replacement', (SELECT count(*) FROM sql06.gateway_events WHERE reference_code='PAY-712B' AND gateway_status='SETTLED')=1
  UNION ALL SELECT 'restricted_author_note', (SELECT count(*) FROM sql06.reconciliation_notes WHERE visibility='RESTRICTED_AUTHOR')=1
  UNION ALL SELECT 'audit_override', (SELECT count(*) FROM sql06.access_audit WHERE actor='Dev Malhotra' AND action='MANUAL_OVERRIDE' AND result='SUCCESS')=1
  UNION ALL SELECT 'ledger_net_balance', (
    SELECT sum(CASE WHEN entry_type='CREDIT' THEN amount WHEN entry_type='DEBIT' THEN -amount WHEN entry_type='REVERSAL' THEN amount ELSE 0 END)
    FROM sql06.ledger_entries WHERE status='POSTED') = 0
)
SELECT check_name, CASE WHEN ok THEN 'PASS' ELSE 'FAIL' END AS result FROM checks ORDER BY check_name;
