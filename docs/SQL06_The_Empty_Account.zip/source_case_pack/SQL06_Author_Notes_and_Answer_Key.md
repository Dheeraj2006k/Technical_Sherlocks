# SQL06 — Organizer Answer Key (RESTRICTED)

## Intended answer
**Dev Malhotra** created replacement request `PAY-712B` and used a successful `MANUAL_OVERRIDE`. The original `PAY-712` gateway attempt was rejected for destination validation and then reversed. The replacement was accepted and settled, but its destination fingerprint changed from `DEST-NORTH-44` to `DEST-NORTH-84`. It reused `APR-103`, whose registered approval described the original emergency reserve purpose/payee; the approval does not independently validate a changed destination.

## Twist
The dashboard's ₹0 is a misleading snapshot/sync symptom, not proof that the money vanished at the moment the dashboard refreshed. The actual suspicious event is the replacement transfer settling to a different destination. The apparent reversal creates a plausible explanation for a routine retry, while the changed fingerprint and manual override break that explanation.

## Fairness guardrails
- Do not claim the true beneficiary or final use of funds is known. Destination fingerprints are identifiers, not identities.
- The ₹12,000 balance calculation is ledger-based and is not sufficient by itself to prove wrongdoing.
- Asha created the original request; the audit shows she did not create the replacement.
- The faculty approval is for a purpose/payee; a changed destination is the key discrepancy.
- The restricted private draft is author-only. Do not expose it to players or include it in student-facing query access.

## Scoring (100)
T1–T6: 10 each = 60. Culprit: 25. Explanation: 15, requiring at least three distinct evidence points. Hint ladder 10/8/6/4/2. Wrong committed answer −2, floor 0. Exploration errors are free.
