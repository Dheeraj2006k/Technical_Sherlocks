# SQL06 — The Empty Account

**Case pack status: content packaged; not production-certified.**

## Files
- `schema/001_sql06_schema.sql` — case-specific PostgreSQL tables in `sql06`.
- `seeds/seed_SQL06.sql` — deterministic, idempotent seed script.
- `verification/verify_SQL06.sql` — expected PASS checks.
- `source_case_pack/SQL06_Case_Manifest.json` — case metadata, phases, tasks, accepted answers and scoring.
- `source_case_pack/SQL06_Hints.json` — progressive hints.
- `source_case_pack/SQL06_Author_Notes_and_Answer_Key.md` — restricted organizer solution.
- `player_release/` — only intended player-facing narrative and public task prompts.

## Staging sequence
1. Apply `schema/001_sql06_schema.sql` to a disposable Supabase staging project.
2. Apply `seeds/seed_SQL06.sql`.
3. Run `verification/verify_SQL06.sql`; all checks should report PASS.
4. Wire phase/table visibility and task IDs into the shared Sherlock's Last Case runtime.
5. Ensure student SQL uses a SELECT-only role and cannot read restricted author notes/files. Keep the organizer answer key out of client assets.
6. Run a blind solo playtest and concurrent/security tests before event deployment.

## Important limits
This pack has not been executed against your Supabase project, integrated into your live engine, independently security-tested, or blind-playtested. Do not describe it as certified production-ready until those checks pass. SQL case tables are namespaced and do not replace shared teams/sessions/scoring tables.
