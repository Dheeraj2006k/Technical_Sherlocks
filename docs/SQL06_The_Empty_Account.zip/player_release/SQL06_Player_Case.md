# THE EMPTY ACCOUNT
**Case SQL06 · Solo investigation**

The morning before QUBIT opens, the QUBIT Prototype Fund dashboard shows **₹0 available**. The fund received ₹42,000 the previous day. Two supplier payments were ordinary. A third ₹12,000 reserve payment was rejected, reversed, and apparently sent again.

The logistics lead says the replacement was just a routine retry and the dashboard is behind on syncing. But the replacement settled, and the gateway records do not look identical.

Your job is to reconstruct the money trail, compare the approval with the replacement request, and identify who made the suspicious change. You can prove a destination changed; you cannot identify the real-world owner from a fingerprint alone.

## Investigation phases
1. **The Balance:** inspect `sql06.account_snapshots` and `sql06.ledger_entries`.
2. **The Approval Trail:** inspect `sql06.payment_requests`, `sql06.approval_registry`, and `sql06.staff_directory`.
3. **The Gateway:** inspect `sql06.gateway_events`, `sql06.access_audit`, and the player-visible reconciliation notes.

## Questions
1. What was the grant credit amount?
2. Which reference is the original reserve payment?
3. Which approval code was reused for the replacement request?
4. Who created the replacement request?
5. What changed between the original and replacement gateway transfers?
6. What audit action allowed the replacement to proceed?

## Final deduction
Who was responsible for the suspicious replacement transfer, and what evidence proves it was not a routine retry?

**SQL note:** Query errors are free. Only committed answers are subject to the game's scoring rules.
